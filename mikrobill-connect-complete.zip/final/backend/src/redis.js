/**
 * backend/src/redis.js
 *
 * ioredis client with graceful degradation.
 * If REDIS_URL is not set, all operations are no-ops (QoS leaderboard simply won't work,
 * but the rest of the system continues normally).
 */

"use strict";

const logger = require("./utils/logger");

let client = null;

if (process.env.REDIS_URL) {
  const Redis = require("ioredis");

  client = new Redis(process.env.REDIS_URL, {
    maxRetriesPerRequest: 3,
    enableReadyCheck:     true,
    lazyConnect:          false,
  });

  client.on("connect", () => logger.info("redis: connected"));
  client.on("error",   (err) => logger.error({ err }, "redis: error"));
  client.on("close",   () => logger.warn("redis: connection closed"));
} else {
  logger.warn("redis: REDIS_URL not set — QoS top-user leaderboard disabled");
}

module.exports = client; // null if not configured
