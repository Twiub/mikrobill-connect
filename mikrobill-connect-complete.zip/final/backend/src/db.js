/**
 * backend/src/db.js
 *
 * PostgreSQL connection pool using node-postgres (pg).
 * Reads credentials from environment variables.
 *
 * Usage:
 *   const db = require("./db");
 *   const { rows } = await db.query("SELECT * FROM routers WHERE id = $1", [id]);
 *
 *   // For transactions:
 *   const client = await db.connect();
 *   try {
 *     await client.query("BEGIN");
 *     // ...
 *     await client.query("COMMIT");
 *   } catch { await client.query("ROLLBACK"); }
 *   finally { client.release(); }
 */

"use strict";

const { Pool } = require("pg");
const logger   = require("./utils/logger");

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,

  // Connection pool tuning for ISP workloads
  max:              20,    // max concurrent connections
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000,

  // SSL for cloud-hosted Postgres (Supabase, RDS, etc.)
  ssl: process.env.DATABASE_SSL === "true"
    ? { rejectUnauthorized: false }
    : undefined,
});

// Log slow queries in production
pool.on("connect", () => {
  logger.debug("db: new connection acquired from pool");
});

pool.on("error", (err) => {
  logger.error({ err }, "db: idle client error");
});

// Health check helper
async function healthCheck() {
  const client = await pool.connect();
  try {
    await client.query("SELECT 1");
    return true;
  } finally {
    client.release();
  }
}

module.exports = {
  query:  (...args) => pool.query(...args),
  connect: ()      => pool.connect(),
  end:    ()       => pool.end(),
  healthCheck,
};
