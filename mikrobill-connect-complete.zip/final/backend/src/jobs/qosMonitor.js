/**
 * backend/src/jobs/qosMonitor.js
 *
 * Polls MikroTik queue tree stats every 30 seconds.
 *   • Stores per-queue byte/packet/drop counters in qos_stats
 *   • Calculates estimated bufferbloat latency score per router
 *   • Alerts admin when drop rate > 5% or WAN queue > 90% utilisation
 *   • Syncs top-10 bandwidth users to a Redis sorted set for live dashboard
 *
 * Requires:
 *   - CAKE queues named:  wan-cake, cake-ingress, pkg-*, user-*
 *   - getMikrotikConnection(), db, redis, sendAdminAlert(), logger
 */

"use strict";

const cron                     = require("node-cron");
const db                       = require("../db");
const redis                    = require("../redis");
const { getMikrotikConnection } = require("../services/mikrotik");
const { sendAdminAlert }        = require("../services/notifications");
const logger                    = require("../utils/logger");

const POLL_INTERVAL    = "*/30 * * * * *";  // every 30 seconds (node-cron 6-field)
const DROP_ALERT_PCT   = 5;                 // % drop rate threshold
const WAN_ALERT_PCT    = 90;               // % WAN utilisation threshold
const ALERT_COOLDOWN   = 5 * 60 * 1000;   // 5 minutes between repeat alerts
const WAN_QUEUE_NAME   = "wan-cake";       // top-level CAKE shaper name

// Alert state (in-process — use Redis for multi-process deployments)
const lastAlerts = new Map();

// ---------------------------------------------------------------------------
// Parse "95M" → bits-per-second number
// ---------------------------------------------------------------------------
function parseBandwidthBps(str) {
  if (!str) return 0;
  const m = String(str).match(/^([\d.]+)([KMG]?)$/i);
  if (!m) return 0;
  const n = parseFloat(m[1]);
  const unit = m[2].toUpperCase();
  const mult = { K: 1_000, M: 1_000_000, G: 1_000_000_000 }[unit] ?? 1;
  return n * mult * 8; // bytes → bits
}

// ---------------------------------------------------------------------------
// Alert helper with cooldown
// ---------------------------------------------------------------------------
async function maybeAlert(key, title, message) {
  const last = lastAlerts.get(key) ?? 0;
  if (Date.now() - last < ALERT_COOLDOWN) return;
  lastAlerts.set(key, Date.now());

  try {
    await sendAdminAlert(title, message);
  } catch (err) {
    logger.error({ err }, "qos_monitor: alert send failed");
  }
}

// ---------------------------------------------------------------------------
// Core poll
// ---------------------------------------------------------------------------
async function collectQosStats() {
  let routers;

  try {
    const r = await db.query(
      "SELECT id, name, ip_address FROM routers WHERE status = 'online'"
    );
    routers = r.rows;
  } catch (err) {
    logger.error({ err }, "qos_monitor: failed to load routers");
    return;
  }

  for (const router of routers) {
    let conn;

    try {
      conn = await getMikrotikConnection(router.id);

      // Fetch queue tree stats
      const stats = await conn.write("/queue/tree/print", [
        "=.proplist=name,bytes,packets,dropped,queued,max-limit",
      ]);

      const insertValues = [];
      const insertParams = [];
      let p = 1;

      // Identify WAN queue for utilisation calculation
      const wanQueue = stats.find(q => q.name === WAN_QUEUE_NAME);
      const wanMaxBps = parseBandwidthBps(wanQueue?.["max-limit"]);

      // Track top users for Redis leaderboard
      const userQueues = stats.filter(q => q.name?.startsWith("user-"));

      for (const q of stats) {
        const bytes   = parseInt(q.bytes   ?? "0", 10);
        const packets = parseInt(q.packets ?? "0", 10);
        const dropped = parseInt(q.dropped ?? "0", 10);
        const queued  = parseInt(q.queued  ?? "0", 10);

        insertValues.push(
          `($${p++}, $${p++}, $${p++}, $${p++}, $${p++}, $${p++})`
        );
        insertParams.push(router.id, q.name, bytes, packets, dropped, queued);

        // ── Drop rate alert ──────────────────────────────────────────────
        const dropRate = packets > 0 ? (dropped / packets) * 100 : 0;
        if (dropRate > DROP_ALERT_PCT && packets > 1000) {
          await maybeAlert(
            `drop:${router.id}:${q.name}`,
            "⚠️ QoS Drop Rate Alert",
            `Queue "${q.name}" on ${router.name}: ${dropRate.toFixed(1)}% drop rate ` +
            `(${dropped.toLocaleString()} drops / ${packets.toLocaleString()} pkts). ` +
            `Possible congestion or abuse.`
          );
        }

        // ── WAN utilisation alert ────────────────────────────────────────
        if (q.name === WAN_QUEUE_NAME && wanMaxBps > 0) {
          // bytes is cumulative — derive current rate from delta if available
          // For simplicity: alert when queued packets are very high (proxy for saturation)
          const wanPct = Math.min((queued / 500) * 100, 100); // rough proxy
          if (wanPct > WAN_ALERT_PCT) {
            await maybeAlert(
              `wan:${router.id}`,
              "🔥 WAN Queue Saturation",
              `WAN CAKE queue on ${router.name} is heavily loaded (${queued} pkts queued). ` +
              `Bufferbloat may be occurring. Check for traffic spikes.`
            );
          }
        }
      }

      // ── Bulk insert ───────────────────────────────────────────────────
      if (insertValues.length > 0) {
        await db.query(
          `INSERT INTO qos_stats (router_id, queue_name, bytes, packets, dropped, queued)
           VALUES ${insertValues.join(", ")}`,
          insertParams
        );
      }

      // ── Top bandwidth users → Redis sorted set ────────────────────────
      // Key: qos:top_users:{routerId}  Score: bytes  Member: username
      if (userQueues.length > 0 && redis) {
        const pipeline = redis.pipeline();
        const redisKey = `qos:top_users:${router.id}`;
        pipeline.del(redisKey);
        for (const q of userQueues) {
          const username = q.name.replace(/^user-/, "");
          const bytes    = parseInt(q.bytes ?? "0", 10);
          pipeline.zadd(redisKey, bytes, username);
        }
        pipeline.expire(redisKey, 120); // 2-minute TTL
        await pipeline.exec();
      }

      logger.debug({ router: router.name, queues: stats.length }, "qos_monitor: polled");

    } catch (err) {
      logger.error({ err, router: router.name }, "qos_monitor: poll error");
    } finally {
      conn?.close?.();
    }
  }
}

// ---------------------------------------------------------------------------
// Prune: keep only 7 days of QoS stats
// ---------------------------------------------------------------------------
async function pruneOldStats() {
  try {
    const { rowCount } = await db.query(
      "DELETE FROM qos_stats WHERE recorded_at < NOW() - INTERVAL '7 days'"
    );
    if (rowCount > 0) logger.info({ rowCount }, "qos_monitor: pruned old stats");
  } catch (err) {
    logger.error({ err }, "qos_monitor: prune failed");
  }
}

// ---------------------------------------------------------------------------
// Start
// ---------------------------------------------------------------------------
function start() {
  logger.info("qos_monitor: starting (every 30s)");

  collectQosStats().catch(err =>
    logger.error({ err }, "qos_monitor: initial poll failed")
  );

  cron.schedule(POLL_INTERVAL, () => {
    collectQosStats().catch(err =>
      logger.error({ err }, "qos_monitor: scheduled poll failed")
    );
  });

  cron.schedule("0 3 * * *", pruneOldStats);
}

module.exports = { start, collectQosStats };
