/**
 * backend/src/jobs/tetherEnforcement.js
 *
 * Runs every 5 minutes:
 *   • Reads the MikroTik `tethered-devices` address-list from every active router
 *   • Maps each tethered IP back to the paying subscriber via active_sessions
 *   • Upserts violations into sharing_violations with router + TTL info
 *   • Sends an in-app notification to the subscriber (not SMS — avoid false positives)
 *
 * MikroTik TTL mangle rules (from Section 2.2 of design doc) must already be
 * deployed on each router before this job has data to read.
 */

"use strict";

const cron                     = require("node-cron");
const db                       = require("../db");
const { getMikrotikConnection } = require("../services/mikrotik");
const { createNotification }    = require("../services/notifications");
const logger                    = require("../utils/logger");

const POLL_INTERVAL = "*/5 * * * *";

// ---------------------------------------------------------------------------
// Core
// ---------------------------------------------------------------------------
async function syncTetheredDevices() {
  let routers;

  try {
    const r = await db.query(
      "SELECT id, name FROM routers WHERE status = 'online'"
    );
    routers = r.rows;
  } catch (err) {
    logger.error({ err }, "tether_enforcement: failed to load routers");
    return;
  }

  for (const router of routers) {
    let conn;

    try {
      conn = await getMikrotikConnection(router.id);

      // Fetch entries currently in the address-list
      const tethered = await conn.write("/ip/firewall/address-list/print", [
        "?list=tethered-devices",
        "=.proplist=address,timeout,comment",
      ]);

      if (!tethered?.length) continue;

      for (const entry of tethered) {
        const ip = entry.address;

        // Determine TTL value from comment field set by mangle rule
        // e.g. comment="TTL=63: Android tethered client"
        const ttlMatch = entry.comment?.match(/TTL=(\d+)/);
        const ttlValue = ttlMatch ? parseInt(ttlMatch[1], 10) : null;

        // Find which subscriber owns this IP via their active session
        const sessionResult = await db.query(
          `SELECT s.id AS session_id, s.subscriber_id, sub.username, sub.phone
           FROM   active_sessions s
           JOIN   subscribers sub ON sub.id = s.subscriber_id
           WHERE  s.ip_address = $1
             AND  s.status = 'active'
           LIMIT  1`,
          [ip]
        );

        if (!sessionResult.rows.length) continue; // unknown IP, skip

        const { subscriber_id, username, phone } = sessionResult.rows[0];

        // Upsert violation — avoid duplicate rows for same IP within 10 minutes
        const upsertResult = await db.query(
          `INSERT INTO sharing_violations
             (subscriber_id, router_id, tethered_ip, ttl_value, detected_at)
           VALUES ($1, $2, $3::inet, $4, NOW())
           ON CONFLICT DO NOTHING
           RETURNING id`,
          [subscriber_id, router.id, ip, ttlValue]
        );

        // Only notify on new violations
        if (upsertResult.rows.length > 0) {
          logger.info(
            { subscriber_id, username, ip, router: router.name, ttlValue },
            "tether_enforcement: new violation recorded"
          );

          // In-app notification — no SMS to avoid alerting user to circumvent
          await createNotification({
            subscriber_id,
            type:    "warning",
            title:   "Hotspot Sharing Detected",
            message: `A device tethering through your phone (IP: ${ip}) was blocked from internet access. ` +
                     `Your own connection is unaffected. Contact support if you believe this is an error.`,
            channel: "push",
          }).catch(e => logger.warn({ e }, "tether_enforcement: notification failed"));
        }
      }

      logger.debug(
        { router: router.name, count: tethered.length },
        "tether_enforcement: polled"
      );

    } catch (err) {
      logger.error({ err, router: router.name }, "tether_enforcement: poll error");
    } finally {
      conn?.close?.();
    }
  }
}

// ---------------------------------------------------------------------------
// Auto-resolve violations older than 15 minutes (address-list timeout = 10m)
// ---------------------------------------------------------------------------
async function resolveExpiredViolations() {
  try {
    const { rowCount } = await db.query(
      `UPDATE sharing_violations
       SET    resolved = TRUE, resolved_at = NOW()
       WHERE  resolved = FALSE
         AND  detected_at < NOW() - INTERVAL '15 minutes'`
    );
    if (rowCount > 0) {
      logger.debug({ rowCount }, "tether_enforcement: auto-resolved expired violations");
    }
  } catch (err) {
    logger.error({ err }, "tether_enforcement: resolve failed");
  }
}

// ---------------------------------------------------------------------------
// Start
// ---------------------------------------------------------------------------
function start() {
  logger.info("tether_enforcement: starting (every 5 min)");

  syncTetheredDevices().catch(err =>
    logger.error({ err }, "tether_enforcement: initial run failed")
  );

  cron.schedule(POLL_INTERVAL, async () => {
    await syncTetheredDevices().catch(err =>
      logger.error({ err }, "tether_enforcement: scheduled run failed")
    );
    await resolveExpiredViolations().catch(() => {});
  });
}

module.exports = { start, syncTetheredDevices };
