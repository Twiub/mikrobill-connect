/**
 * backend/src/jobs/ipPoolMonitor.js
 *
 * Polls every 5 minutes:
 *   • Fetches used/total counts for each IP pool from every active MikroTik
 *   • Stores metrics in ip_pool_stats for trend graphs
 *   • Fires admin alert (SMS + push) when any pool exceeds 80% capacity
 *
 * Depends on:
 *   - getMikrotikConnection()  → node-routeros / routeros-client connection
 *   - db                       → pg Pool
 *   - sendAdminAlert()         → Africa's Talking SMS + FCM push
 */

"use strict";

const cron             = require("node-cron");
const db               = require("../db");
const { getMikrotikConnection } = require("../services/mikrotik");
const { sendAdminAlert }        = require("../services/notifications");
const logger           = require("../utils/logger");

const POLL_INTERVAL     = "*/5 * * * *";   // every 5 minutes
const ALERT_THRESHOLD   = 80;              // percent

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Parse a MikroTik pool ranges string into the total number of usable IPs.
 * Supports comma-separated ranges, e.g. "10.10.0.1-10.10.15.254"
 *
 * @param {string} ranges  e.g. "10.10.0.1-10.10.15.254,10.10.16.1-10.10.31.254"
 * @returns {number}
 */
function calculatePoolSize(ranges) {
  if (!ranges) return 0;

  return ranges.split(",").reduce((total, range) => {
    const [startStr, endStr] = range.trim().split("-");
    if (!startStr || !endStr) return total;

    const ipToLong = (ip) =>
      ip.trim().split(".").reduce((acc, octet) => (acc << 8) + parseInt(octet, 10), 0) >>> 0;

    const size = ipToLong(endStr) - ipToLong(startStr) + 1;
    return total + Math.max(0, size);
  }, 0);
}

// Track which pools have already sent an alert this cycle to avoid spam
const alertedPools = new Map(); // key: `${routerId}:${poolName}` → timestamp

// ---------------------------------------------------------------------------
// Core poll function
// ---------------------------------------------------------------------------
async function checkIpPoolUtilization() {
  let routers;

  try {
    const result = await db.query(
      "SELECT id, name, ip_address FROM routers WHERE status = 'online' ORDER BY name"
    );
    routers = result.rows;
  } catch (err) {
    logger.error({ err }, "ip_pool_monitor: failed to fetch routers");
    return;
  }

  for (const router of routers) {
    let conn;

    try {
      conn = await getMikrotikConnection(router.id);

      // Fetch pool definitions (name + ranges)
      const poolDefs = await conn.write("/ip/pool/print", [
        "=.proplist=name,ranges,next-pool",
      ]);

      // Fetch used addresses (one entry per leased IP)
      const usedEntries = await conn.write("/ip/pool/used/print", [
        "=.proplist=pool,address",
      ]);

      // Group used entries by pool name
      const usedByPool = {};
      for (const entry of usedEntries) {
        const p = entry["pool"] ?? entry["owner-name"] ?? "";
        usedByPool[p] = (usedByPool[p] ?? 0) + 1;
      }

      // Build records and insert in a single transaction
      const insertValues = [];
      const insertParams = [];
      let paramIdx = 1;

      for (const pool of poolDefs) {
        const poolName = pool.name;
        const used     = usedByPool[poolName] ?? 0;
        const total    = calculatePoolSize(pool.ranges);
        if (total === 0) continue;

        const pctUsed = parseFloat(((used / total) * 100).toFixed(2));

        insertValues.push(`($${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++}, $${paramIdx++})`);
        insertParams.push(router.id, poolName, used, total, pctUsed);

        // Alert if over threshold, but at most once per 30 minutes per pool
        const alertKey = `${router.id}:${poolName}`;
        const lastAlert = alertedPools.get(alertKey) ?? 0;
        const cooldown  = 30 * 60 * 1000; // 30 min

        if (pctUsed > ALERT_THRESHOLD && Date.now() - lastAlert > cooldown) {
          alertedPools.set(alertKey, Date.now());

          sendAdminAlert(
            "⚠️ IP Pool Capacity Alert",
            `Pool "${poolName}" on ${router.name} is ${pctUsed}% full (${used}/${total} IPs). ` +
            `Consider adding a next-pool or expanding the subnet.`
          ).catch(e => logger.error({ err: e }, "ip_pool_monitor: alert failed"));
        }
      }

      if (insertValues.length > 0) {
        await db.query(
          `INSERT INTO ip_pool_stats (router_id, pool_name, used, total, pct_used)
           VALUES ${insertValues.join(", ")}`,
          insertParams
        );
      }

      logger.debug({ router: router.name, pools: poolDefs.length }, "ip_pool_monitor: polled");

    } catch (err) {
      logger.error({ err, router: router.name }, "ip_pool_monitor: poll failed for router");
    } finally {
      conn?.close?.();
    }
  }
}

// ---------------------------------------------------------------------------
// Retention: delete records older than 30 days to keep the table lean
// ---------------------------------------------------------------------------
async function pruneOldStats() {
  try {
    const { rowCount } = await db.query(
      "DELETE FROM ip_pool_stats WHERE recorded_at < NOW() - INTERVAL '30 days'"
    );
    if (rowCount > 0) {
      logger.info({ rowCount }, "ip_pool_monitor: pruned old stats");
    }
  } catch (err) {
    logger.error({ err }, "ip_pool_monitor: prune failed");
  }
}

// ---------------------------------------------------------------------------
// Start
// ---------------------------------------------------------------------------
function start() {
  logger.info("ip_pool_monitor: starting (every 5 min)");

  // Run immediately on startup
  checkIpPoolUtilization().catch(err =>
    logger.error({ err }, "ip_pool_monitor: initial poll failed")
  );

  cron.schedule(POLL_INTERVAL, () => {
    checkIpPoolUtilization().catch(err =>
      logger.error({ err }, "ip_pool_monitor: scheduled poll failed")
    );
  });

  // Prune once per day at 02:00
  cron.schedule("0 2 * * *", pruneOldStats);
}

module.exports = { start, checkIpPoolUtilization, calculatePoolSize };
