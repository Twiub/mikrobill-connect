/**
 * backend/src/jobs/radiusdeskSync.js
 *
 * Syncs RadiusDesk access point data into the local radiusdesk_aps table
 * every 2 minutes so the coverage map always has fresh AP positions + status.
 *
 * Also performs a health check on RadiusDesk itself and logs to error_logs
 * if it becomes unreachable.
 */

"use strict";

const cron        = require("node-cron");
const db          = require("../db");
const radiusdesk  = require("../services/radiusdesk");
const logger      = require("../utils/logger");

const SYNC_INTERVAL = "*/2 * * * *";

async function syncAccessPoints() {
  let aps;

  try {
    aps = await radiusdesk.getEnrichedAccessPoints();
  } catch (err) {
    logger.error({ err }, "rd_sync: failed to fetch APs from RadiusDesk");

    // Log to error_logs table so it shows up in the admin Error Logs page
    await db.query(
      `INSERT INTO error_logs (service, level, message, details)
       VALUES ('radiusdesk', 'error', 'RadiusDesk unreachable', $1)`,
      [JSON.stringify({ error: err.message })]
    ).catch(() => {});

    return;
  }

  if (!aps.length) return;

  // Upsert each AP — keyed on MAC address
  for (const ap of aps) {
    try {
      await db.query(
        `INSERT INTO radiusdesk_aps
           (mac, name, lat, lng, online, active_clients, last_contact, model, firmware, synced_at)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
         ON CONFLICT (mac) DO UPDATE SET
           name           = EXCLUDED.name,
           lat            = EXCLUDED.lat,
           lng            = EXCLUDED.lng,
           online         = EXCLUDED.online,
           active_clients = EXCLUDED.active_clients,
           last_contact   = EXCLUDED.last_contact,
           model          = EXCLUDED.model,
           firmware       = EXCLUDED.firmware,
           synced_at      = NOW()`,
        [
          ap.mac,
          ap.name,
          ap.lat,
          ap.lng,
          ap.online,
          ap.activeClients,
          ap.lastContact,
          ap.model,
          ap.firmware,
        ]
      );
    } catch (err) {
      logger.error({ err, mac: ap.mac }, "rd_sync: upsert failed for AP");
    }
  }

  // Mark APs not seen in RadiusDesk as offline
  const liveMacs = aps.map(a => a.mac);
  if (liveMacs.length > 0) {
    await db.query(
      `UPDATE radiusdesk_aps
       SET online = FALSE
       WHERE mac <> ALL($1::text[])
         AND online = TRUE`,
      [liveMacs]
    ).catch(err => logger.error({ err }, "rd_sync: offline mark failed"));
  }

  logger.debug({ count: aps.length }, "rd_sync: access points synced");
}

function start() {
  logger.info("rd_sync: starting (every 2 min)");

  syncAccessPoints().catch(err =>
    logger.error({ err }, "rd_sync: initial sync failed")
  );

  cron.schedule(SYNC_INTERVAL, () => {
    syncAccessPoints().catch(err =>
      logger.error({ err }, "rd_sync: scheduled sync failed")
    );
  });
}

module.exports = { start, syncAccessPoints };
