/**
 * backend/src/utils/logger.js
 *
 * Structured JSON logger using pino.
 * Falls back to a simple console wrapper if pino is not installed.
 */

"use strict";

let logger;

try {
  const pino = require("pino");
  logger = pino({
    level: process.env.LOG_LEVEL || "info",
    transport: process.env.NODE_ENV !== "production"
      ? { target: "pino-pretty", options: { colorize: true } }
      : undefined,
  });
} catch {
  // Simple console fallback if pino is not installed
  const ts = () => new Date().toISOString();
  const fmt = (level, obj, msg) => {
    const extra = obj && typeof obj === "object" ? JSON.stringify(obj) : "";
    return `[${ts()}] ${level.toUpperCase()} ${msg ?? ""} ${extra}`;
  };
  logger = {
    info:  (obj, msg) => console.log(fmt("info",  obj, msg)),
    warn:  (obj, msg) => console.warn(fmt("warn",  obj, msg)),
    error: (obj, msg) => console.error(fmt("error", obj, msg)),
    debug: (obj, msg) => process.env.LOG_LEVEL === "debug" && console.log(fmt("debug", obj, msg)),
    fatal: (obj, msg) => console.error(fmt("fatal", obj, msg)),
    child: () => logger,
  };
}

module.exports = logger;
