/**
 * backend/src/services/mpesa.js
 *
 * Safaricom M-Pesa Daraja API integration.
 * Supports:
 *   - STK Push (Lipa Na M-Pesa Online) — prompt user to pay
 *   - C2B callback processing — receive payment confirmation
 *   - B2C (optional) — refunds
 *
 * Required env vars:
 *   MPESA_CONSUMER_KEY
 *   MPESA_CONSUMER_SECRET
 *   MPESA_SHORTCODE       e.g. "174379" (sandbox) or your Till/Paybill
 *   MPESA_PASSKEY         From Daraja portal STK push settings
 *   MPESA_CALLBACK_URL    Public URL e.g. "https://billing.yourisp.co.ke/api/mpesa/callback"
 *   MPESA_ENV             "sandbox" or "production" (default: sandbox)
 */

"use strict";

const fetch  = require("node-fetch");
const logger = require("../utils/logger");

const ENV        = process.env.MPESA_ENV ?? "sandbox";
const BASE_URL   = ENV === "production"
  ? "https://api.safaricom.co.ke"
  : "https://sandbox.safaricom.co.ke";

const SHORTCODE    = process.env.MPESA_SHORTCODE;
const PASSKEY      = process.env.MPESA_PASSKEY;
const CALLBACK_URL = process.env.MPESA_CALLBACK_URL;

// ── Auth token (cached) ───────────────────────────────────────────────────────
let cachedToken   = null;
let tokenExpiry   = 0;

async function getAccessToken() {
  if (cachedToken && Date.now() < tokenExpiry) return cachedToken;

  const creds  = Buffer.from(`${process.env.MPESA_CONSUMER_KEY}:${process.env.MPESA_CONSUMER_SECRET}`).toString("base64");
  const res    = await fetch(`${BASE_URL}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${creds}` },
  });
  const data   = await res.json();

  if (!data.access_token) throw new Error(`M-Pesa OAuth failed: ${JSON.stringify(data)}`);

  cachedToken = data.access_token;
  tokenExpiry = Date.now() + (parseInt(data.expires_in ?? "3600", 10) - 60) * 1000;
  return cachedToken;
}

// ── Password helper ───────────────────────────────────────────────────────────
function generatePassword() {
  const timestamp = new Date().toISOString().replace(/[^0-9]/g, "").slice(0, 14);
  const raw       = `${SHORTCODE}${PASSKEY}${timestamp}`;
  return {
    password:  Buffer.from(raw).toString("base64"),
    timestamp,
  };
}

// ── STK Push ─────────────────────────────────────────────────────────────────
/**
 * Initiate an STK push payment request.
 *
 * @param {object} opts
 * @param {string} opts.phone        E.164 format, e.g. "254712345678" (no +)
 * @param {number} opts.amount       Integer, minimum 1
 * @param {string} opts.accountRef   Subscriber username / invoice ref
 * @param {string} opts.description  e.g. "WiFi Package Renewal"
 * @returns {Promise<object>}  Daraja API response
 */
async function stkPush({ phone, amount, accountRef, description = "WiFi Package" }) {
  const token             = await getAccessToken();
  const { password, timestamp } = generatePassword();

  const payload = {
    BusinessShortCode: SHORTCODE,
    Password:          password,
    Timestamp:         timestamp,
    TransactionType:   "CustomerPayBillOnline",
    Amount:            Math.round(amount),
    PartyA:            phone,
    PartyB:            SHORTCODE,
    PhoneNumber:       phone,
    CallBackURL:       CALLBACK_URL,
    AccountReference:  accountRef.slice(0, 12), // max 12 chars
    TransactionDesc:   description.slice(0, 13), // max 13 chars
  };

  const res = await fetch(`${BASE_URL}/mpesa/stkpush/v1/processrequest`, {
    method:  "POST",
    headers: {
      Authorization:  `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  });

  const data = await res.json();
  logger.info({ data, phone, amount, accountRef }, "mpesa: STK push initiated");
  return data;
}

// ── STK Query ─────────────────────────────────────────────────────────────────
/**
 * Check the status of a pending STK push transaction.
 *
 * @param {string} checkoutRequestId  From the STK push response
 */
async function stkQuery(checkoutRequestId) {
  const token             = await getAccessToken();
  const { password, timestamp } = generatePassword();

  const res = await fetch(`${BASE_URL}/mpesa/stkpushquery/v1/query`, {
    method:  "POST",
    headers: {
      Authorization:  `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      BusinessShortCode: SHORTCODE,
      Password:          password,
      Timestamp:         timestamp,
      CheckoutRequestID: checkoutRequestId,
    }),
  });

  return res.json();
}

// ── Parse C2B / STK callback ──────────────────────────────────────────────────
/**
 * Parse the Daraja callback body into a normalized object.
 *
 * @param {object} body  Raw callback body from Safaricom
 * @returns {{ success: boolean, mpesaRef: string, amount: number, phone: string, accountRef: string }}
 */
function parseCallback(body) {
  const callback = body?.Body?.stkCallback ?? body;
  const success  = callback.ResultCode === 0;

  const items    = callback.CallbackMetadata?.Item ?? [];
  const get      = (name) => items.find((i) => i.Name === name)?.Value;

  return {
    success,
    resultCode:  callback.ResultCode,
    resultDesc:  callback.ResultDesc,
    mpesaRef:    get("MpesaReceiptNumber") ?? "",
    amount:      Number(get("Amount") ?? 0),
    phone:       String(get("PhoneNumber") ?? ""),
    accountRef:  get("AccountReference") ?? "",
    transDate:   get("TransactionDate") ?? null,
    checkoutRequestId: callback.CheckoutRequestID,
  };
}

module.exports = { stkPush, stkQuery, parseCallback };
