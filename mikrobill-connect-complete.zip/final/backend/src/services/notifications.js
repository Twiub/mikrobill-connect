/**
 * backend/src/services/notifications.js
 *
 * Notification delivery service.
 * Supports:
 *   - SMS via Africa's Talking (AT)
 *   - In-app push notifications stored in Supabase `notifications` table
 *
 * Set AFRICAS_TALKING_API_KEY and AFRICAS_TALKING_USERNAME env vars to enable SMS.
 * SMS silently degrades to log-only if credentials are missing.
 */

"use strict";

const { createClient } = require("@supabase/supabase-js");
const logger = require("../utils/logger");

// Supabase admin client (service role — bypasses RLS)
const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

// Africa's Talking SMS client (optional)
let AfricasTalking = null;
let smsClient      = null;

try {
  AfricasTalking = require("africastalking");
  if (process.env.AFRICAS_TALKING_API_KEY && process.env.AFRICAS_TALKING_USERNAME) {
    const at  = AfricasTalking({
      apiKey:   process.env.AFRICAS_TALKING_API_KEY,
      username: process.env.AFRICAS_TALKING_USERNAME,
    });
    smsClient = at.SMS;
    logger.info("notifications: Africa's Talking SMS enabled");
  }
} catch {
  logger.warn("notifications: africastalking not installed — SMS disabled");
}

// Get all super_admin phone numbers from the DB for alert routing
async function getAdminPhones() {
  const { data } = await supabase
    .from("profiles")
    .select("phone")
    .not("phone", "is", null);
  return (data ?? []).map((r) => r.phone).filter(Boolean);
}

/**
 * Send an SMS message.
 *
 * @param {string|string[]} to   E.164 phone number(s), e.g. "+254712345678"
 * @param {string}          message
 */
async function sendSms(to, message) {
  const recipients = Array.isArray(to) ? to : [to];

  if (!smsClient) {
    logger.warn({ recipients, message }, "notifications: SMS skipped (no AT credentials)");
    return;
  }

  try {
    const result = await smsClient.send({
      to:       recipients,
      message,
      from:     process.env.AFRICAS_TALKING_SENDER_ID ?? "WIFI-ISP",
    });
    logger.info({ result }, "notifications: SMS sent");
    return result;
  } catch (err) {
    logger.error({ err, recipients }, "notifications: SMS failed");
    throw err;
  }
}

/**
 * Create an in-app notification record in the database.
 *
 * @param {object} opts
 * @param {string} opts.subscriber_id  UUID of the subscriber
 * @param {string} opts.type           "info"|"warning"|"success"|"error"
 * @param {string} opts.title
 * @param {string} opts.message
 * @param {string} [opts.channel]      "push"|"sms"|"both" (default: "push")
 */
async function createNotification({ subscriber_id, type = "info", title, message, channel = "push" }) {
  const { error } = await supabase.from("notifications").insert({
    subscriber_id,
    type,
    title,
    message,
    channel,
    status: "sent",
    sent_at: new Date().toISOString(),
  });

  if (error) {
    logger.error({ error, subscriber_id }, "notifications: failed to insert notification");
    throw error;
  }
}

/**
 * Send an alert to all admin users (SMS + log).
 * Used by background monitoring jobs for high-priority alerts.
 *
 * @param {string} title
 * @param {string} message
 */
async function sendAdminAlert(title, message) {
  const text = `[${title}]\n${message}`;
  logger.warn({ title, message }, "notifications: ADMIN ALERT");

  try {
    const phones = await getAdminPhones();
    if (phones.length > 0) {
      await sendSms(phones, text);
    }
  } catch (err) {
    logger.error({ err }, "notifications: admin alert SMS failed");
  }
}

module.exports = {
  sendSms,
  sendAdminAlert,
  createNotification,
};
