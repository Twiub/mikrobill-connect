/**
 * backend/src/services/radiusdesk.js
 *
 * RadiusDesk REST API integration.
 * Handles AP management, client lookup, NAS registration, and CoA disconnects.
 * All requests include retry logic and structured error logging.
 */

"use strict";

const logger = require("../utils/logger");

const RADIUSDESK_URL   = process.env.RADIUSDESK_URL?.replace(/\/$/, ""); // e.g. http://radiusdesk.local
const RADIUSDESK_TOKEN = process.env.RADIUSDESK_API_TOKEN;
const TIMEOUT_MS       = 10_000;
const MAX_RETRIES      = 2;

if (!RADIUSDESK_URL || !RADIUSDESK_TOKEN) {
  logger.warn("RadiusDesk integration disabled: RADIUSDESK_URL or RADIUSDESK_API_TOKEN not set.");
}

// ---------------------------------------------------------------------------
// Internal fetch wrapper — adds auth, timeout, retry, structured logging
// ---------------------------------------------------------------------------
async function rdFetch(path, options = {}, attempt = 0) {
  const url = `${RADIUSDESK_URL}${path}`;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), TIMEOUT_MS);

  try {
    const res = await fetch(url, {
      ...options,
      signal: controller.signal,
      headers: {
        "Authorization": `Bearer ${RADIUSDESK_TOKEN}`,
        "Content-Type":  "application/json",
        ...(options.headers ?? {}),
      },
    });

    clearTimeout(timer);

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      throw new Error(`RadiusDesk HTTP ${res.status}: ${body}`);
    }

    return res.json();
  } catch (err) {
    clearTimeout(timer);

    if (attempt < MAX_RETRIES && !err.message.includes("HTTP 4")) {
      const delay = 500 * (attempt + 1);
      logger.warn(`RadiusDesk fetch retry ${attempt + 1}/${MAX_RETRIES} for ${path} in ${delay}ms`);
      await new Promise(r => setTimeout(r, delay));
      return rdFetch(path, options, attempt + 1);
    }

    logger.error({ err, path }, "RadiusDesk request failed");
    throw err;
  }
}

// ---------------------------------------------------------------------------
// Access Points
// ---------------------------------------------------------------------------

/**
 * Retrieve all access points registered in RadiusDesk.
 * @returns {Promise<Array>}
 */
async function getAccessPoints() {
  const data = await rdFetch("/cake2/rd_cake/access_points/index.json");
  return Array.isArray(data?.data) ? data.data : [];
}

/**
 * Get clients currently connected to a specific AP.
 * @param {string} apMac  AP MAC address (colon-separated, e.g. "AA:BB:CC:DD:EE:FF")
 * @returns {Promise<Array>}
 */
async function getAPClients(apMac) {
  const encoded = encodeURIComponent(apMac);
  const data = await rdFetch(`/cake2/rd_cake/online_users/for_ap/${encoded}.json`);
  return Array.isArray(data?.data) ? data.data : [];
}

/**
 * Fetch all APs enriched with live active client counts.
 * @returns {Promise<Array<{mac, name, lat, lng, online, activeClients, lastContact, model, firmware}>>}
 */
async function getEnrichedAccessPoints() {
  const aps = await getAccessPoints();

  const enriched = await Promise.allSettled(
    aps.map(async (ap) => {
      let activeClients = 0;
      try {
        const clients = await getAPClients(ap.mac);
        activeClients = clients.length;
      } catch {
        // non-fatal — keep AP but with 0 clients
      }

      const lastContactMs = ap.last_contact
        ? new Date(ap.last_contact).getTime()
        : 0;

      return {
        mac:           ap.mac,
        name:          ap.name ?? ap.mac,
        lat:           ap.lat    ? parseFloat(ap.lat)    : null,
        lng:           ap.lng    ? parseFloat(ap.lng)    : null,
        online:        lastContactMs > Date.now() - 120_000, // seen in last 2 min
        activeClients,
        lastContact:   ap.last_contact ?? null,
        model:         ap.model    ?? null,
        firmware:      ap.firmware ?? null,
      };
    })
  );

  return enriched
    .filter(r => r.status === "fulfilled")
    .map(r => r.value);
}

// ---------------------------------------------------------------------------
// NAS Management
// ---------------------------------------------------------------------------

/**
 * Register a new MikroTik router as a NAS in RadiusDesk.
 * Called automatically when a new router is added via the admin panel.
 *
 * @param {string} nasIp     Router IP address
 * @param {string} nasSecret RADIUS shared secret
 * @param {string} nasName   Human-readable name
 * @returns {Promise<object>}
 */
async function registerNAS(nasIp, nasSecret, nasName) {
  return rdFetch("/cake2/rd_cake/nas/add.json", {
    method: "POST",
    body: JSON.stringify({
      ipaddr:    nasIp,
      secret:    nasSecret,
      shortname: nasName,
      type:      "mikrotik",
    }),
  });
}

/**
 * Delete a NAS entry by router IP (called when a router is removed).
 * @param {string} nasIp
 */
async function deleteNAS(nasIp) {
  return rdFetch("/cake2/rd_cake/nas/delete_by_ip.json", {
    method: "POST",
    body: JSON.stringify({ ipaddr: nasIp }),
  });
}

// ---------------------------------------------------------------------------
// Session Management — CoA Disconnect
// ---------------------------------------------------------------------------

/**
 * Disconnect a user session via RadiusDesk CoA (Change of Authorization).
 * RadiusDesk sends a Disconnect-Request packet to the NAS.
 *
 * @param {string} username  RADIUS username to disconnect
 * @returns {Promise<object>}
 */
async function disconnectUser(username) {
  return rdFetch("/cake2/rd_cake/online_users/disconnect.json", {
    method: "POST",
    body: JSON.stringify({ username }),
  });
}

/**
 * Get all currently online users across all APs.
 * @returns {Promise<Array>}
 */
async function getOnlineUsers() {
  const data = await rdFetch("/cake2/rd_cake/online_users/index.json");
  return Array.isArray(data?.data) ? data.data : [];
}

// ---------------------------------------------------------------------------
// Health Check
// ---------------------------------------------------------------------------

/**
 * Check if RadiusDesk is reachable.
 * Returns { online: boolean, latencyMs: number }
 */
async function healthCheck() {
  const start = Date.now();
  try {
    await rdFetch("/cake2/rd_cake/access_points/index.json");
    return { online: true, latencyMs: Date.now() - start };
  } catch {
    return { online: false, latencyMs: Date.now() - start };
  }
}

module.exports = {
  getAccessPoints,
  getAPClients,
  getEnrichedAccessPoints,
  registerNAS,
  deleteNAS,
  disconnectUser,
  getOnlineUsers,
  healthCheck,
};
