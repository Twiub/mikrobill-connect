/**
 * backend/src/services/mikrotik.js
 *
 * MikroTik RouterOS API client.
 *
 * Uses the `node-routeros` library (RouterOS API protocol).
 * Each router record in the DB stores: ip_address, api_port, api_username, api_password (encrypted).
 *
 * Usage:
 *   const { getMikrotikConnection } = require("./mikrotik");
 *   const conn = await getMikrotikConnection(routerId);
 *   const pools = await conn.write("/ip/pool/print", ["=.proplist=name,ranges"]);
 *   conn.close();
 */

"use strict";

const { RouterOSAPI } = require("node-routeros");
const db     = require("../db");
const logger = require("../utils/logger");
const crypto = require("crypto");

// ── Encryption helpers ────────────────────────────────────────────────────────
// Router API passwords are stored AES-256-GCM encrypted in the DB.
// Key is derived from MIKROTIK_ENCRYPTION_KEY env variable.
// If the env var is not set, passwords are stored/read as plain text
// (acceptable for local/dev environments but NOT recommended for production).

const ENC_KEY_HEX = process.env.MIKROTIK_ENCRYPTION_KEY ?? "";
const ALGORITHM   = "aes-256-gcm";

function encryptPassword(plain) {
  if (!ENC_KEY_HEX) return plain; // passthrough if no key set
  const key   = Buffer.from(ENC_KEY_HEX, "hex");
  const iv    = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  const enc   = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  const tag   = cipher.getAuthTag();
  return [iv.toString("hex"), enc.toString("hex"), tag.toString("hex")].join(":");
}

function decryptPassword(stored) {
  if (!ENC_KEY_HEX || !stored.includes(":")) return stored; // plain text fallback
  const [ivHex, encHex, tagHex] = stored.split(":");
  const key    = Buffer.from(ENC_KEY_HEX, "hex");
  const iv     = Buffer.from(ivHex,  "hex");
  const enc    = Buffer.from(encHex, "hex");
  const tag    = Buffer.from(tagHex, "hex");
  const decipher = crypto.createDecipheriv(ALGORITHM, key, iv);
  decipher.setAuthTag(tag);
  return decipher.update(enc) + decipher.final("utf8");
}

// ── Connection pool ───────────────────────────────────────────────────────────
// Keep one persistent connection per router to avoid repeated TCP handshakes.
// Connections are validated before use and re-created if they have dropped.

const connectionPool = new Map(); // routerId → RouterOSAPI instance

async function createConnection(router) {
  const password = decryptPassword(router.api_password);

  const conn = new RouterOSAPI({
    host:     router.ip_address,
    port:     router.api_port ?? 8728,
    user:     router.api_username,
    password,
    timeout:  15,             // seconds
    keepalive: true,
  });

  await conn.connect();

  logger.info(
    { routerId: router.id, host: router.ip_address },
    "mikrotik: connected"
  );

  // Auto-remove from pool on disconnect
  conn.on("close", () => {
    connectionPool.delete(router.id);
    logger.warn({ routerId: router.id }, "mikrotik: connection closed");
  });

  conn.on("error", (err) => {
    connectionPool.delete(router.id);
    logger.error({ err, routerId: router.id }, "mikrotik: connection error");
  });

  return conn;
}

/**
 * Get (or create) a MikroTik API connection for the given router DB id.
 * Fetches router credentials from the database.
 *
 * @param {number|string} routerId
 * @returns {Promise<RouterOSAPI>}
 */
async function getMikrotikConnection(routerId) {
  // Check pool first
  const existing = connectionPool.get(routerId);
  if (existing?.connected) {
    return existing;
  }

  // Load router credentials from DB
  const { rows } = await db.query(
    `SELECT id, name, ip_address, api_port, api_username, api_password
     FROM   routers
     WHERE  id = $1`,
    [routerId]
  );

  if (!rows.length) {
    throw new Error(`Router ${routerId} not found in database`);
  }

  const router = rows[0];
  const conn = await createConnection(router);
  connectionPool.set(routerId, conn);
  return conn;
}

/**
 * Execute a MikroTik API command on a specific router, creating a fresh
 * connection. Used for one-off commands (e.g. CoA disconnect).
 *
 * @param {number} routerId
 * @param {string} command     e.g. "/ip/hotspot/active/remove"
 * @param {string[]} params    e.g. ["=.id=*1"]
 * @returns {Promise<any[]>}
 */
async function executeCommand(routerId, command, params = []) {
  const conn = await getMikrotikConnection(routerId);
  return conn.write(command, params);
}

/**
 * Disconnect a hotspot or PPPoE session by username.
 * Attempts on all provided router IDs until the session is found.
 *
 * @param {number[]} routerIds
 * @param {string}   username
 * @returns {Promise<boolean>}  true if session was found and removed
 */
async function disconnectSession(routerIds, username) {
  for (const routerId of routerIds) {
    try {
      const conn = await getMikrotikConnection(routerId);

      // Try PPPoE active sessions
      const pppoe = await conn.write("/ppp/active/print", [
        `?name=${username}`,
        "=.proplist=.id,name",
      ]);
      if (pppoe.length > 0) {
        await conn.write("/ppp/active/remove", [`=.id=${pppoe[0][".id"]}`]);
        logger.info({ username, routerId }, "mikrotik: disconnected PPPoE session");
        return true;
      }

      // Try Hotspot active sessions
      const hs = await conn.write("/ip/hotspot/active/print", [
        `?user=${username}`,
        "=.proplist=.id,user",
      ]);
      if (hs.length > 0) {
        await conn.write("/ip/hotspot/active/remove", [`=.id=${hs[0][".id"]}`]);
        logger.info({ username, routerId }, "mikrotik: disconnected hotspot session");
        return true;
      }

    } catch (err) {
      logger.warn({ err, routerId, username }, "mikrotik: disconnect attempt failed");
    }
  }

  logger.warn({ username }, "mikrotik: session not found on any router");
  return false;
}

/**
 * Apply a PPPoE or hotspot profile change (e.g. when package changes or user
 * is suspended/activated). Disconnects the active session so the router
 * will reconnect and pick up the new profile via RADIUS.
 *
 * @param {number[]} routerIds
 * @param {string}   username
 */
async function applyProfileChange(routerIds, username) {
  return disconnectSession(routerIds, username);
}

/**
 * Add a static DHCP lease (for IP/MAC binding).
 *
 * @param {number} routerId
 * @param {object} params
 * @param {string} params.mac
 * @param {string} params.ip
 * @param {string} params.comment
 */
async function addDhcpLease(routerId, { mac, ip, comment = "" }) {
  const conn = await getMikrotikConnection(routerId);
  return conn.write("/ip/dhcp-server/lease/add", [
    `=mac-address=${mac}`,
    `=address=${ip}`,
    `=comment=${comment}`,
    "=always-broadcast=yes",
  ]);
}

/**
 * Remove a static DHCP lease by MAC address.
 */
async function removeDhcpLease(routerId, mac) {
  const conn = await getMikrotikConnection(routerId);
  const leases = await conn.write("/ip/dhcp-server/lease/print", [
    `?mac-address=${mac}`,
    "=.proplist=.id",
  ]);
  if (!leases.length) return false;
  await conn.write("/ip/dhcp-server/lease/remove", [`=.id=${leases[0][".id"]}`]);
  return true;
}

/**
 * Add an IP to the "allowed-tvs" address-list (TV binding feature).
 * The address-list is used in a firewall rule to allow the TV without a portal login.
 *
 * @param {number} routerId
 * @param {string} ip
 * @param {string} comment e.g. subscriber username
 */
async function addTvBinding(routerId, ip, comment = "TV binding") {
  const conn = await getMikrotikConnection(routerId);
  return conn.write("/ip/firewall/address-list/add", [
    "=list=allowed-tvs",
    `=address=${ip}`,
    `=comment=${comment}`,
  ]);
}

/**
 * Remove a TV binding by IP address.
 */
async function removeTvBinding(routerId, ip) {
  const conn = await getMikrotikConnection(routerId);
  const entries = await conn.write("/ip/firewall/address-list/print", [
    "?list=allowed-tvs",
    `?address=${ip}`,
    "=.proplist=.id",
  ]);
  if (!entries.length) return false;
  await conn.write("/ip/firewall/address-list/remove", [`=.id=${entries[0][".id"]}`]);
  return true;
}

/**
 * Generate the RouterOS script that sets up the MikroTik for this billing system.
 * Returns a RouterOS script string that can be run via /system/script or
 * pasted into the terminal.
 *
 * Configures:
 *   - RADIUS client pointing to this billing server
 *   - PPPoE server with RADIUS auth
 *   - Hotspot server with RADIUS auth
 *   - DHCP server (basic)
 *   - Queue tree for CAKE QoS (RouterOS v7)
 *   - TTL mangle rules for tethering detection
 *   - Bandwidth schedule support via RADIUS attributes
 *
 * @param {object} cfg
 * @param {string} cfg.radiusHost      IP of the billing/RADIUS server
 * @param {string} cfg.radiusSecret    Shared secret
 * @param {string} cfg.wanInterface    e.g. "ether1"
 * @param {string} cfg.lanInterface    e.g. "bridge1"
 * @param {string} cfg.dhcpPool        e.g. "10.10.0.1-10.10.15.254"
 * @param {string} cfg.hotspotInterface e.g. "bridge1"
 * @param {string} cfg.wanBandwidthMbps e.g. "100" (Mbps)
 * @returns {string}
 */
function generateSetupScript(cfg) {
  const {
    radiusHost,
    radiusSecret,
    wanInterface     = "ether1",
    lanInterface     = "bridge1",
    dhcpPool         = "192.168.88.10-192.168.88.254",
    hotspotInterface = "bridge1",
    wanBandwidthMbps = "100",
  } = cfg;

  return `# ================================================================
# Mikrobill Connect — MikroTik RouterOS Setup Script
# Generated: ${new Date().toISOString()}
# 
# Run this in the RouterOS terminal or via /system/script
# Tested on RouterOS v7.x (CHR, hAP, CCR, RB series)
# ================================================================

# ── 1. RADIUS Client ─────────────────────────────────────────────
/radius remove [find]
/radius add \\
  address=${radiusHost} \\
  secret="${radiusSecret}" \\
  service=ppp,hotspot \\
  authentication-port=1812 \\
  accounting-port=1813 \\
  timeout=3s \\
  comment="Mikrobill RADIUS"

/radius incoming set accept=yes port=3799

# ── 2. PPPoE Server ──────────────────────────────────────────────
# Profile with RADIUS – actual speeds come from RADIUS attributes
/ppp profile add \\
  name=mikrobill-pppoe \\
  use-radius=yes \\
  change-tcp-mss=yes \\
  only-one=yes \\
  comment="Mikrobill PPPoE"

/interface pppoe-server server add \\
  interface=${wanInterface} \\
  service-name=mikrobill \\
  authentication=mschap2 \\
  default-profile=mikrobill-pppoe \\
  one-session-per-host=yes \\
  max-sessions=1024 \\
  disabled=no \\
  comment="Mikrobill PPPoE"

# ── 3. Hotspot Server ────────────────────────────────────────────
/ip hotspot profile add \\
  name=mikrobill-hotspot \\
  use-radius=yes \\
  radius-accounting=yes \\
  nas-port-type=wireless-802.11 \\
  hotspot-address=192.168.88.1 \\
  login-by=http-chap,cookie \\
  comment="Mikrobill Hotspot"

/ip hotspot add \\
  name=hotspot1 \\
  interface=${hotspotInterface} \\
  profile=mikrobill-hotspot \\
  addresses-per-mac=2 \\
  disabled=no

# ── 4. DHCP Server & Pool ────────────────────────────────────────
/ip pool add name=dhcp-pool ranges=${dhcpPool}
/ip dhcp-server add \\
  name=dhcp1 \\
  interface=${lanInterface} \\
  address-pool=dhcp-pool \\
  lease-time=1d \\
  disabled=no
/ip dhcp-server network add \\
  address=${dhcpPool.split(".").slice(0,3).join(".")}.0/24 \\
  gateway=192.168.88.1 \\
  dns-server=8.8.8.8,1.1.1.1

# ── 5. CAKE QoS — RouterOS v7 ────────────────────────────────────
# Top-level WAN shaper — set to your upstream bandwidth
/queue tree add \\
  name=wan-cake \\
  parent=global \\
  packet-mark=all \\
  queue=cake \\
  max-limit=${wanBandwidthMbps}M \\
  comment="WAN CAKE shaper"

# Ingress shaping (download) — uses IFB interface trick
/queue tree add \\
  name=cake-ingress \\
  parent=global \\
  packet-mark=all \\
  queue=cake \\
  max-limit=${wanBandwidthMbps}M \\
  comment="Ingress CAKE"

# ── 6. TTL Mangle Rules — Tethering Detection ────────────────────
# Devices tethered through a mobile hotspot have TTL=63 or TTL=127
# (phone decrements TTL by 1 before forwarding)
/ip firewall mangle add \\
  chain=prerouting \\
  in-interface=${lanInterface} \\
  ttl=63 \\
  action=add-src-to-address-list \\
  address-list=tethered-devices \\
  address-list-timeout=10m \\
  comment="TTL 63 tether detection (Android)"

/ip firewall mangle add \\
  chain=prerouting \\
  in-interface=${lanInterface} \\
  ttl=127 \\
  action=add-src-to-address-list \\
  address-list=tethered-devices \\
  address-list-timeout=10m \\
  comment="TTL 127 tether detection (iOS)"

/ip firewall mangle add \\
  chain=prerouting \\
  in-interface=${lanInterface} \\
  ttl=64 \\
  action=passthrough \\
  comment="Normal TTL passthrough (not tethered)"

# ── 7. Firewall — Allow TV list ──────────────────────────────────
# TVs that are bound via the user portal bypass captive portal
/ip firewall address-list add \\
  list=allowed-tvs \\
  address=0.0.0.0 \\
  comment="Placeholder — managed by billing system" \\
  disabled=yes

/ip firewall filter add \\
  chain=forward \\
  src-address-list=allowed-tvs \\
  action=accept \\
  place-before=0 \\
  comment="Allow bound TV devices"

# ── 8. RADIUS Accounting Interim Updates ─────────────────────────
/ppp profile set mikrobill-pppoe interim-update=1m

# ── 9. Scheduler — Auto-reboot on high CPU (optional safety net) ─
/system scheduler add \\
  name=watchdog \\
  interval=5m \\
  on-event=":local cpu [/system resource get cpu-load]; :if (\\$cpu > 95) do={/system reboot}" \\
  comment="CPU watchdog"

:log info "Mikrobill setup script complete"
:put "Done! Router is ready for Mikrobill Connect."
`;
}

/**
 * Generate a per-package queue tree entry.
 * Called when a new package is created to provision queue rules.
 *
 * @param {string} packageName  e.g. "home-10mbps"
 * @param {string} speedDown    e.g. "10M"
 * @param {string} speedUp      e.g. "5M"
 * @param {string} burstDown    e.g. "20M" (optional)
 * @param {string} burstUp      e.g. "10M" (optional)
 * @param {number} burstTime    seconds (optional)
 * @returns {string}  RouterOS script snippet
 */
function generatePackageQueueScript({ packageName, speedDown, speedUp, burstDown, burstUp, burstTime }) {
  const profileName = packageName.toLowerCase().replace(/\s+/g, "-");
  let script = `
# Package: ${packageName}
/queue type add name=${profileName} kind=pcq pcq-rate=${speedDown} pcq-classifier=dst-address
/queue simple add name=${profileName}-down max-limit=${speedDown} queue=${profileName}/${profileName}
`;
  if (burstDown && burstUp && burstTime) {
    script += `/queue simple set [find name=${profileName}-down] burst-limit=${burstDown}/${burstUp} burst-threshold=${speedDown}/${speedUp} burst-time=${burstTime}s\n`;
  }
  return script;
}

module.exports = {
  getMikrotikConnection,
  executeCommand,
  disconnectSession,
  applyProfileChange,
  addDhcpLease,
  removeDhcpLease,
  addTvBinding,
  removeTvBinding,
  generateSetupScript,
  generatePackageQueueScript,
  encryptPassword,
  decryptPassword,
};
