/**
 * backend/src/routes/portal.js
 *
 * User-facing portal API routes (no admin role required, but rate-limited):
 *   POST /api/portal/login        — Hotspot / portal login (bcrypt password check)
 *   POST /api/portal/location     — Report subscriber GPS location
 *   GET  /api/portal/network-check — Check if request is from ISP network
 */

"use strict";

const express = require("express");
const bcrypt  = require("bcryptjs");
const crypto  = require("crypto");
const { body, validationResult } = require("express-validator");
const { createClient } = require("@supabase/supabase-js");
const db     = require("../db");
const logger = require("../utils/logger");

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

const router = express.Router();

// ---------------------------------------------------------------------------
// POST /api/portal/login
// Verifies subscriber phone + password using bcrypt (safe in production).
// Returns a session token on success.
// ---------------------------------------------------------------------------
router.post(
  "/portal/login",
  [
    body("phone").trim().notEmpty().withMessage("Phone required"),
    body("password").notEmpty().withMessage("Password required"),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ success: false, error: "Phone and password are required." });
    }

    const { phone, password } = req.body;

    try {
      // Fetch subscriber including their hashed password
      const { rows } = await db.query(
        `SELECT s.*, p.name AS package_name, p.speed_down, p.max_devices, p.duration_days
         FROM   subscribers s
         JOIN   packages p ON p.id = s.package_id
         WHERE  s.phone = $1
           AND  s.status = 'active'
         LIMIT  1`,
        [phone]
      );

      if (!rows.length) {
        return res.status(401).json({ success: false, error: "Account not found or inactive." });
      }

      const sub = rows[0];

      // Check password:
      //   1. Try bcrypt hash (recommended — set when subscriber is created/password is changed)
      //   2. Fall back to plain text comparison for legacy records (migrate these over time)
      let passwordValid = false;

      if (sub.password_hash) {
        passwordValid = await bcrypt.compare(password, sub.password_hash);
      } else if (sub.pppoe_password) {
        // Legacy plain text — compare and then hash for future logins
        passwordValid = sub.pppoe_password === password || sub.username === password;
        if (passwordValid) {
          // Upgrade to bcrypt hash
          const hash = await bcrypt.hash(password, 12);
          await db.query("UPDATE subscribers SET password_hash = $1 WHERE id = $2", [hash, sub.id]);
        }
      }

      if (!passwordValid) {
        return res.status(401).json({ success: false, error: "Incorrect password." });
      }

      // Generate a secure session token
      const token     = crypto.randomBytes(32).toString("hex");
      const expiresAt = new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString();

      await db.query(
        `INSERT INTO portal_sessions (subscriber_id, token, user_agent, expires_at)
         VALUES ($1, $2, $3, $4)`,
        [sub.id, token, req.headers["user-agent"] ?? "unknown", expiresAt]
      );

      // Return subscriber (excluding sensitive fields)
      const { password_hash, pppoe_password, ...safeSub } = sub;

      logger.info({ subscriberId: sub.id, phone: sub.phone }, "portal: login successful");
      res.json({ success: true, token, subscriber: safeSub });

    } catch (err) {
      logger.error({ err, phone }, "portal: login error");
      res.status(500).json({ success: false, error: "Login failed. Please try again." });
    }
  }
);

module.exports = router;
