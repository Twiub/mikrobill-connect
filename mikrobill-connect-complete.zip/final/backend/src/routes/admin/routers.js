/**
 * backend/src/routes/admin/routers.js
 *
 * Admin routes for MikroTik router management.
 * When a router is added it is automatically registered in:
 *   1. routers table (billing DB)
 *   2. nas table (FreeRADIUS NAS clients)
 *   3. RadiusDesk (via API)
 *   4. isp_ip_ranges (pool CIDRs linked to this router)
 *
 * When a router is deleted, NAS + RadiusDesk entries are cleaned up.
 */

"use strict";

const express    = require("express");
const { body, param, validationResult } = require("express-validator");
const db         = require("../../db");
const radiusdesk = require("../../services/radiusdesk");
const { requireRole } = require("../../middleware/auth");
const logger     = require("../../utils/logger");

const router = express.Router();

// ---------------------------------------------------------------------------
// POST /api/admin/routers  — add a new MikroTik router
// ---------------------------------------------------------------------------
router.post(
  "/",
  requireRole(["super_admin"]),
  [
    body("name").trim().notEmpty().withMessage("Name is required"),
    body("ip").isIP().withMessage("Valid IP required"),
    body("secret").isLength({ min: 8 }).withMessage("RADIUS secret must be ≥ 8 chars"),
    body("model").optional().trim(),
    body("lat").optional().isFloat({ min: -90,  max: 90  }),
    body("lng").optional().isFloat({ min: -180, max: 180 }),
    body("pool_cidrs").optional().isArray(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

    const { name, ip, secret, model, lat, lng, pool_cidrs = [] } = req.body;

    const client = await db.connect(); // transaction
    try {
      await client.query("BEGIN");

      // 1. Insert into routers table
      const { rows } = await client.query(
        `INSERT INTO routers
           (name, ip_address, radius_secret, model, lat, lng, status)
         VALUES ($1, $2, $3, $4, $5, $6, 'offline')
         RETURNING *`,
        [name, ip, secret, model ?? null, lat ?? null, lng ?? null]
      );
      const newRouter = rows[0];

      // 2. Register as FreeRADIUS NAS client
      await client.query(
        `INSERT INTO nas (nasname, shortname, type, secret, router_id)
         VALUES ($1::inet, $2, 'mikrotik', $3, $4)
         ON CONFLICT (nasname) DO UPDATE SET
           shortname = EXCLUDED.shortname,
           secret    = EXCLUDED.secret,
           router_id = EXCLUDED.router_id`,
        [ip, name, secret, newRouter.id]
      );

      // 3. Register pool CIDRs as ISP IP ranges
      for (const cidr of pool_cidrs) {
        await client.query(
          `INSERT INTO isp_ip_ranges (cidr, label, router_id)
           VALUES ($1::cidr, $2, $3)
           ON CONFLICT DO NOTHING`,
          [cidr, `${name} pool`, newRouter.id]
        );
      }

      await client.query("COMMIT");

      // 4. Register in RadiusDesk (outside transaction — non-fatal if RD is down)
      radiusdesk.registerNAS(ip, secret, name).catch(err =>
        logger.warn({ err, routerName: name }, "routers: RadiusDesk NAS registration failed (non-fatal)")
      );

      logger.info({ routerId: newRouter.id, name }, "routers: new router added");
      res.status(201).json({ success: true, router: newRouter });

    } catch (err) {
      await client.query("ROLLBACK");
      logger.error({ err }, "routers: add failed");
      res.status(500).json({ success: false, error: "Failed to add router" });
    } finally {
      client.release();
    }
  }
);

// ---------------------------------------------------------------------------
// DELETE /api/admin/routers/:id
// ---------------------------------------------------------------------------
router.delete(
  "/:id",
  requireRole(["super_admin"]),
  [param("id").isInt({ min: 1 })],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

    const routerId = parseInt(req.params.id, 10);

    try {
      const { rows } = await db.query(
        "SELECT ip_address, name FROM routers WHERE id = $1",
        [routerId]
      );
      if (!rows.length) return res.status(404).json({ error: "Router not found" });

      const { ip_address, name } = rows[0];

      // Remove from billing DB (cascades to nas via FK)
      await db.query("DELETE FROM routers WHERE id = $1", [routerId]);

      // Remove from RadiusDesk (non-fatal)
      radiusdesk.deleteNAS(ip_address).catch(err =>
        logger.warn({ err, name }, "routers: RadiusDesk NAS delete failed (non-fatal)")
      );

      logger.info({ routerId, name }, "routers: router deleted");
      res.json({ success: true });

    } catch (err) {
      logger.error({ err, routerId }, "routers: delete failed");
      res.status(500).json({ success: false, error: "Failed to delete router" });
    }
  }
);

// ---------------------------------------------------------------------------
// GET /api/admin/routers  — list all routers with NAS + AP counts
// ---------------------------------------------------------------------------
router.get(
  "/",
  requireRole(["super_admin", "network_admin"]),
  async (_req, res) => {
    try {
      const { rows } = await db.query(
        `SELECT r.*,
                n.nasname IS NOT NULL           AS nas_registered,
                COUNT(DISTINCT ap.mac)::int      AS ap_count,
                COALESCE(SUM(ap.active_clients), 0)::int AS total_ap_clients
         FROM   routers r
         LEFT   JOIN nas n          ON n.router_id = r.id
         LEFT   JOIN radiusdesk_aps ap ON ap.router_id = r.id
         GROUP  BY r.id, n.nasname
         ORDER  BY r.name`
      );
      res.json({ success: true, routers: rows });
    } catch (err) {
      logger.error({ err }, "routers: list failed");
      res.status(500).json({ success: false, routers: [] });
    }
  }
);

module.exports = router;
