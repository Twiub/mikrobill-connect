/**
 * backend/src/routes/admin/mikrotik.js
 *
 * Admin routes for MikroTik operations:
 *   POST /api/admin/mikrotik/setup-script     — Generate RouterOS setup script
 *   POST /api/admin/mikrotik/disconnect       — Disconnect an active session
 *   POST /api/admin/mikrotik/apply-profile    — Apply profile change (after package update)
 *   POST /api/admin/mikrotik/tv-bind          — Add TV IP to allowed-tvs address-list
 *   DELETE /api/admin/mikrotik/tv-bind        — Remove TV IP binding
 *   GET  /api/admin/mikrotik/sessions/:routerId — List active sessions on a specific router
 */

"use strict";

const express = require("express");
const { body, param, validationResult } = require("express-validator");
const {
  getMikrotikConnection,
  disconnectSession,
  generateSetupScript,
  generatePackageQueueScript,
  addTvBinding,
  removeTvBinding,
} = require("../../services/mikrotik");
const { requireRole } = require("../../middleware/auth");
const db     = require("../../db");
const logger = require("../../utils/logger");

const router = express.Router();

// ---------------------------------------------------------------------------
// POST /api/admin/mikrotik/setup-script
// Generate a RouterOS setup script for a new router
// ---------------------------------------------------------------------------
router.post(
  "/setup-script",
  requireRole(["super_admin", "network_admin"]),
  [
    body("radiusHost").isIP().withMessage("Valid RADIUS server IP required"),
    body("radiusSecret").isLength({ min: 8 }).withMessage("RADIUS secret must be ≥ 8 chars"),
    body("wanInterface").optional().trim(),
    body("lanInterface").optional().trim(),
    body("wanBandwidthMbps").optional().isInt({ min: 1, max: 100000 }),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

    const script = generateSetupScript(req.body);
    res.json({ success: true, script });
  }
);

// ---------------------------------------------------------------------------
// POST /api/admin/mikrotik/package-script
// Generate a RouterOS queue script for a specific package
// ---------------------------------------------------------------------------
router.post(
  "/package-script",
  requireRole(["super_admin", "network_admin"]),
  [
    body("packageName").trim().notEmpty(),
    body("speedDown").trim().notEmpty(),
    body("speedUp").trim().notEmpty(),
  ],
  (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

    const script = generatePackageQueueScript(req.body);
    res.json({ success: true, script });
  }
);

// ---------------------------------------------------------------------------
// POST /api/admin/mikrotik/disconnect
// Disconnect an active subscriber session
// ---------------------------------------------------------------------------
router.post(
  "/disconnect",
  requireRole(["super_admin", "network_admin", "support_agent"]),
  [
    body("username").trim().notEmpty().withMessage("username required"),
    body("routerIds").isArray({ min: 1 }).withMessage("routerIds array required"),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

    const { username, routerIds } = req.body;

    try {
      const success = await disconnectSession(routerIds, username);
      if (success) {
        // Mark session inactive in DB
        await db.query(
          "UPDATE active_sessions SET status = 'terminated', ended_at = NOW() WHERE username = $1 AND status = 'active'",
          [username]
        );
      }
      res.json({ success, message: success ? "Session terminated" : "Session not found on specified routers" });
    } catch (err) {
      logger.error({ err, username }, "mikrotik: disconnect failed");
      res.status(500).json({ success: false, error: "Failed to disconnect session" });
    }
  }
);

// ---------------------------------------------------------------------------
// GET /api/admin/mikrotik/sessions/:routerId
// List active sessions (PPPoE + hotspot) on a specific router
// ---------------------------------------------------------------------------
router.get(
  "/sessions/:routerId",
  requireRole(["super_admin", "network_admin"]),
  [param("routerId").isInt({ min: 1 })],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

    const routerId = parseInt(req.params.routerId, 10);

    try {
      const conn = await getMikrotikConnection(routerId);

      // Fetch PPPoE active sessions
      const pppoe = await conn.write("/ppp/active/print", [
        "=.proplist=.id,name,address,uptime,bytes-in,bytes-out,caller-id",
      ]);

      // Fetch Hotspot active sessions
      const hotspot = await conn.write("/ip/hotspot/active/print", [
        "=.proplist=.id,user,address,mac-address,uptime,bytes-in,bytes-out",
      ]);

      res.json({
        success: true,
        pppoe:   pppoe.map((s) => ({ ...s, type: "pppoe" })),
        hotspot: hotspot.map((s) => ({ ...s, type: "hotspot" })),
        total:   pppoe.length + hotspot.length,
      });
    } catch (err) {
      logger.error({ err, routerId }, "mikrotik: sessions fetch failed");
      res.status(500).json({ success: false, error: "Failed to fetch sessions from router" });
    }
  }
);

// ---------------------------------------------------------------------------
// POST /api/admin/mikrotik/tv-bind
// Add a TV IP to the allowed-tvs firewall address-list
// ---------------------------------------------------------------------------
router.post(
  "/tv-bind",
  requireRole(["super_admin", "support_agent"]),
  [
    body("routerId").isInt({ min: 1 }),
    body("ip").isIP().withMessage("Valid IP address required"),
    body("comment").optional().trim(),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

    const { routerId, ip, comment } = req.body;
    try {
      await addTvBinding(routerId, ip, comment);
      res.json({ success: true });
    } catch (err) {
      logger.error({ err, ip }, "mikrotik: tv-bind failed");
      res.status(500).json({ success: false, error: "Failed to bind TV" });
    }
  }
);

// ---------------------------------------------------------------------------
// DELETE /api/admin/mikrotik/tv-bind
// ---------------------------------------------------------------------------
router.delete(
  "/tv-bind",
  requireRole(["super_admin", "support_agent"]),
  [body("routerId").isInt({ min: 1 }), body("ip").isIP()],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

    const { routerId, ip } = req.body;
    try {
      const removed = await removeTvBinding(routerId, ip);
      res.json({ success: removed });
    } catch (err) {
      logger.error({ err, ip }, "mikrotik: tv-bind remove failed");
      res.status(500).json({ success: false, error: "Failed to remove TV binding" });
    }
  }
);

module.exports = router;
