/**
 * backend/src/routes/mpesa.js
 *
 * M-Pesa payment routes:
 *   POST /api/mpesa/stk-push     — Initiate STK push from portal or admin
 *   POST /api/mpesa/callback     — Daraja C2B / STK callback (no auth, Safaricom calls this)
 *   GET  /api/mpesa/status/:id   — Query STK push status
 */

"use strict";

const express = require("express");
const { body, param, validationResult } = require("express-validator");
const { stkPush, stkQuery, parseCallback } = require("../services/mpesa");
const { authenticateUser }                 = require("../middleware/auth");
const { disconnectSession }                = require("../services/mikrotik");
const db     = require("../db");
const logger = require("../utils/logger");

const router = express.Router();

// ---------------------------------------------------------------------------
// POST /api/mpesa/stk-push
// Initiates an STK push. Called from the User Portal.
// ---------------------------------------------------------------------------
router.post(
  "/stk-push",
  authenticateUser,
  [
    body("phone").matches(/^254\d{9}$/).withMessage("Phone must be in format 254XXXXXXXXX"),
    body("amount").isInt({ min: 1, max: 100000 }).withMessage("Amount must be 1–100000"),
    body("packageId").isUUID().withMessage("Valid package UUID required"),
    body("subscriberId").isUUID().withMessage("Valid subscriber UUID required"),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(422).json({ errors: errors.array() });

    const { phone, amount, packageId, subscriberId } = req.body;

    // Get subscriber username for account reference
    const { rows: sub } = await db.query(
      "SELECT username FROM subscribers WHERE id = $1",
      [subscriberId]
    );
    if (!sub.length) return res.status(404).json({ error: "Subscriber not found" });

    // Create pending transaction record
    const { rows: txn } = await db.query(
      `INSERT INTO transactions (subscriber_id, package_id, amount, status, payment_method, phone)
       VALUES ($1, $2, $3, 'pending', 'mpesa', $4)
       RETURNING id`,
      [subscriberId, packageId, amount, phone]
    );

    try {
      const data = await stkPush({
        phone,
        amount,
        accountRef:  sub[0].username,
        description: "WiFi Package",
      });

      if (data.ResponseCode !== "0") {
        await db.query("UPDATE transactions SET status = 'failed' WHERE id = $1", [txn[0].id]);
        return res.status(400).json({ success: false, message: data.ResponseDescription });
      }

      // Store CheckoutRequestID for later status queries
      await db.query(
        "UPDATE transactions SET mpesa_checkout_id = $1 WHERE id = $2",
        [data.CheckoutRequestID, txn[0].id]
      );

      res.json({
        success: true,
        message: data.CustomerMessage,
        transactionId: txn[0].id,
        checkoutRequestId: data.CheckoutRequestID,
      });

    } catch (err) {
      logger.error({ err, subscriberId }, "mpesa: stk-push failed");
      await db.query("UPDATE transactions SET status = 'failed' WHERE id = $1", [txn[0].id]);
      res.status(500).json({ success: false, error: "Payment initiation failed" });
    }
  }
);

// ---------------------------------------------------------------------------
// POST /api/mpesa/callback
// Safaricom POSTs here after payment — NO AUTH (public endpoint, validate by IP if needed)
// ---------------------------------------------------------------------------
router.post("/callback", async (req, res) => {
  // Acknowledge immediately to prevent Safaricom timeout
  res.json({ ResultCode: 0, ResultDesc: "Accepted" });

  const parsed = parseCallback(req.body);
  logger.info({ parsed }, "mpesa: callback received");

  if (!parsed.success) {
    logger.warn({ parsed }, "mpesa: payment failed or cancelled");
    // Update transaction status
    await db.query(
      "UPDATE transactions SET status = 'failed', mpesa_ref = $1 WHERE mpesa_checkout_id = $2",
      [parsed.mpesaRef || "FAILED", parsed.checkoutRequestId]
    ).catch((e) => logger.error({ e }, "mpesa: failed transaction update error"));
    return;
  }

  try {
    // Find the pending transaction
    const { rows: txn } = await db.query(
      "SELECT * FROM transactions WHERE mpesa_checkout_id = $1",
      [parsed.checkoutRequestId]
    );

    if (!txn.length) {
      // C2B direct payment — look up by account reference (subscriber username)
      const { rows: sub } = await db.query(
        "SELECT id, expires_at FROM subscribers WHERE username = $1",
        [parsed.accountRef]
      );
      if (!sub.length) {
        logger.warn({ parsed }, "mpesa: unknown subscriber for C2B payment");
        return;
      }
    }

    const transaction = txn[0] ?? {};
    const subscriberId = transaction.subscriber_id;

    // Mark transaction as successful
    await db.query(
      `UPDATE transactions
       SET status = 'success', mpesa_ref = $1, completed_at = NOW()
       WHERE mpesa_checkout_id = $2`,
      [parsed.mpesaRef, parsed.checkoutRequestId]
    );

    if (!subscriberId) return;

    // Get package details to extend subscription
    const { rows: pkgRows } = await db.query(
      "SELECT * FROM packages WHERE id = $1",
      [transaction.package_id]
    );
    const pkg = pkgRows[0];
    if (!pkg) return;

    // Extend subscriber expiry
    await db.query(
      `UPDATE subscribers
       SET expires_at    = NOW() + ($1 || ' days')::interval,
           status        = 'active',
           package_id    = $2,
           updated_at    = NOW()
       WHERE id = $3`,
      [pkg.duration_days, pkg.id, subscriberId]
    );

    // Disconnect existing session so router re-authenticates with new profile
    const { rows: routers } = await db.query("SELECT id FROM routers WHERE status = 'online'");
    const routerIds = routers.map((r) => r.id);

    const { rows: subRows } = await db.query("SELECT username FROM subscribers WHERE id = $1", [subscriberId]);
    if (subRows.length && routerIds.length) {
      await disconnectSession(routerIds, subRows[0].username).catch(
        (e) => logger.warn({ e }, "mpesa: callback disconnect failed (non-fatal)")
      );
    }

    logger.info({ subscriberId, mpesaRef: parsed.mpesaRef, amount: parsed.amount }, "mpesa: payment processed");

  } catch (err) {
    logger.error({ err, parsed }, "mpesa: callback processing error");
  }
});

// ---------------------------------------------------------------------------
// GET /api/mpesa/status/:checkoutRequestId
// Poll payment status (used by frontend polling)
// ---------------------------------------------------------------------------
router.get("/status/:checkoutRequestId", authenticateUser, async (req, res) => {
  const { checkoutRequestId } = req.params;

  try {
    // First check our DB
    const { rows } = await db.query(
      "SELECT status, mpesa_ref, amount FROM transactions WHERE mpesa_checkout_id = $1",
      [checkoutRequestId]
    );

    if (rows.length && rows[0].status !== "pending") {
      return res.json({ success: true, status: rows[0].status, mpesaRef: rows[0].mpesa_ref });
    }

    // If still pending, query Daraja
    const data = await stkQuery(checkoutRequestId);
    res.json({
      success: true,
      status:  data.ResultCode === 0 ? "success" : "pending",
      daraja:  data,
    });

  } catch (err) {
    logger.error({ err }, "mpesa: status check failed");
    res.status(500).json({ success: false });
  }
});

module.exports = router;
