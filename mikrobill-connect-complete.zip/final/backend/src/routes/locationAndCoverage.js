/**
 * backend/src/routes/portal/location.js
 *
 * Customer PWA location endpoints:
 *   GET  /api/portal/network-check   — verify request IP is in ISP range
 *   POST /api/portal/location        — store GPS point (only accepted from ISP IPs)
 *
 * Admin coverage map endpoints:
 *   GET  /api/admin/coverage-map     — heatmap data + router markers
 *   GET  /api/admin/radiusdesk/aps   — AP list with live client counts
 */

"use strict";

const express             = require("express");
const { body, query, validationResult } = require("express-validator");
const db                  = require("../../db");
const { authenticateUser, requireRole } = require("../../middleware/auth");
const logger              = require("../../utils/logger");

const router = express.Router();

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Check whether a dotted-decimal IPv4 string falls within a CIDR.
 * Uses PostgreSQL's inet operators — fast and correct for edge cases.
 *
 * @param {string} ip
 * @param {string} cidr
 * @returns {Promise<boolean>}
 */
async function isIpInCidr(ip, cidr) {
  try {
    const { rows } = await db.query(
      "SELECT ($1::inet << $2::cidr) AS result",
      [ip, cidr]
    );
    return rows[0]?.result === true;
  } catch {
    return false;
  }
}

/**
 * Extract the real client IP, respecting X-Forwarded-For from Nginx proxy.
 */
function getClientIp(req) {
  const forwarded = req.headers["x-forwarded-for"];
  if (forwarded) return forwarded.split(",")[0].trim();
  return req.ip ?? req.connection?.remoteAddress ?? "";
}

// ---------------------------------------------------------------------------
// GET /api/portal/network-check
// ---------------------------------------------------------------------------
// No auth required — called before login to decide whether to enable location.
// Returns { onISPNetwork: boolean, clientIp: string }
router.get("/portal/network-check", async (req, res) => {
  const clientIp = getClientIp(req);

  try {
    const { rows: ranges } = await db.query(
      "SELECT cidr FROM isp_ip_ranges WHERE active = TRUE"
    );

    let onISPNetwork = false;
    for (const range of ranges) {
      if (await isIpInCidr(clientIp, range.cidr)) {
        onISPNetwork = true;
        break;
      }
    }

    res.json({ onISPNetwork, clientIp });
  } catch (err) {
    logger.error({ err }, "network-check: error");
    res.status(500).json({ onISPNetwork: false, clientIp, error: "internal" });
  }
});

// ---------------------------------------------------------------------------
// POST /api/portal/location
// ---------------------------------------------------------------------------
router.post(
  "/portal/location",
  authenticateUser,
  [
    body("lat").isFloat({ min: -90,  max: 90  }).withMessage("Invalid latitude"),
    body("lng").isFloat({ min: -180, max: 180 }).withMessage("Invalid longitude"),
    body("accuracy").optional().isFloat({ min: 0, max: 50_000 }),
  ],
  async (req, res) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(422).json({ errors: errors.array() });
    }

    const clientIp      = getClientIp(req);
    const subscriberId  = req.user.subscriberId;
    const { lat, lng, accuracy } = req.body;

    // --- Guard: only accept location reports from ISP network ---
    const { rows: ranges } = await db.query(
      "SELECT cidr FROM isp_ip_ranges WHERE active = TRUE"
    );

    let onISP = false;
    for (const r of ranges) {
      if (await isIpInCidr(clientIp, r.cidr)) { onISP = true; break; }
    }

    if (!onISP) {
      // Silently ignore — don't tell the client why (prevents circumvention via VPN)
      return res.json({ ok: true });
    }

    // Identify which router this IP belongs to
    const { rows: routerRows } = await db.query(
      `SELECT r.id
       FROM   routers r
       JOIN   isp_ip_ranges ir ON ir.router_id = r.id
       WHERE  ir.active = TRUE
         AND  $1::inet << ir.cidr::cidr
       LIMIT  1`,
      [clientIp]
    );
    const routerId = routerRows[0]?.id ?? null;

    try {
      await db.query(
        `INSERT INTO user_locations (subscriber_id, router_id, lat, lng, accuracy_m)
         VALUES ($1, $2, $3, $4, $5)`,
        [subscriberId, routerId, lat, lng, accuracy ?? null]
      );

      res.json({ ok: true });
    } catch (err) {
      logger.error({ err }, "location: insert failed");
      res.status(500).json({ error: "internal" });
    }
  }
);

// ---------------------------------------------------------------------------
// GET /api/admin/coverage-map?hours=24
// ---------------------------------------------------------------------------
router.get(
  "/admin/coverage-map",
  authenticateUser,
  requireRole(["super_admin", "network_admin", "field_tech"]),
  [
    query("hours").optional().isInt({ min: 1, max: 720 }).toInt(),
  ],
  async (req, res) => {
    const hours = req.query.hours ?? 24;

    try {
      // Heatmap points: aggregate to ~50m grid cells to avoid sending millions of rows
      const { rows: locations } = await db.query(
        `SELECT
           ROUND(lat::numeric, 4)  AS lat,
           ROUND(lng::numeric, 4)  AS lng,
           COUNT(*)::int           AS weight
         FROM  user_locations
         WHERE recorded_at > NOW() - ($1 || ' hours')::INTERVAL
         GROUP BY ROUND(lat::numeric, 4), ROUND(lng::numeric, 4)
         ORDER BY weight DESC
         LIMIT  5000`,
        [hours]
      );

      // Router markers with online status
      const { rows: routers } = await db.query(
        `SELECT id, name, ip_address, lat, lng, status, active_users, cpu_load
         FROM   routers
         ORDER  BY name`
      );

      // RadiusDesk AP markers
      const { rows: aps } = await db.query(
        `SELECT mac, name, lat, lng, online, active_clients, last_contact
         FROM   radiusdesk_aps
         WHERE  lat IS NOT NULL AND lng IS NOT NULL
         ORDER  BY name`
      );

      // Outage zones: grid cells with historical coverage but no reports in last 2h
      const { rows: outageZones } = await db.query(
        `SELECT
           ROUND(lat::numeric, 3) AS lat,
           ROUND(lng::numeric, 3) AS lng,
           COUNT(*) AS historical_count
         FROM  user_locations
         WHERE recorded_at > NOW() - '7 days'::INTERVAL
         GROUP BY ROUND(lat::numeric, 3), ROUND(lng::numeric, 3)
         HAVING MAX(recorded_at) < NOW() - '2 hours'::INTERVAL
            AND COUNT(*) > 5
         LIMIT  200`
      );

      res.json({ locations, routers, aps, outageZones });
    } catch (err) {
      logger.error({ err }, "coverage-map: query failed");
      res.status(500).json({ error: "internal" });
    }
  }
);

// ---------------------------------------------------------------------------
// GET /api/admin/radiusdesk/aps
// ---------------------------------------------------------------------------
router.get(
  "/admin/radiusdesk/aps",
  authenticateUser,
  requireRole(["super_admin", "network_admin"]),
  async (_req, res) => {
    try {
      const { rows } = await db.query(
        `SELECT mac, name, lat, lng, online, active_clients,
                last_contact, model, firmware, synced_at
         FROM   radiusdesk_aps
         ORDER  BY name`
      );
      res.json({ success: true, aps: rows });
    } catch (err) {
      logger.error({ err }, "radiusdesk/aps: query failed");
      res.status(500).json({ success: false, aps: [] });
    }
  }
);

// ---------------------------------------------------------------------------
// GET /api/admin/ip-pools — current pool utilisation snapshot
// ---------------------------------------------------------------------------
router.get(
  "/admin/ip-pools",
  authenticateUser,
  requireRole(["super_admin", "network_admin"]),
  async (_req, res) => {
    try {
      const { rows } = await db.query(
        `SELECT ps.router_id, r.name AS router_name,
                ps.pool_name, ps.used, ps.total, ps.pct_used, ps.recorded_at
         FROM   v_ip_pool_latest ps
         JOIN   routers r ON r.id = ps.router_id
         ORDER  BY ps.pct_used DESC`
      );
      res.json({ success: true, pools: rows });
    } catch (err) {
      logger.error({ err }, "ip-pools: query failed");
      res.status(500).json({ success: false, pools: [] });
    }
  }
);

// ---------------------------------------------------------------------------
// GET /api/admin/qos — latest QoS stats per queue per router
// ---------------------------------------------------------------------------
router.get(
  "/admin/qos",
  authenticateUser,
  requireRole(["super_admin", "network_admin"]),
  async (_req, res) => {
    try {
      const { rows } = await db.query(
        `SELECT qs.router_id, r.name AS router_name,
                qs.queue_name, qs.bytes, qs.packets, qs.dropped,
                qs.queued, qs.drop_rate, qs.recorded_at
         FROM   v_qos_latest qs
         JOIN   routers r ON r.id = qs.router_id
         ORDER  BY qs.drop_rate DESC`
      );
      res.json({ success: true, queues: rows });
    } catch (err) {
      logger.error({ err }, "qos: query failed");
      res.status(500).json({ success: false, queues: [] });
    }
  }
);

module.exports = router;
