/**
 * Mikrobill Connect — Backend Entry Point
 * Registers all background jobs and API routes.
 */

"use strict";

const express  = require("express");
const cors     = require("cors");
const helmet   = require("helmet");
require("dotenv").config();

const logger = require("./utils/logger");
const db     = require("./db");
const app    = express();
const PORT   = process.env.PORT || 3001;

app.use(helmet());
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(",") ?? ["http://localhost:5173"],
  credentials: true,
}));
app.use(express.json({ limit: "500kb" }));

app.use((req, _res, next) => {
  logger.debug({ method: req.method, path: req.path }, "request");
  next();
});

const { authenticateUser } = require("./middleware/auth");

const locationRoutes    = require("./routes/locationAndCoverage");
const adminRoutersRoute = require("./routes/admin/routers");
const mikrotikRoutes    = require("./routes/admin/mikrotik");
const mpesaRoutes       = require("./routes/mpesa");
const portalRoutes      = require("./routes/portal");

app.use("/api", locationRoutes);
app.use("/api/admin/routers",  authenticateUser, adminRoutersRoute);
app.use("/api/admin/mikrotik", authenticateUser, mikrotikRoutes);
app.use("/api/mpesa", mpesaRoutes);
app.use("/api", portalRoutes);

app.get("/health", async (_req, res) => {
  let dbOk = false;
  try { await db.healthCheck(); dbOk = true; } catch {}
  res.json({ status: dbOk ? "ok" : "degraded", db: dbOk ? "connected" : "disconnected", uptime: process.uptime(), ts: new Date().toISOString() });
});

app.use((err, req, res, _next) => {
  logger.error({ err, path: req.path }, "unhandled error");
  res.status(500).json({ error: "Internal server error" });
});

[
  { name: "ipPoolMonitor",     module: require("./jobs/ipPoolMonitor") },
  { name: "qosMonitor",        module: require("./jobs/qosMonitor") },
  { name: "tetherEnforcement", module: require("./jobs/tetherEnforcement") },
  { name: "radiusdeskSync",    module: require("./jobs/radiusdeskSync") },
].forEach(({ name, module }) => {
  try { module.start(); logger.info(`${name}: started`); }
  catch (err) { logger.error({ err }, `${name}: failed to start`); }
});

app.listen(PORT, () => {
  logger.info(`[Mikrobill Backend] Listening on port ${PORT}`);
});

async function shutdown() {
  logger.info("Shutting down...");
  await db.end();
  process.exit(0);
}
process.on("SIGTERM", shutdown);
process.on("SIGINT",  shutdown);

module.exports = app;
