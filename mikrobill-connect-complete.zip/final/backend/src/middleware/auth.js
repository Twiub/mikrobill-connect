/**
 * backend/src/middleware/auth.js
 *
 * JWT authentication middleware using Supabase JWT verification.
 *
 * Usage:
 *   const { authenticateUser, requireRole } = require("./middleware/auth");
 *
 *   router.get("/secure", authenticateUser, requireRole(["super_admin"]), handler);
 */

"use strict";

const { createClient } = require("@supabase/supabase-js");
const logger = require("../utils/logger");

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_ROLE_KEY
);

/**
 * Extracts Bearer token from Authorization header and verifies it
 * against Supabase. Attaches `req.user` and `req.userId` on success.
 */
async function authenticateUser(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Missing or invalid Authorization header" });
  }

  const token = authHeader.slice(7);

  try {
    const { data: { user }, error } = await supabase.auth.getUser(token);
    if (error || !user) {
      return res.status(401).json({ error: "Invalid or expired token" });
    }

    req.user   = user;
    req.userId = user.id;
    next();
  } catch (err) {
    logger.error({ err }, "auth: token verification failed");
    res.status(500).json({ error: "Authentication error" });
  }
}

/**
 * Role-based access control middleware.
 * Must be used AFTER authenticateUser.
 *
 * @param {string[]} allowedRoles  e.g. ["super_admin", "network_admin"]
 */
function requireRole(allowedRoles) {
  return async (req, res, next) => {
    if (!req.userId) {
      return res.status(401).json({ error: "Unauthenticated" });
    }

    try {
      const { data, error } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", req.userId)
        .single();

      if (error || !data) {
        return res.status(403).json({ error: "No role assigned to this user" });
      }

      if (!allowedRoles.includes(data.role)) {
        logger.warn(
          { userId: req.userId, role: data.role, required: allowedRoles },
          "auth: insufficient role"
        );
        return res.status(403).json({ error: `Requires one of: ${allowedRoles.join(", ")}` });
      }

      req.userRole = data.role;
      next();
    } catch (err) {
      logger.error({ err }, "auth: role check failed");
      res.status(500).json({ error: "Authorization error" });
    }
  };
}

module.exports = { authenticateUser, requireRole };
