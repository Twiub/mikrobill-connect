-- ===================================================
-- Migration 002: New Features
-- Expenditure Categories, Staff, Notification Templates,
-- M-Pesa Config, Hotspot Device Locks, PPPoE Hotspot Access,
-- Routers with API creds, Bandwidth Schedule fixes
-- ===================================================

-- ── Routers: add API credentials & port ──────────────────────────────────────
ALTER TABLE routers
  ADD COLUMN IF NOT EXISTS api_port      integer     DEFAULT 8728,
  ADD COLUMN IF NOT EXISTS api_username  text        DEFAULT 'admin',
  ADD COLUMN IF NOT EXISTS api_password  text        DEFAULT '',
  ADD COLUMN IF NOT EXISTS api_ssl       boolean     DEFAULT false,
  ADD COLUMN IF NOT EXISTS location      text,
  ADD COLUMN IF NOT EXISTS nas_ip        text,
  ADD COLUMN IF NOT EXISTS secret_radius text;

-- ── Expenditure Categories ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS expenditure_categories (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name        text NOT NULL UNIQUE,
  color       text DEFAULT '#6366f1',
  is_recurring boolean DEFAULT false,
  created_at  timestamptz DEFAULT now()
);

-- Seed default categories
INSERT INTO expenditure_categories (name, color, is_recurring) VALUES
  ('Bandwidth',  '#3b82f6', true),
  ('Equipment',  '#8b5cf6', false),
  ('Salary',     '#10b981', true),
  ('Power',      '#f59e0b', true),
  ('Office',     '#6b7280', true),
  ('Other',      '#ef4444', false)
ON CONFLICT (name) DO NOTHING;

-- ── Staff ────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS staff (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name           text NOT NULL,
  email               text,
  phone               text,
  role                text NOT NULL DEFAULT 'technician',
  department          text,
  salary              numeric(12,2) DEFAULT 0,
  recurring_day       integer DEFAULT 1 CHECK (recurring_day BETWEEN 1 AND 28),
  is_active           boolean DEFAULT true,
  hire_date           date,
  created_at          timestamptz DEFAULT now(),
  updated_at          timestamptz DEFAULT now()
);

-- ── Expenditures: add category_id & staff_id foreign keys ───────────────────
ALTER TABLE expenditures
  ADD COLUMN IF NOT EXISTS category_id  uuid REFERENCES expenditure_categories(id),
  ADD COLUMN IF NOT EXISTS staff_id     uuid REFERENCES staff(id),
  ADD COLUMN IF NOT EXISTS is_recurring boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS notes        text;

-- ── Notification Templates ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS notification_templates (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type        text NOT NULL UNIQUE, -- expiry_24h, expiry_1h, payment_received, etc.
  title       text NOT NULL,
  body        text NOT NULL,       -- supports {{name}}, {{package}}, {{amount}}, {{expires}}
  channel     text DEFAULT 'both', -- sms | push | both
  enabled     boolean DEFAULT true,
  updated_at  timestamptz DEFAULT now(),
  updated_by  text
);

-- Seed default templates
INSERT INTO notification_templates (type, title, body, channel) VALUES
  ('expiry_24h',        'Package Expiring',      'Hi {{name}}, your {{package}} package expires in 24 hours. Renew now to stay connected.', 'both'),
  ('expiry_1h',         'Package Expiring Soon',  'Hi {{name}}, your {{package}} package expires in 1 hour! Renew immediately.', 'sms'),
  ('payment_received',  'Payment Received',       'Hi {{name}}, we received KES {{amount}} for your {{package}} package. Expires {{expires}}. Enjoy!', 'both'),
  ('account_suspended', 'Account Suspended',      'Hi {{name}}, your account has been suspended. Contact support or renew your package.', 'sms'),
  ('outage',            'Network Outage',         'Hi {{name}}, we are experiencing a network issue at your area. Our team is working on it. Sorry for the inconvenience.', 'both'),
  ('outage_resolved',   'Network Restored',       'Hi {{name}}, the network issue in your area has been resolved. Enjoy your connection!', 'both'),
  ('ticket_updated',    'Ticket Update',          'Hi {{name}}, your support ticket #{{ticket_id}} has been updated: {{status}}.', 'push'),
  ('broadcast',         'Admin Message',          '{{message}}', 'both'),
  ('welcome',           'Welcome to WiFi',        'Hi {{name}}, welcome! Your WiFi is ready. Username: {{username}} Password: {{password}}. Enjoy!', 'sms')
ON CONFLICT (type) DO NOTHING;

-- ── M-Pesa Config (single-row settings table) ────────────────────────────────
CREATE TABLE IF NOT EXISTS mpesa_config (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  environment         text DEFAULT 'sandbox' CHECK (environment IN ('sandbox','production')),
  consumer_key        text,
  consumer_secret     text,
  passkey             text,
  shortcode           text,  -- Paybill or Till number
  initiator_name      text,
  initiator_password  text,
  stk_callback_url    text,
  c2b_confirmation_url text,
  c2b_validation_url  text,
  b2c_result_url      text,
  b2c_timeout_url     text,
  account_reference   text DEFAULT 'WIFI',
  transaction_desc    text DEFAULT 'WiFi Package',
  updated_at          timestamptz DEFAULT now()
);

-- Seed with one empty row
INSERT INTO mpesa_config (id) VALUES (gen_random_uuid())
ON CONFLICT DO NOTHING;

-- ── Hotspot Allowed Devices (locked per subscriber, once per month) ───────────
CREATE TABLE IF NOT EXISTS hotspot_allowed_devices (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscriber_id uuid NOT NULL REFERENCES subscribers(id) ON DELETE CASCADE,
  mac_address   text NOT NULL,
  device_name   text,
  locked_at     timestamptz DEFAULT now(),
  locked_month  integer GENERATED ALWAYS AS (EXTRACT(MONTH FROM locked_at)::integer) STORED,
  locked_year   integer GENERATED ALWAYS AS (EXTRACT(YEAR FROM locked_at)::integer) STORED,
  UNIQUE (subscriber_id, mac_address)
);

-- ── PPPoE subscribers with hotspot access ───────────────────────────────────
-- Add hotspot_enabled flag and allowed package IDs to subscribers
ALTER TABLE subscribers
  ADD COLUMN IF NOT EXISTS hotspot_enabled   boolean DEFAULT false,
  ADD COLUMN IF NOT EXISTS hotspot_package_ids text[],  -- package IDs allowed for hotspot
  ADD COLUMN IF NOT EXISTS pppoe_username    text,
  ADD COLUMN IF NOT EXISTS pppoe_password    text,
  ADD COLUMN IF NOT EXISTS router_id         uuid REFERENCES routers(id);

-- ── Packages: add pppoe_profile & hotspot_profile fields ────────────────────
ALTER TABLE packages
  ADD COLUMN IF NOT EXISTS pppoe_profile   text,  -- MikroTik PPP profile name
  ADD COLUMN IF NOT EXISTS hotspot_profile text,  -- MikroTik Hotspot profile name
  ADD COLUMN IF NOT EXISTS burst_down      text,
  ADD COLUMN IF NOT EXISTS burst_up        text,
  ADD COLUMN IF NOT EXISTS burst_threshold text,
  ADD COLUMN IF NOT EXISTS burst_time_s    integer,
  ADD COLUMN IF NOT EXISTS data_cap_gb     numeric(8,2),
  ADD COLUMN IF NOT EXISTS shared_users_max integer DEFAULT 1,
  ADD COLUMN IF NOT EXISTS description     text;

-- ── Bandwidth schedules: add is_active & router_id filter ───────────────────
ALTER TABLE bandwidth_schedules
  ADD COLUMN IF NOT EXISTS is_active  boolean DEFAULT true,
  ADD COLUMN IF NOT EXISTS router_id  uuid REFERENCES routers(id),
  ADD COLUMN IF NOT EXISTS priority   integer DEFAULT 10;

-- ── Captive portal sessions (cookie-based login) ────────────────────────────
CREATE TABLE IF NOT EXISTS portal_sessions (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  subscriber_id uuid NOT NULL REFERENCES subscribers(id) ON DELETE CASCADE,
  token         text NOT NULL UNIQUE DEFAULT encode(gen_random_bytes(32), 'hex'),
  ip_address    text,
  user_agent    text,
  created_at    timestamptz DEFAULT now(),
  expires_at    timestamptz DEFAULT now() + interval '30 days',
  last_active   timestamptz DEFAULT now()
);

-- Index for fast token lookups
CREATE INDEX IF NOT EXISTS idx_portal_sessions_token ON portal_sessions(token);
CREATE INDEX IF NOT EXISTS idx_portal_sessions_expires ON portal_sessions(expires_at);

-- ── RLS Policies ────────────────────────────────────────────────────────────
ALTER TABLE expenditure_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE staff ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE mpesa_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE hotspot_allowed_devices ENABLE ROW LEVEL SECURITY;
ALTER TABLE portal_sessions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated users can manage expenditure_categories"
  ON expenditure_categories FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Authenticated users can manage staff"
  ON staff FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Authenticated users can manage notification_templates"
  ON notification_templates FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Authenticated users can manage mpesa_config"
  ON mpesa_config FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Authenticated users can manage hotspot_allowed_devices"
  ON hotspot_allowed_devices FOR ALL TO authenticated USING (true) WITH CHECK (true);

CREATE POLICY "Authenticated users can manage portal_sessions"
  ON portal_sessions FOR ALL TO authenticated USING (true) WITH CHECK (true);
