-- =============================================================================
-- WiFi Billing System - Missing Features Migration
-- Adds: user_locations, isp_ip_ranges, ip_pool_stats, qos_stats,
--       radiusdesk_access_points, nas, tethering_violations (extended),
--       PostGIS spatial support
-- =============================================================================

-- Enable PostGIS for spatial queries (run once per database)
CREATE EXTENSION IF NOT EXISTS postgis;

-- ---------------------------------------------------------------------------
-- 1. ISP IP RANGES — for verifying user is on ISP network before reporting location
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.isp_ip_ranges (
  id          BIGSERIAL PRIMARY KEY,
  cidr        CIDR        NOT NULL,
  label       TEXT,                        -- e.g. "Hotspot Pool A", "PPPoE Pool"
  router_id   BIGINT REFERENCES public.routers(id) ON DELETE SET NULL,
  active      BOOLEAN     NOT NULL DEFAULT TRUE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_isp_ip_ranges_cidr ON public.isp_ip_ranges USING GIST (cidr inet_ops);
CREATE INDEX IF NOT EXISTS idx_isp_ip_ranges_active ON public.isp_ip_ranges (active) WHERE active = TRUE;

-- Seed with default hotspot/PPPoE pools from design doc
INSERT INTO public.isp_ip_ranges (cidr, label) VALUES
  ('10.10.0.0/20',  'Hotspot Pool A'),
  ('10.10.16.0/20', 'Hotspot Pool B'),
  ('10.20.0.0/20',  'PPPoE Pool A'),
  ('10.20.16.0/20', 'PPPoE Pool B'),
  ('10.30.0.0/22',  'Expired/Redirect Pool')
ON CONFLICT DO NOTHING;

-- ---------------------------------------------------------------------------
-- 2. USER LOCATIONS — GPS points collected from PWA (only while on ISP network)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.user_locations (
  id            BIGSERIAL   PRIMARY KEY,
  subscriber_id BIGINT      NOT NULL REFERENCES public.subscribers(id) ON DELETE CASCADE,
  router_id     BIGINT      REFERENCES public.routers(id) ON DELETE SET NULL,
  lat           DECIMAL(10,8) NOT NULL,
  lng           DECIMAL(11,8) NOT NULL,
  accuracy_m    DECIMAL(8,2),              -- GPS accuracy in metres
  -- PostGIS point for fast spatial queries
  geom          GEOMETRY(Point, 4326) GENERATED ALWAYS AS (
                  ST_SetSRID(ST_MakePoint(lng, lat), 4326)
                ) STORED,
  recorded_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Spatial index for fast heatmap/proximity queries
CREATE INDEX IF NOT EXISTS idx_user_locations_geom
  ON public.user_locations USING GIST (geom);

-- Time index for filtering last N hours
CREATE INDEX IF NOT EXISTS idx_user_locations_recorded_at
  ON public.user_locations (recorded_at DESC);

CREATE INDEX IF NOT EXISTS idx_user_locations_subscriber
  ON public.user_locations (subscriber_id, recorded_at DESC);

-- ---------------------------------------------------------------------------
-- 3. IP POOL STATS — captured every 5 minutes for utilization monitoring
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.ip_pool_stats (
  id          BIGSERIAL   PRIMARY KEY,
  router_id   BIGINT      NOT NULL REFERENCES public.routers(id) ON DELETE CASCADE,
  pool_name   TEXT        NOT NULL,
  used        INT         NOT NULL DEFAULT 0,
  total       INT         NOT NULL DEFAULT 1,
  pct_used    DECIMAL(5,2) NOT NULL DEFAULT 0,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ip_pool_stats_router_time
  ON public.ip_pool_stats (router_id, recorded_at DESC);

CREATE INDEX IF NOT EXISTS idx_ip_pool_stats_pool_time
  ON public.ip_pool_stats (pool_name, recorded_at DESC);

-- Partial index for high-utilisation alerting queries
CREATE INDEX IF NOT EXISTS idx_ip_pool_stats_high_util
  ON public.ip_pool_stats (router_id, pct_used)
  WHERE pct_used > 80;

-- ---------------------------------------------------------------------------
-- 4. QOS STATS — CAKE queue metrics polled every 30 seconds
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.qos_stats (
  id          BIGSERIAL   PRIMARY KEY,
  router_id   BIGINT      NOT NULL REFERENCES public.routers(id) ON DELETE CASCADE,
  queue_name  TEXT        NOT NULL,
  bytes       BIGINT      NOT NULL DEFAULT 0,
  packets     BIGINT      NOT NULL DEFAULT 0,
  dropped     BIGINT      NOT NULL DEFAULT 0,
  queued      INT         NOT NULL DEFAULT 0,
  -- Derived: drops/packets %. Stored for fast alerting queries.
  drop_rate   DECIMAL(5,2) GENERATED ALWAYS AS (
                CASE WHEN packets > 0
                     THEN ROUND((dropped::DECIMAL / packets) * 100, 2)
                     ELSE 0
                END
              ) STORED,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_qos_stats_router_time
  ON public.qos_stats (router_id, recorded_at DESC);

CREATE INDEX IF NOT EXISTS idx_qos_stats_high_drops
  ON public.qos_stats (router_id, drop_rate)
  WHERE drop_rate > 5;

-- ---------------------------------------------------------------------------
-- 5. RADIUSDESK ACCESS POINTS — synced from RadiusDesk API
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.radiusdesk_aps (
  id              BIGSERIAL   PRIMARY KEY,
  mac             TEXT        NOT NULL UNIQUE,   -- AP MAC address (RadiusDesk key)
  name            TEXT,
  router_id       BIGINT      REFERENCES public.routers(id) ON DELETE SET NULL,
  lat             DECIMAL(10,8),
  lng             DECIMAL(11,8),
  geom            GEOMETRY(Point, 4326) GENERATED ALWAYS AS (
                    CASE WHEN lat IS NOT NULL AND lng IS NOT NULL
                         THEN ST_SetSRID(ST_MakePoint(lng, lat), 4326)
                         ELSE NULL
                    END
                  ) STORED,
  online          BOOLEAN     NOT NULL DEFAULT FALSE,
  active_clients  INT         NOT NULL DEFAULT 0,
  last_contact    TIMESTAMPTZ,
  firmware        TEXT,
  model           TEXT,
  synced_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_radiusdesk_aps_geom
  ON public.radiusdesk_aps USING GIST (geom);

CREATE INDEX IF NOT EXISTS idx_radiusdesk_aps_online
  ON public.radiusdesk_aps (online, last_contact DESC);

-- ---------------------------------------------------------------------------
-- 6. NAS TABLE — FreeRADIUS NAS clients (shared with RadiusDesk)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.nas (
  id          BIGSERIAL   PRIMARY KEY,
  nasname     INET        NOT NULL UNIQUE,   -- router IP
  shortname   TEXT        NOT NULL,
  type        TEXT        NOT NULL DEFAULT 'mikrotik',
  secret      TEXT        NOT NULL,
  description TEXT,
  router_id   BIGINT      REFERENCES public.routers(id) ON DELETE CASCADE,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_nas_nasname ON public.nas (nasname);

-- ---------------------------------------------------------------------------
-- 7. Extend sharing_violations with MikroTik router reference (if not present)
-- ---------------------------------------------------------------------------
ALTER TABLE public.sharing_violations
  ADD COLUMN IF NOT EXISTS router_id    BIGINT REFERENCES public.routers(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS tethered_ip  INET,
  ADD COLUMN IF NOT EXISTS ttl_value    SMALLINT,   -- 63 or 127
  ADD COLUMN IF NOT EXISTS resolved     BOOLEAN NOT NULL DEFAULT FALSE,
  ADD COLUMN IF NOT EXISTS resolved_at  TIMESTAMPTZ;

CREATE INDEX IF NOT EXISTS idx_sharing_violations_router
  ON public.sharing_violations (router_id, detected_at DESC)
  WHERE resolved = FALSE;

-- ---------------------------------------------------------------------------
-- 8. Add missing columns to packages for burst config
-- ---------------------------------------------------------------------------
ALTER TABLE public.packages
  ADD COLUMN IF NOT EXISTS burst_down        TEXT,           -- e.g. '20M'
  ADD COLUMN IF NOT EXISTS burst_up          TEXT,           -- e.g. '8M'
  ADD COLUMN IF NOT EXISTS burst_threshold_down TEXT,        -- e.g. '5M'
  ADD COLUMN IF NOT EXISTS burst_threshold_up   TEXT,        -- e.g. '2M'
  ADD COLUMN IF NOT EXISTS burst_time_s      SMALLINT,       -- seconds
  ADD COLUMN IF NOT EXISTS data_cap_gb       DECIMAL(10,2);  -- NULL = unlimited

-- Update hotspot packages with burst settings
UPDATE public.packages SET
  burst_down = '10M', burst_up = '4M',
  burst_threshold_down = '2M', burst_threshold_up = '1M',
  burst_time_s = 8
WHERE name = 'Hotspot Basic' AND burst_down IS NULL;

UPDATE public.packages SET
  burst_down = '20M', burst_up = '8M',
  burst_threshold_down = '5M', burst_threshold_up = '2M',
  burst_time_s = 8
WHERE name = 'Hotspot Standard' AND burst_down IS NULL;

UPDATE public.packages SET
  burst_down = '40M', burst_up = '16M',
  burst_threshold_down = '10M', burst_threshold_up = '4M',
  burst_time_s = 10
WHERE name = 'Hotspot Premium' AND burst_down IS NULL;

UPDATE public.packages SET
  burst_down = '40M', burst_up = '20M',
  burst_threshold_down = '10M', burst_threshold_up = '5M',
  burst_time_s = 10
WHERE name = 'PPPoE Home' AND burst_down IS NULL;

-- ---------------------------------------------------------------------------
-- Row-Level Security (match existing project pattern)
-- ---------------------------------------------------------------------------
ALTER TABLE public.isp_ip_ranges     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_locations    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ip_pool_stats     ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.qos_stats         ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.radiusdesk_aps    ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.nas               ENABLE ROW LEVEL SECURITY;

-- Admins can read/write everything
CREATE POLICY "admin_all_isp_ip_ranges"  ON public.isp_ip_ranges  FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "admin_all_user_locations" ON public.user_locations  FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "admin_all_ip_pool_stats"  ON public.ip_pool_stats   FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "admin_all_qos_stats"      ON public.qos_stats       FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "admin_all_radiusdesk_aps" ON public.radiusdesk_aps  FOR ALL USING (auth.role() = 'authenticated');
CREATE POLICY "admin_all_nas"            ON public.nas             FOR ALL USING (auth.role() = 'authenticated');

-- ---------------------------------------------------------------------------
-- Helper view: latest pool stats per pool (for dashboard widgets)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.v_ip_pool_latest AS
SELECT DISTINCT ON (router_id, pool_name)
  router_id, pool_name, used, total, pct_used, recorded_at
FROM public.ip_pool_stats
ORDER BY router_id, pool_name, recorded_at DESC;

-- Helper view: latest QoS stats per queue (for dashboard)
CREATE OR REPLACE VIEW public.v_qos_latest AS
SELECT DISTINCT ON (router_id, queue_name)
  router_id, queue_name, bytes, packets, dropped, queued, drop_rate, recorded_at
FROM public.qos_stats
ORDER BY router_id, queue_name, recorded_at DESC;

-- ---------------------------------------------------------------------------
-- Retention policy: auto-delete old metrics (keeps DB lean)
-- Run this as a pg_cron job or call from your backend scheduler
-- ---------------------------------------------------------------------------
-- DELETE FROM public.ip_pool_stats  WHERE recorded_at < NOW() - INTERVAL '30 days';
-- DELETE FROM public.qos_stats      WHERE recorded_at < NOW() - INTERVAL '7 days';
-- DELETE FROM public.user_locations WHERE recorded_at < NOW() - INTERVAL '90 days';
