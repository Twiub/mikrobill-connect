/**
 * src/components/LocationConsentModal.tsx
 *
 * Modal shown once to PWA portal users asking for location permission.
 * Transparent about what data is collected and why.
 * Dismissable — declining doesn't restrict any portal functionality.
 *
 * Integration example (in UserPortal.tsx):
 *
 *   import { useLocationTracking } from "@/hooks/useLocationTracking";
 *   import LocationConsentModal from "@/components/LocationConsentModal";
 *
 *   const { needsConsent, grantPermission, denyPermission, isReporting } =
 *     useLocationTracking(token);
 *
 *   return (
 *     <>
 *       {needsConsent && (
 *         <LocationConsentModal onAccept={grantPermission} onDecline={denyPermission} />
 *       )}
 *       {isReporting && (
 *         <p className="text-xs text-muted-foreground">📍 Location sharing active</p>
 *       )}
 *       ...rest of portal...
 *     </>
 *   );
 */

import { useState } from "react";
import { Button } from "@/components/ui/button";
import { MapPin, Shield, X } from "lucide-react";

interface Props {
  onAccept:  () => Promise<void>;
  onDecline: () => void;
}

const LocationConsentModal = ({ onAccept, onDecline }: Props) => {
  const [loading, setLoading] = useState(false);

  const handleAccept = async () => {
    setLoading(true);
    try {
      await onAccept();
    } finally {
      setLoading(false);
    }
  };

  return (
    /* Backdrop */
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="relative w-full max-w-md rounded-2xl bg-card border border-border shadow-2xl overflow-hidden">

        {/* Close button */}
        <button
          onClick={onDecline}
          className="absolute top-4 right-4 p-1.5 rounded-full text-muted-foreground hover:bg-muted transition-colors"
          aria-label="Dismiss"
        >
          <X className="h-4 w-4" />
        </button>

        {/* Header illustration */}
        <div className="bg-gradient-to-br from-primary/10 to-violet-500/10 p-8 flex justify-center">
          <div className="relative">
            <div className="h-16 w-16 rounded-2xl bg-primary/20 flex items-center justify-center">
              <MapPin className="h-8 w-8 text-primary" />
            </div>
            <div className="absolute -bottom-1 -right-1 h-6 w-6 rounded-full bg-success flex items-center justify-center">
              <Shield className="h-3.5 w-3.5 text-white" />
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="p-6 space-y-4">
          <div>
            <h2 className="text-lg font-bold">Help Us Improve Your Coverage</h2>
            <p className="text-sm text-muted-foreground mt-1.5">
              Allow us to periodically collect your location <strong>only while you are
              connected to our network</strong> so we can identify coverage gaps and
              respond faster to outages in your area.
            </p>
          </div>

          {/* What we collect */}
          <div className="rounded-xl border border-border/60 bg-muted/30 p-4 space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
              What we collect
            </p>
            {[
              "Your approximate GPS location (every 5 minutes)",
              "Which of our routers you are connected to",
              "Connection timestamp",
            ].map(item => (
              <div key={item} className="flex items-start gap-2 text-sm">
                <span className="text-success mt-0.5">✓</span>
                <span>{item}</span>
              </div>
            ))}
          </div>

          {/* Privacy promises */}
          <div className="space-y-2">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">
              We will never
            </p>
            {[
              "Track you when you are on other networks or mobile data",
              "Share your location with any third parties",
              "Use your location for advertising",
              "Require location for any portal features",
            ].map(item => (
              <div key={item} className="flex items-start gap-2 text-sm text-muted-foreground">
                <span className="text-destructive mt-0.5">✗</span>
                <span>{item}</span>
              </div>
            ))}
          </div>

          <p className="text-xs text-muted-foreground">
            You can change your mind at any time in your browser settings or by contacting support.
            Declining does not affect any portal features.
          </p>
        </div>

        {/* Actions */}
        <div className="px-6 pb-6 flex flex-col gap-2">
          <Button onClick={handleAccept} disabled={loading} className="w-full gap-2">
            <MapPin className="h-4 w-4" />
            {loading ? "Requesting permission…" : "Allow Location Sharing"}
          </Button>
          <Button variant="ghost" onClick={onDecline} className="w-full text-muted-foreground">
            Not Now
          </Button>
        </div>
      </div>
    </div>
  );
};

export default LocationConsentModal;
