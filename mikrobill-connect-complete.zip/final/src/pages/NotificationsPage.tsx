import { useState } from "react";
import AdminLayout from "@/components/AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useSubscribers } from "@/hooks/useDatabase";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, Send, MessageSquare, Smartphone, Loader2, Save, Pencil } from "lucide-react";
import StatusBadge from "@/components/StatusBadge";
import { useToast } from "@/hooks/use-toast";

const useNotifications = () => useQuery({
  queryKey: ["notifications"],
  queryFn: async () => {
    const { data, error } = await supabase.from("notifications").select("*").order("sent_at", { ascending: false });
    if (error) throw error;
    return data ?? [];
  },
});

const useTemplates = () => useQuery({
  queryKey: ["notification_templates"],
  queryFn: async () => {
    const { data, error } = await supabase.from("notification_templates").select("*").order("type");
    if (error) throw error;
    return data ?? [];
  },
});

const typeStyles: Record<string, string> = {
  expiry: "bg-warning/15 text-warning border-warning/30",
  payment: "bg-success/15 text-success border-success/30",
  outage: "bg-destructive/15 text-destructive border-destructive/30",
  ticket: "bg-info/15 text-info border-info/30",
  broadcast: "bg-primary/15 text-primary border-primary/30",
  system: "bg-muted text-muted-foreground border-border",
};

const TEMPLATE_VARS: Record<string, string[]> = {
  expiry_24h: ["{{name}}", "{{package}}", "{{expires}}"],
  expiry_1h: ["{{name}}", "{{package}}"],
  payment_received: ["{{name}}", "{{amount}}", "{{package}}", "{{expires}}"],
  account_suspended: ["{{name}}"],
  outage: ["{{name}}"],
  outage_resolved: ["{{name}}"],
  ticket_updated: ["{{name}}", "{{ticket_id}}", "{{status}}"],
  broadcast: ["{{message}}"],
  welcome: ["{{name}}", "{{username}}", "{{password}}"],
};

const NotificationsPage = () => {
  const { data: notifications = [] } = useNotifications();
  const { data: templates = [] } = useTemplates();
  const { data: subscribers = [] } = useSubscribers();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [broadcastOpen, setBroadcastOpen] = useState(false);
  const [templateOpen, setTemplateOpen] = useState(false);
  const [sending, setSending] = useState(false);
  const [savingTpl, setSavingTpl] = useState(false);
  const [editTplId, setEditTplId] = useState<string | null>(null);

  const [broadcast, setBroadcast] = useState({ title: "", message: "", channel: "both", target: "all", segment: "" });
  const [tplForm, setTplForm] = useState({ type: "", title: "", body: "", channel: "both", enabled: true });

  const sTpl = (k: keyof typeof tplForm) => (v: any) => setTplForm((f) => ({ ...f, [k]: v }));
  const sBc = (k: keyof typeof broadcast) => (v: any) => setBroadcast((f) => ({ ...f, [k]: v }));

  const openEditTpl = (tpl: any) => {
    setEditTplId(tpl.id);
    setTplForm({ type: tpl.type, title: tpl.title, body: tpl.body, channel: tpl.channel, enabled: tpl.enabled });
    setTemplateOpen(true);
  };

  const handleSendBroadcast = async () => {
    if (!broadcast.title.trim() || !broadcast.message.trim()) {
      toast({ title: "Validation Error", description: "Title and message are required.", variant: "destructive" });
      return;
    }
    setSending(true);
    try {
      // Insert notification record for each subscriber (or one broadcast record)
      const payload = {
        type: "broadcast", title: broadcast.title, message: broadcast.message,
        channel: broadcast.channel, target: broadcast.target,
        status: "pending", sent_at: new Date().toISOString(),
      };
      const { error } = await supabase.from("notifications").insert(payload);
      if (error) throw error;
      // Trigger actual SMS/push delivery via backend
      const apiBase = import.meta.env.VITE_BACKEND_URL ?? "/api";
      await fetch(`${apiBase}/admin/notifications/broadcast`, {
        method: "POST",
        headers: { "Content-Type": "application/json", "Authorization": `Bearer ${(await supabase.auth.getSession()).data.session?.access_token ?? ""}` },
        body: JSON.stringify({ title: broadcast.title, message: broadcast.message, channel: broadcast.channel, target: broadcast.target }),
      }).catch(() => {}); // non-fatal — message is already queued in DB
      toast({ title: "Broadcast Queued", description: `Message queued for delivery to ${broadcast.target === "all" ? "all subscribers" : "selected segment"}.` });
      queryClient.invalidateQueries({ queryKey: ["notifications"] });
      setBroadcastOpen(false);
      setBroadcast({ title: "", message: "", channel: "both", target: "all", segment: "" });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally { setSending(false); }
  };

  const handleSaveTemplate = async () => {
    if (!tplForm.title.trim() || !tplForm.body.trim()) {
      toast({ title: "Validation Error", description: "Title and body are required.", variant: "destructive" });
      return;
    }
    setSavingTpl(true);
    try {
      const payload = { title: tplForm.title, body: tplForm.body, channel: tplForm.channel, enabled: tplForm.enabled, updated_at: new Date().toISOString() };
      if (editTplId) {
        const { error } = await supabase.from("notification_templates").update(payload).eq("id", editTplId);
        if (error) throw error;
        toast({ title: "Template Updated" });
      }
      queryClient.invalidateQueries({ queryKey: ["notification_templates"] });
      setTemplateOpen(false);
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally { setSavingTpl(false); }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Notifications</h1>
            <p className="text-sm text-muted-foreground mt-1">SMS + FCM push management &amp; templates</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" className="gap-2" onClick={() => { setBroadcastOpen(true); }}>
              <Send className="h-4 w-4" />Send Broadcast
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-4 gap-4">
          {[
            { label: "Total Sent", value: (notifications as any[]).filter((n) => n.status === "sent").length, icon: Send },
            { label: "Pending", value: (notifications as any[]).filter((n) => n.status === "pending").length, icon: Bell },
            { label: "SMS Channel", value: (notifications as any[]).filter((n) => n.channel === "sms" || n.channel === "both").length, icon: MessageSquare },
            { label: "Push Channel", value: (notifications as any[]).filter((n) => n.channel === "push" || n.channel === "both").length, icon: Smartphone },
          ].map((s) => (
            <div key={s.label} className="glass-card p-4 flex items-center gap-3">
              <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center">
                <s.icon className="h-4 w-4 text-primary" />
              </div>
              <div>
                <p className="text-lg font-bold">{s.value}</p>
                <p className="text-[10px] text-muted-foreground">{s.label}</p>
              </div>
            </div>
          ))}
        </div>

        <Tabs defaultValue="history">
          <TabsList>
            <TabsTrigger value="history">History</TabsTrigger>
            <TabsTrigger value="templates">Message Templates</TabsTrigger>
          </TabsList>

          <TabsContent value="history" className="mt-4">
            <div className="glass-card overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-border/50">
                    <TableHead className="text-xs">Type</TableHead>
                    <TableHead className="text-xs">Title</TableHead>
                    <TableHead className="text-xs">Message</TableHead>
                    <TableHead className="text-xs">Channel</TableHead>
                    <TableHead className="text-xs">Target</TableHead>
                    <TableHead className="text-xs">Status</TableHead>
                    <TableHead className="text-xs">Sent</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(notifications as any[]).map((n) => (
                    <TableRow key={n.id} className="border-border/30">
                      <TableCell><Badge variant="outline" className={`${typeStyles[n.type] ?? ""} text-[10px] capitalize`}>{n.type}</Badge></TableCell>
                      <TableCell className="text-sm font-medium">{n.title}</TableCell>
                      <TableCell className="text-xs text-muted-foreground max-w-[200px] truncate">{n.message}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-1 text-xs text-muted-foreground">
                          {n.channel === "sms" ? <MessageSquare className="h-3.5 w-3.5" /> : n.channel === "push" ? <Smartphone className="h-3.5 w-3.5" /> : <Bell className="h-3.5 w-3.5" />}
                          <span className="capitalize">{n.channel}</span>
                        </div>
                      </TableCell>
                      <TableCell className="text-xs">{n.target_name || n.target}</TableCell>
                      <TableCell><StatusBadge status={n.status} /></TableCell>
                      <TableCell className="text-xs text-muted-foreground font-mono">{new Date(n.sent_at).toLocaleString()}</TableCell>
                    </TableRow>
                  ))}
                  {(notifications as any[]).length === 0 && <TableRow><TableCell colSpan={7} className="text-center py-8 text-muted-foreground">No notifications yet</TableCell></TableRow>}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="templates" className="mt-4">
            <div className="space-y-3">
              <p className="text-xs text-muted-foreground">These templates are used when automatic notifications are triggered. Edit the content to match your brand voice. Variables in {"{{double_braces}}"} are replaced automatically.</p>
              <div className="grid grid-cols-1 gap-3">
                {(templates as any[]).map((tpl) => (
                  <div key={tpl.id} className="glass-card p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="text-[10px] font-mono">{tpl.type}</Badge>
                          <Badge variant="outline" className={`text-[10px] capitalize ${tpl.channel === "sms" ? "bg-warning/10 text-warning border-warning/30" : tpl.channel === "push" ? "bg-info/10 text-info border-info/30" : "bg-primary/10 text-primary border-primary/30"}`}>{tpl.channel}</Badge>
                          {!tpl.enabled && <Badge variant="outline" className="text-[10px] text-muted-foreground">Disabled</Badge>}
                        </div>
                        <p className="text-sm font-semibold">{tpl.title}</p>
                        <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{tpl.body}</p>
                        {TEMPLATE_VARS[tpl.type] && (
                          <div className="flex flex-wrap gap-1 mt-2">
                            {TEMPLATE_VARS[tpl.type].map((v) => <code key={v} className="text-[9px] bg-muted px-1.5 py-0.5 rounded font-mono text-muted-foreground">{v}</code>)}
                          </div>
                        )}
                      </div>
                      <Button variant="ghost" size="sm" className="h-7 text-xs text-primary ml-4 shrink-0" onClick={() => openEditTpl(tpl)}>
                        <Pencil className="h-3 w-3 mr-1" />Edit
                      </Button>
                    </div>
                  </div>
                ))}
                {(templates as any[]).length === 0 && <p className="text-center text-muted-foreground py-8">No templates found. Run migration to seed defaults.</p>}
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>

      {/* Broadcast Dialog */}
      <Dialog open={broadcastOpen} onOpenChange={setBroadcastOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Send Broadcast Message</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label>Title *</Label>
              <Input placeholder="e.g. Network Maintenance Tonight" value={broadcast.title} onChange={(e) => sBc("title")(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Message *</Label>
              <Textarea placeholder="Your message to subscribers..." value={broadcast.message} onChange={(e) => sBc("message")(e.target.value)} rows={4} />
              <p className="text-[10px] text-muted-foreground">SMS limit: 160 characters per message. Longer messages will be split.</p>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label>Channel</Label>
                <Select value={broadcast.channel} onValueChange={sBc("channel")}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="both">SMS + Push</SelectItem>
                    <SelectItem value="sms">SMS Only</SelectItem>
                    <SelectItem value="push">Push Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Target Audience</Label>
                <Select value={broadcast.target} onValueChange={sBc("target")}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Subscribers</SelectItem>
                    <SelectItem value="active">Active Only</SelectItem>
                    <SelectItem value="expired">Expired Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="p-3 rounded-lg bg-warning/10 border border-warning/30 text-xs text-warning">
              This will send to <strong>{broadcast.target === "all" ? (subscribers as any[]).length : broadcast.target === "active" ? (subscribers as any[]).filter((s: any) => s.status === "active").length : (subscribers as any[]).filter((s: any) => s.status === "expired").length}</strong> subscriber(s). SMS costs apply.
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setBroadcastOpen(false)}>Cancel</Button>
            <Button onClick={handleSendBroadcast} disabled={sending} className="gap-2">
              {sending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
              Send Broadcast
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Template Edit Dialog */}
      <Dialog open={templateOpen} onOpenChange={setTemplateOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Edit Notification Template</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="p-3 rounded-lg bg-muted/40 text-xs text-muted-foreground">
              Template: <code className="font-mono bg-muted px-1 rounded">{tplForm.type}</code>
              {TEMPLATE_VARS[tplForm.type] && (
                <div className="mt-2">Available variables: {TEMPLATE_VARS[tplForm.type].map((v) => <code key={v} className="bg-muted px-1 rounded mr-1">{v}</code>)}</div>
              )}
            </div>
            <div className="space-y-1.5">
              <Label>Notification Title</Label>
              <Input value={tplForm.title} onChange={(e) => sTpl("title")(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>Message Body</Label>
              <Textarea value={tplForm.body} onChange={(e) => sTpl("body")(e.target.value)} rows={4} />
              <p className="text-[10px] text-muted-foreground">Use {"{{variable}}"} placeholders — they are replaced with real values when sent.</p>
            </div>
            <div className="space-y-1.5">
              <Label>Channel</Label>
              <Select value={tplForm.channel} onValueChange={sTpl("channel")}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="both">SMS + Push</SelectItem>
                  <SelectItem value="sms">SMS Only</SelectItem>
                  <SelectItem value="push">Push Only</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={tplForm.enabled} onCheckedChange={sTpl("enabled")} />
              <Label>Enabled (auto-send when triggered)</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setTemplateOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveTemplate} disabled={savingTpl} className="gap-2">
              {savingTpl ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              Save Template
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
};

export default NotificationsPage;
