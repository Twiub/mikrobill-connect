import { useState } from "react";
import AdminLayout from "@/components/AdminLayout";
import { usePackages, formatKES } from "@/hooks/useDatabase";
import { supabase } from "@/integrations/supabase/client";
import { Zap, Plus, Pencil, Save, Loader2, Wifi, Network } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import StatusBadge from "@/components/StatusBadge";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";

const EMPTY_PKG = {
  name: "", price: 0, duration_days: 30, speed_down: "10M", speed_up: "5M",
  max_devices: 2, type: "hotspot", tier: "basic", active: true,
  pppoe_profile: "", hotspot_profile: "", burst_down: "", burst_up: "",
  burst_threshold: "", burst_time_s: "" as string | number,
  data_cap_gb: "" as string | number, shared_users_max: 1, description: "",
};

const tierColors: Record<string, string> = {
  basic: "bg-muted text-muted-foreground border-border",
  standard: "bg-info/15 text-info border-info/30",
  premium: "bg-primary/15 text-primary border-primary/30",
  unlimited: "bg-success/15 text-success border-success/30",
};

const PackagesPage = () => {
  const { data: packages, isLoading } = usePackages();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState<typeof EMPTY_PKG>({ ...EMPTY_PKG });

  const openAdd = () => { setEditId(null); setForm({ ...EMPTY_PKG }); setOpen(true); };
  const openEdit = (pkg: any) => {
    setEditId(pkg.id);
    setForm({
      name: pkg.name ?? "", price: pkg.price ?? 0, duration_days: pkg.duration_days ?? 30,
      speed_down: pkg.speed_down ?? "10M", speed_up: pkg.speed_up ?? "5M",
      max_devices: pkg.max_devices ?? 2, type: pkg.type ?? "hotspot", tier: pkg.tier ?? "basic",
      active: pkg.active ?? true, pppoe_profile: pkg.pppoe_profile ?? "",
      hotspot_profile: pkg.hotspot_profile ?? "", burst_down: pkg.burst_down ?? "",
      burst_up: pkg.burst_up ?? "", burst_threshold: pkg.burst_threshold ?? "",
      burst_time_s: pkg.burst_time_s ?? "", data_cap_gb: pkg.data_cap_gb ?? "",
      shared_users_max: pkg.shared_users_max ?? 1, description: pkg.description ?? "",
    });
    setOpen(true);
  };

  const set = (k: keyof typeof EMPTY_PKG) => (v: any) => setForm((f) => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.name.trim() || !form.speed_down || !form.speed_up) {
      toast({ title: "Validation Error", description: "Name, download and upload speeds are required.", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload: any = {
        name: form.name.trim(), price: Number(form.price), duration_days: Number(form.duration_days),
        speed_down: form.speed_down, speed_up: form.speed_up, max_devices: Number(form.max_devices),
        type: form.type, tier: form.tier, active: form.active,
        pppoe_profile: form.pppoe_profile || null, hotspot_profile: form.hotspot_profile || null,
        burst_down: form.burst_down || null, burst_up: form.burst_up || null,
        burst_threshold: form.burst_threshold || null,
        burst_time_s: form.burst_time_s ? Number(form.burst_time_s) : null,
        data_cap_gb: form.data_cap_gb ? Number(form.data_cap_gb) : null,
        shared_users_max: Number(form.shared_users_max), description: form.description || null,
      };
      if (editId) {
        const { error } = await supabase.from("packages").update(payload).eq("id", editId);
        if (error) throw error;
        toast({ title: "Package Updated", description: `${form.name} saved.` });
      } else {
        const { error } = await supabase.from("packages").insert(payload);
        if (error) throw error;
        toast({ title: "Package Created", description: `${form.name} created.` });
      }
      queryClient.invalidateQueries({ queryKey: ["packages"] });
      setOpen(false);
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const toggleActive = async (pkg: any) => {
    await supabase.from("packages").update({ active: !pkg.active }).eq("id", pkg.id);
    queryClient.invalidateQueries({ queryKey: ["packages"] });
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Packages</h1>
            <p className="text-sm text-muted-foreground mt-1">WiFi plans — PPPoE, Hotspot &amp; both</p>
          </div>
          <Button size="sm" className="gap-2" onClick={openAdd}>
            <Plus className="h-4 w-4" />Add Package
          </Button>
        </div>

        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Loading packages...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {packages?.map((pkg: any) => (
              <div key={pkg.id} className={`glass-card p-6 flex flex-col relative overflow-hidden hover:border-primary/50 transition-colors ${!pkg.active ? "opacity-60" : ""}`}>
                <div className="absolute top-0 right-0 w-20 h-20 bg-primary/5 rounded-bl-[60px]" />
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-base font-bold">{pkg.name}</h3>
                  <div className="h-8 w-8 rounded-full bg-primary/10 flex items-center justify-center">
                    <Zap className="h-4 w-4 text-primary" />
                  </div>
                </div>
                <div className="flex flex-wrap items-center gap-1.5 mb-3">
                  <Badge variant="outline" className={`${tierColors[pkg.tier]} text-[10px] capitalize`}>{pkg.tier}</Badge>
                  {pkg.type === "pppoe" && <Badge variant="outline" className="bg-info/10 text-info border-info/30 text-[10px]"><Network className="h-2.5 w-2.5 mr-1" />PPPoE</Badge>}
                  {pkg.type === "hotspot" && <Badge variant="outline" className="bg-primary/10 text-primary border-primary/30 text-[10px]"><Wifi className="h-2.5 w-2.5 mr-1" />Hotspot</Badge>}
                  {pkg.type === "both" && <Badge variant="outline" className="bg-success/10 text-success border-success/30 text-[10px]">Both</Badge>}
                </div>
                <p className="text-3xl font-extrabold text-gradient mb-1">{formatKES(Number(pkg.price))}</p>
                <p className="text-xs text-muted-foreground mb-4">{pkg.duration_days} day{pkg.duration_days > 1 ? "s" : ""}</p>
                <div className="space-y-2 flex-1 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Download</span><span className="font-semibold">{pkg.speed_down}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Upload</span><span className="font-semibold">{pkg.speed_up}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Max Devices</span><span className="font-semibold">{pkg.max_devices}</span></div>
                  {pkg.data_cap_gb && <div className="flex justify-between"><span className="text-muted-foreground">Data Cap</span><span className="font-semibold">{pkg.data_cap_gb} GB</span></div>}
                </div>
                <div className="mt-4 pt-4 border-t border-border/50 flex items-center justify-between">
                  <StatusBadge status={pkg.active ? "active" : "expired"} />
                  <div className="flex gap-1">
                    <Button variant="ghost" size="sm" className="h-7 text-xs text-primary hover:text-primary" onClick={() => openEdit(pkg)}>
                      <Pencil className="h-3 w-3 mr-1" />Edit
                    </Button>
                    <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={() => toggleActive(pkg)}>
                      {pkg.active ? "Disable" : "Enable"}
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{editId ? "Edit Package" : "Add New Package"}</DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="basic">
            <TabsList className="mb-4">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="mikrotik">MikroTik</TabsTrigger>
              <TabsTrigger value="burst">Burst &amp; Limits</TabsTrigger>
            </TabsList>
            <TabsContent value="basic" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Package Name *</Label>
                  <Input placeholder="e.g. Home 10Mbps" value={form.name} onChange={(e) => set("name")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Price (KES) *</Label>
                  <Input type="number" placeholder="500" value={form.price} onChange={(e) => set("price")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Duration (days)</Label>
                  <Input type="number" placeholder="30" value={form.duration_days} onChange={(e) => set("duration_days")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Max Devices</Label>
                  <Input type="number" placeholder="2" value={form.max_devices} onChange={(e) => set("max_devices")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Download Speed *</Label>
                  <Input placeholder="10M" value={form.speed_down} onChange={(e) => set("speed_down")(e.target.value)} />
                  <p className="text-[10px] text-muted-foreground">e.g. 10M, 512k, 1G</p>
                </div>
                <div className="space-y-1.5">
                  <Label>Upload Speed *</Label>
                  <Input placeholder="5M" value={form.speed_up} onChange={(e) => set("speed_up")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Connection Type</Label>
                  <Select value={form.type} onValueChange={set("type")}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="hotspot">Hotspot</SelectItem>
                      <SelectItem value="pppoe">PPPoE</SelectItem>
                      <SelectItem value="both">Both (Hotspot + PPPoE)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label>Tier</Label>
                  <Select value={form.tier} onValueChange={set("tier")}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">Basic</SelectItem>
                      <SelectItem value="standard">Standard</SelectItem>
                      <SelectItem value="premium">Premium</SelectItem>
                      <SelectItem value="unlimited">Unlimited</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Description</Label>
                <Textarea placeholder="Package description..." value={form.description} onChange={(e) => set("description")(e.target.value)} rows={2} />
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={form.active} onCheckedChange={set("active")} />
                <Label>Active (visible for purchase)</Label>
              </div>
            </TabsContent>
            <TabsContent value="mikrotik" className="space-y-4">
              <div className="p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground">
                Profile names must match exactly as configured in RouterOS. PPPoE: <code>/ppp profile</code> · Hotspot: <code>/ip hotspot user profile</code>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>PPPoE Profile Name</Label>
                  <Input placeholder="pppoe-10mbps" value={form.pppoe_profile} onChange={(e) => set("pppoe_profile")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Hotspot Profile Name</Label>
                  <Input placeholder="hotspot-10mbps" value={form.hotspot_profile} onChange={(e) => set("hotspot_profile")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Shared Users Max</Label>
                  <Input type="number" min="1" placeholder="1" value={form.shared_users_max} onChange={(e) => set("shared_users_max")(e.target.value)} />
                  <p className="text-[10px] text-muted-foreground">simultaneous-use (PPPoE)</p>
                </div>
                <div className="space-y-1.5">
                  <Label>Data Cap (GB, blank = unlimited)</Label>
                  <Input type="number" placeholder="50" value={form.data_cap_gb} onChange={(e) => set("data_cap_gb")(e.target.value || "")} />
                </div>
              </div>
            </TabsContent>
            <TabsContent value="burst" className="space-y-4">
              <div className="p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground">
                Burst allows users to exceed their limit temporarily when average usage is below threshold. Maps to RouterOS <code>burst-limit</code>, <code>burst-threshold</code>, <code>burst-time</code>.
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Burst Download Speed</Label>
                  <Input placeholder="20M" value={form.burst_down} onChange={(e) => set("burst_down")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Burst Upload Speed</Label>
                  <Input placeholder="10M" value={form.burst_up} onChange={(e) => set("burst_up")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>Burst Threshold</Label>
                  <Input placeholder="8M" value={form.burst_threshold} onChange={(e) => set("burst_threshold")(e.target.value)} />
                  <p className="text-[10px] text-muted-foreground">avg usage below this activates burst</p>
                </div>
                <div className="space-y-1.5">
                  <Label>Burst Time (seconds)</Label>
                  <Input type="number" placeholder="10" value={form.burst_time_s} onChange={(e) => set("burst_time_s")(e.target.value)} />
                  <p className="text-[10px] text-muted-foreground">averaging window</p>
                </div>
              </div>
            </TabsContent>
          </Tabs>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving} className="gap-2">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {editId ? "Save Changes" : "Create Package"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
};

export default PackagesPage;
