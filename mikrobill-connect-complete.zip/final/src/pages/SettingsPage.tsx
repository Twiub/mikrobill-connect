import { useState, useEffect } from "react";
import AdminLayout from "@/components/AdminLayout";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Settings, Wifi, Server, Shield, Globe, Bell, Save, Eye, EyeOff, Loader2, RefreshCw, CheckCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const useMpesaConfig = () => useQuery({
  queryKey: ["mpesa_config"],
  queryFn: async () => {
    const { data, error } = await supabase.from("mpesa_config").select("*").limit(1).single();
    if (error && error.code !== "PGRST116") throw error;
    return data;
  },
});

const SettingsPage = () => {
  const { data: mpesaCfg, isLoading } = useMpesaConfig();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState(false);
  const [showSecret, setShowSecret] = useState(false);
  const [showPasskey, setShowPasskey] = useState(false);
  const [testResult, setTestResult] = useState<"success" | "error" | null>(null);

  const [mpesa, setMpesa] = useState({
    environment: "sandbox",
    consumer_key: "",
    consumer_secret: "",
    passkey: "",
    shortcode: "",
    initiator_name: "",
    initiator_password: "",
    stk_callback_url: "",
    c2b_confirmation_url: "",
    c2b_validation_url: "",
    b2c_result_url: "",
    b2c_timeout_url: "",
    account_reference: "WIFI",
    transaction_desc: "WiFi Package",
  });

  // Other settings state
  const [dlna, setDlna] = useState({ server_ip: "192.168.88.200", port: "8200" });
  const [tax, setTax] = useState({ vat_rate: "16", kra_pin: "" });
  const [sms, setSms] = useState({ provider: "africastalking", api_key: "", username: "", sender_id: "" });
  const [fcm, setFcm] = useState({ server_key: "", project_id: "" });

  useEffect(() => {
    if (mpesaCfg) {
      setMpesa({
        environment: mpesaCfg.environment ?? "sandbox",
        consumer_key: mpesaCfg.consumer_key ?? "",
        consumer_secret: mpesaCfg.consumer_secret ?? "",
        passkey: mpesaCfg.passkey ?? "",
        shortcode: mpesaCfg.shortcode ?? "",
        initiator_name: mpesaCfg.initiator_name ?? "",
        initiator_password: mpesaCfg.initiator_password ?? "",
        stk_callback_url: mpesaCfg.stk_callback_url ?? "",
        c2b_confirmation_url: mpesaCfg.c2b_confirmation_url ?? "",
        c2b_validation_url: mpesaCfg.c2b_validation_url ?? "",
        b2c_result_url: mpesaCfg.b2c_result_url ?? "",
        b2c_timeout_url: mpesaCfg.b2c_timeout_url ?? "",
        account_reference: mpesaCfg.account_reference ?? "WIFI",
        transaction_desc: mpesaCfg.transaction_desc ?? "WiFi Package",
      });
    }
  }, [mpesaCfg]);

  const saveMpesa = async () => {
    setSaving(true);
    try {
      if (mpesaCfg?.id) {
        const { error } = await supabase.from("mpesa_config").update({ ...mpesa, updated_at: new Date().toISOString() }).eq("id", mpesaCfg.id);
        if (error) throw error;
      } else {
        const { error } = await supabase.from("mpesa_config").insert(mpesa);
        if (error) throw error;
      }
      queryClient.invalidateQueries({ queryKey: ["mpesa_config"] });
      toast({ title: "M-Pesa Config Saved", description: "Settings have been saved successfully." });
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally { setSaving(false); }
  };

  const testMpesa = async () => {
    setTesting(true);
    setTestResult(null);
    // Simulate API test - in production this would call your backend
    await new Promise((r) => setTimeout(r, 1500));
    setTestResult(mpesa.consumer_key && mpesa.consumer_secret ? "success" : "error");
    setTesting(false);
  };

  const setM = (k: keyof typeof mpesa) => (v: any) => setMpesa((f) => ({ ...f, [k]: v }));

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-bold">System Settings</h1>
          <p className="text-sm text-muted-foreground mt-1">Global configuration for WiFi Billing System</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* M-Pesa Daraja API */}
          <div className="glass-card p-5 lg:col-span-2">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-2">
                <Wifi className="h-5 w-5 text-success" />
                <h3 className="text-sm font-semibold">M-Pesa Daraja API</h3>
                <Badge variant="outline" className={`text-[10px] ${mpesa.environment === "production" ? "bg-success/15 text-success border-success/30" : "bg-warning/15 text-warning border-warning/30"}`}>
                  {mpesa.environment === "production" ? "Production" : "Sandbox"}
                </Badge>
              </div>
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="gap-1.5" onClick={testMpesa} disabled={testing}>
                  {testing ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
                  Test Connection
                </Button>
                {testResult === "success" && <Badge className="bg-success/15 text-success border-success/30 border gap-1"><CheckCircle className="h-3 w-3" />Connected</Badge>}
                {testResult === "error" && <Badge className="bg-destructive/15 text-destructive border-destructive/30 border gap-1"><AlertCircle className="h-3 w-3" />Failed</Badge>}
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div className="space-y-1.5">
                <Label>Environment</Label>
                <Select value={mpesa.environment} onValueChange={setM("environment")}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sandbox">Sandbox (Testing)</SelectItem>
                    <SelectItem value="production">Production (Live)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label>Shortcode (Paybill / Till)</Label>
                <Input placeholder="174379" value={mpesa.shortcode} onChange={(e) => setM("shortcode")(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Consumer Key</Label>
                <Input placeholder="From Daraja portal" value={mpesa.consumer_key} onChange={(e) => setM("consumer_key")(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Consumer Secret</Label>
                <div className="relative">
                  <Input type={showSecret ? "text" : "password"} placeholder="From Daraja portal" value={mpesa.consumer_secret} onChange={(e) => setM("consumer_secret")(e.target.value)} />
                  <button type="button" onClick={() => setShowSecret(!showSecret)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                    {showSecret ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Lipa Na M-Pesa Passkey</Label>
                <div className="relative">
                  <Input type={showPasskey ? "text" : "password"} placeholder="From Daraja STK Push settings" value={mpesa.passkey} onChange={(e) => setM("passkey")(e.target.value)} />
                  <button type="button" onClick={() => setShowPasskey(!showPasskey)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                    {showPasskey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label>Initiator Name (B2C)</Label>
                <Input placeholder="Daraja API user" value={mpesa.initiator_name} onChange={(e) => setM("initiator_name")(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Initiator Password (B2C)</Label>
                <Input type="password" placeholder="Initiator password" value={mpesa.initiator_password} onChange={(e) => setM("initiator_password")(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Account Reference</Label>
                <Input placeholder="WIFI" value={mpesa.account_reference} onChange={(e) => setM("account_reference")(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>Transaction Description</Label>
                <Input placeholder="WiFi Package" value={mpesa.transaction_desc} onChange={(e) => setM("transaction_desc")(e.target.value)} />
              </div>
            </div>

            <div className="mt-4 pt-4 border-t border-border/50">
              <p className="text-xs font-medium text-muted-foreground mb-3">Callback URLs (must be HTTPS and publicly accessible)</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>STK Push Callback URL</Label>
                  <Input placeholder="https://api.example.com/mpesa/stk/callback" value={mpesa.stk_callback_url} onChange={(e) => setM("stk_callback_url")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>C2B Confirmation URL</Label>
                  <Input placeholder="https://api.example.com/mpesa/c2b/confirmation" value={mpesa.c2b_confirmation_url} onChange={(e) => setM("c2b_confirmation_url")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>C2B Validation URL</Label>
                  <Input placeholder="https://api.example.com/mpesa/c2b/validation" value={mpesa.c2b_validation_url} onChange={(e) => setM("c2b_validation_url")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>B2C Result URL</Label>
                  <Input placeholder="https://api.example.com/mpesa/b2c/result" value={mpesa.b2c_result_url} onChange={(e) => setM("b2c_result_url")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>B2C Timeout URL</Label>
                  <Input placeholder="https://api.example.com/mpesa/b2c/timeout" value={mpesa.b2c_timeout_url} onChange={(e) => setM("b2c_timeout_url")(e.target.value)} />
                </div>
              </div>
            </div>

            <div className="mt-4 flex justify-end">
              <Button onClick={saveMpesa} disabled={saving || isLoading} className="gap-2">
                {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                Save M-Pesa Config
              </Button>
            </div>
          </div>

          {/* DLNA Configuration */}
          <div className="glass-card p-5">
            <div className="flex items-center gap-2 mb-4">
              <Server className="h-5 w-5 text-primary" />
              <h3 className="text-sm font-semibold">DLNA Media Server</h3>
              <Badge variant="outline" className="bg-success/15 text-success border-success/30 text-[10px] ml-auto">Online</Badge>
            </div>
            <div className="space-y-3">
              <div>
                <Label className="text-xs text-muted-foreground">DLNA Server IP</Label>
                <Input value={dlna.server_ip} onChange={(e) => setDlna((d) => ({ ...d, server_ip: e.target.value }))} className="mt-1 bg-muted/50 border-border" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">DLNA Port</Label>
                <Input value={dlna.port} onChange={(e) => setDlna((d) => ({ ...d, port: e.target.value }))} className="mt-1 bg-muted/50 border-border" />
              </div>
              <p className="text-[10px] text-muted-foreground">Server IP is pushed to all MikroTik routers via DHCP option 212.</p>
              <Button size="sm" className="gap-2"><Save className="h-3.5 w-3.5" />Update DLNA</Button>
            </div>
          </div>

          {/* Tax Configuration */}
          <div className="glass-card p-5">
            <div className="flex items-center gap-2 mb-4">
              <Shield className="h-5 w-5 text-warning" />
              <h3 className="text-sm font-semibold">Tax &amp; Compliance</h3>
            </div>
            <div className="space-y-3">
              <div>
                <Label className="text-xs text-muted-foreground">VAT Rate (%)</Label>
                <Input type="number" value={tax.vat_rate} onChange={(e) => setTax((t) => ({ ...t, vat_rate: e.target.value }))} className="mt-1 bg-muted/50 border-border" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">KRA PIN</Label>
                <Input value={tax.kra_pin} onChange={(e) => setTax((t) => ({ ...t, kra_pin: e.target.value }))} placeholder="P*********" className="mt-1 bg-muted/50 border-border" />
              </div>
              <Button size="sm" className="gap-2"><Save className="h-3.5 w-3.5" />Save Tax Config</Button>
            </div>
          </div>

          {/* SMS Provider */}
          <div className="glass-card p-5">
            <div className="flex items-center gap-2 mb-4">
              <Bell className="h-5 w-5 text-info" />
              <h3 className="text-sm font-semibold">SMS Provider (Africa's Talking)</h3>
            </div>
            <div className="space-y-3">
              <div>
                <Label className="text-xs text-muted-foreground">API Key</Label>
                <Input type="password" value={sms.api_key} onChange={(e) => setSms((s) => ({ ...s, api_key: e.target.value }))} placeholder="Your AT API key" className="mt-1 bg-muted/50 border-border" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Username</Label>
                <Input value={sms.username} onChange={(e) => setSms((s) => ({ ...s, username: e.target.value }))} placeholder="sandbox" className="mt-1 bg-muted/50 border-border" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Sender ID</Label>
                <Input value={sms.sender_id} onChange={(e) => setSms((s) => ({ ...s, sender_id: e.target.value }))} placeholder="WIFIBILL" className="mt-1 bg-muted/50 border-border" />
              </div>
              <Button size="sm" className="gap-2"><Save className="h-3.5 w-3.5" />Save SMS Config</Button>
            </div>
          </div>

          {/* FCM Push */}
          <div className="glass-card p-5">
            <div className="flex items-center gap-2 mb-4">
              <Globe className="h-5 w-5 text-chart-3" />
              <h3 className="text-sm font-semibold">Firebase Cloud Messaging (Push)</h3>
            </div>
            <div className="space-y-3">
              <div>
                <Label className="text-xs text-muted-foreground">FCM Server Key</Label>
                <Input type="password" value={fcm.server_key} onChange={(e) => setFcm((f) => ({ ...f, server_key: e.target.value }))} placeholder="From Firebase console" className="mt-1 bg-muted/50 border-border" />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Firebase Project ID</Label>
                <Input value={fcm.project_id} onChange={(e) => setFcm((f) => ({ ...f, project_id: e.target.value }))} placeholder="my-wifi-billing-app" className="mt-1 bg-muted/50 border-border" />
              </div>
              <p className="text-[10px] text-muted-foreground">Used for push notifications to the subscriber PWA app.</p>
              <Button size="sm" className="gap-2"><Save className="h-3.5 w-3.5" />Save FCM Config</Button>
            </div>
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default SettingsPage;
