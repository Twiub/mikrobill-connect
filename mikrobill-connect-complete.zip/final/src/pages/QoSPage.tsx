/**
 * src/pages/QoSPage.tsx
 *
 * Admin QoS / CAKE Bufferbloat monitor:
 *   • WAN queue utilisation per router
 *   • Per-package throughput bars
 *   • Drop rate alerts (>5% = warning)
 *   • Estimated bufferbloat latency score
 *   • Top 10 bandwidth users per router
 *   • CAKE configuration reference panel
 *   • Auto-refreshes every 30 seconds
 */

import { useEffect, useState, useCallback } from "react";
import AdminLayout from "@/components/AdminLayout";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { RefreshCw, Zap, AlertTriangle, CheckCircle2, TrendingDown, Activity } from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell,
} from "recharts";

// ── Types ─────────────────────────────────────────────────────────────────────

interface QueueStat {
  router_id:   number;
  router_name: string;
  queue_name:  string;
  bytes:       number;
  packets:     number;
  dropped:     number;
  queued:      number;
  drop_rate:   number;   // pre-calculated by DB generated column
  recorded_at: string;
}

// ── Helpers ───────────────────────────────────────────────────────────────────

/** Format bytes to human readable */
function fmtBytes(b: number) {
  if (b >= 1e9) return `${(b / 1e9).toFixed(2)} GB`;
  if (b >= 1e6) return `${(b / 1e6).toFixed(1)} MB`;
  if (b >= 1e3) return `${(b / 1e3).toFixed(0)} KB`;
  return `${b} B`;
}

/** Estimate added latency from queued packets (rough proxy) */
function estimateLatencyMs(queued: number, bytes: number): number {
  // Rough: assume average packet 1400 bytes, 100 Mbps link
  const avgPktBytes  = bytes > 0 && queued > 0 ? bytes / queued : 1400;
  const linkBps      = 100_000_000; // 100 Mbps
  return Math.round((queued * avgPktBytes * 8) / linkBps * 1000);
}

function dropBadge(rate: number) {
  if (rate >= 10) return <Badge variant="destructive" className="text-[10px]">{rate.toFixed(1)}% drops 🔴</Badge>;
  if (rate >= 5)  return <Badge className="bg-orange-500 text-white text-[10px]">{rate.toFixed(1)}% drops ⚠️</Badge>;
  return <Badge variant="outline" className="text-success text-[10px]">{rate.toFixed(1)}% drops ✓</Badge>;
}

// ── Custom hook ───────────────────────────────────────────────────────────────

function useQosStats() {
  const [queues,  setQueues]  = useState<QueueStat[]>([]);
  const [loading, setLoading] = useState(false);
  const [error,   setError]   = useState<string | null>(null);

  const fetch_ = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res  = await fetch("/api/admin/qos", {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setQueues(json.queues ?? []);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  return { queues, loading, error, refresh: fetch_ };
}

// ── Component ─────────────────────────────────────────────────────────────────

const QoSPage = () => {
  const { queues, loading, error, refresh } = useQosStats();

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 30_000);
    return () => clearInterval(id);
  }, [refresh]);

  // Group by router
  const byRouter = queues.reduce<Record<number, { name: string; queues: QueueStat[] }>>((acc, q) => {
    if (!acc[q.router_id]) acc[q.router_id] = { name: q.router_name, queues: [] };
    acc[q.router_id].queues.push(q);
    return acc;
  }, {});

  const highDropQueues   = queues.filter(q => q.drop_rate > 5);
  const totalBytesAll    = queues.reduce((s, q) => s + Number(q.bytes), 0);

  return (
    <AdminLayout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">QoS / CAKE Monitor</h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              CAKE AQM · Bufferbloat detection · Per-package throughput · Updated every 30s
            </p>
          </div>
          <div className="flex items-center gap-3">
            {highDropQueues.length > 0 && (
              <Badge variant="destructive" className="gap-1">
                <AlertTriangle className="h-3 w-3" />
                {highDropQueues.length} high drop-rate queue{highDropQueues.length > 1 ? "s" : ""}
              </Badge>
            )}
            <Button size="sm" variant="outline" className="gap-1.5 text-xs" onClick={refresh} disabled={loading}>
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>
        </div>

        {/* Summary stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            { label: "Total queues",     value: queues.length,                    icon: Activity },
            { label: "Total throughput", value: fmtBytes(totalBytesAll),          icon: Zap },
            { label: "High drop-rate",   value: highDropQueues.length,            icon: AlertTriangle },
            { label: "Clean queues",     value: queues.filter(q => q.drop_rate < 1).length, icon: CheckCircle2 },
          ].map(s => (
            <div key={s.label} className="glass-card p-4 flex items-center gap-3">
              <div className="h-9 w-9 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <s.icon className="h-4.5 w-4.5 text-primary" />
              </div>
              <div>
                <p className="text-xs text-muted-foreground">{s.label}</p>
                <p className="text-lg font-bold">{s.value}</p>
              </div>
            </div>
          ))}
        </div>

        {error && (
          <div className="glass-card p-4 border-destructive/30 text-destructive text-sm">
            Failed to load QoS data: {error}
          </div>
        )}

        {/* Per-router panels */}
        {Object.entries(byRouter).map(([routerId, group]) => {
          const wanQueue = group.queues.find(q => q.queue_name === "wan-cake");
          const pkgQueues = group.queues.filter(q => q.queue_name.startsWith("pkg-"));
          const userQueues = group.queues
            .filter(q => q.queue_name.startsWith("user-"))
            .sort((a, b) => Number(b.bytes) - Number(a.bytes))
            .slice(0, 10);

          const estLatency = wanQueue
            ? estimateLatencyMs(wanQueue.queued, Number(wanQueue.bytes))
            : 0;

          return (
            <div key={routerId} className="glass-card p-5 space-y-5">
              {/* Router header */}
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold">{group.name}</h3>
                <div className="flex items-center gap-2">
                  {wanQueue && dropBadge(wanQueue.drop_rate)}
                  <Badge variant="outline" className="text-[10px]">
                    Est. latency: {estLatency < 5 ? "< 5ms 🟢" : estLatency < 20 ? `${estLatency}ms 🟡` : `${estLatency}ms 🔴`}
                  </Badge>
                </div>
              </div>

              {/* WAN CAKE queue */}
              {wanQueue && (
                <div className="rounded-lg border border-border/50 p-4">
                  <div className="flex items-center justify-between mb-3">
                    <p className="text-xs font-semibold font-mono">wan-cake (WAN shaper)</p>
                    <span className="text-xs text-muted-foreground">{fmtBytes(Number(wanQueue.bytes))} total</span>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                    <div>
                      <p className="text-muted-foreground">Packets</p>
                      <p className="font-mono font-bold">{Number(wanQueue.packets).toLocaleString()}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Dropped</p>
                      <p className={`font-mono font-bold ${wanQueue.drop_rate > 5 ? "text-destructive" : "text-success"}`}>
                        {Number(wanQueue.dropped).toLocaleString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Queued now</p>
                      <p className="font-mono font-bold">{wanQueue.queued}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Drop rate</p>
                      <p className={`font-mono font-bold ${wanQueue.drop_rate > 5 ? "text-destructive" : "text-success"}`}>
                        {wanQueue.drop_rate.toFixed(2)}%
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Per-package throughput */}
              {pkgQueues.length > 0 && (
                <div>
                  <p className="text-xs font-semibold mb-3">Package Queue Throughput</p>
                  <div className="h-40">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={pkgQueues.map(q => ({
                        name:  q.queue_name.replace("pkg-", "").replace(/-/g, " "),
                        bytes: Number(q.bytes),
                        drops: q.drop_rate,
                      }))}>
                        <XAxis dataKey="name" tick={{ fontSize: 10 }} />
                        <YAxis tickFormatter={v => fmtBytes(v)} tick={{ fontSize: 10 }} width={60} />
                        <Tooltip formatter={(v: any) => fmtBytes(v)} />
                        <Bar dataKey="bytes" radius={[4, 4, 0, 0]}>
                          {pkgQueues.map((q, i) => (
                            <Cell key={i} fill={q.drop_rate > 5 ? "#ef4444" : "#3b82f6"} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              )}

              {/* Top 10 users */}
              {userQueues.length > 0 && (
                <div>
                  <p className="text-xs font-semibold mb-3">Top Bandwidth Users</p>
                  <div className="space-y-2">
                    {userQueues.map((q, i) => {
                      const maxBytes = Number(userQueues[0].bytes);
                      const pct = maxBytes > 0 ? (Number(q.bytes) / maxBytes) * 100 : 0;
                      return (
                        <div key={q.queue_name} className="flex items-center gap-3">
                          <span className="text-[10px] text-muted-foreground w-4">{i + 1}</span>
                          <span className="text-xs font-mono w-36 truncate">
                            {q.queue_name.replace("user-", "")}
                          </span>
                          <div className="flex-1">
                            <Progress value={pct} className="h-1.5" />
                          </div>
                          <span className="text-xs font-mono w-20 text-right">{fmtBytes(Number(q.bytes))}</span>
                          {dropBadge(q.drop_rate)}
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {/* CAKE config reference */}
        <div className="glass-card p-5">
          <h3 className="text-sm font-bold mb-4">CAKE Queue Configuration Reference</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2">RouterOS v7 — WAN CAKE Shaper</p>
              <pre className="text-[10px] font-mono bg-muted/40 rounded-lg p-3 overflow-x-auto whitespace-pre-wrap">
{`/queue tree
add name=wan-cake parent=ether1-gateway \\
    queue=cake max-limit=95M

/queue type set cake \\
    cake-overhead=44 \\
    cake-overhead-scheme=ptm \\
    cake-nat=yes \\
    cake-split-gso=yes \\
    cake-flowmode=triple-isolate \\
    cake-diffserv=diffserv4`}
              </pre>
            </div>
            <div>
              <p className="text-xs font-semibold text-muted-foreground mb-2">DSCP Traffic Classification</p>
              <pre className="text-[10px] font-mono bg-muted/40 rounded-lg p-3 overflow-x-auto whitespace-pre-wrap">
{`# VoIP/RTP  → DSCP EF  (46)
# Small HTTP → DSCP CS5 (40)
# DNS        → DSCP CS5 (40)
# Streaming  → DSCP AF41(34)
# BitTorrent → DSCP CS1  (8)

/ip firewall mangle
add chain=forward protocol=udp \\
    dst-port=5060,10000-20000 \\
    action=change-dscp new-dscp=46`}
              </pre>
            </div>
          </div>
          <div className="mt-4 grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
            {[
              { label: "Without CAKE",  latency: "200–1000ms", status: "bad" },
              { label: "With CAKE",     latency: "< 5ms added", status: "good" },
              { label: "Target grade",  latency: "A / A+", status: "good" },
              { label: "Drop target",   latency: "< 1%", status: "good" },
            ].map(r => (
              <div key={r.label} className={`rounded-lg border p-3 ${r.status === "good" ? "border-success/30 bg-success/5" : "border-destructive/30 bg-destructive/5"}`}>
                <p className="text-muted-foreground text-[10px]">{r.label}</p>
                <p className="font-bold">{r.latency}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default QoSPage;
