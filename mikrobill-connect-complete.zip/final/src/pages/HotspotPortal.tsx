import { useState, useEffect, useCallback } from "react";
import { Wifi, Phone, CheckCircle, Loader2, Lock, LogIn, X, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";

// ── Cookie helpers ────────────────────────────────────────────────────────────
const COOKIE_KEY = "hs_portal_token";
const COOKIE_DAYS = 30;

function setCookie(name: string, value: string, days: number) {
  const d = new Date();
  d.setTime(d.getTime() + days * 86400000);
  document.cookie = `${name}=${value};expires=${d.toUTCString()};path=/;SameSite=Strict`;
}

function getCookie(name: string): string | null {
  const match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
  return match ? decodeURIComponent(match[2]) : null;
}

function deleteCookie(name: string) {
  document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/`;
}

// ── PWA install prompt ────────────────────────────────────────────────────────
let deferredPrompt: any = null;
window.addEventListener("beforeinstallprompt", (e: any) => { e.preventDefault(); deferredPrompt = e; });

type Step = "loading" | "select" | "phone" | "processing" | "success" | "login" | "portal";

interface Package { id: string; name: string; price: number; duration_days: number; speed_down: string; speed_up: string; max_devices: number; type: string; }
interface Subscriber { id: string; full_name: string; username: string; phone: string; status: string; package_id: string | null; expires_at: string | null; packages?: { name: string } | null; }

const HotspotPortal = () => {
  const [step, setStep] = useState<Step>("loading");
  const [packages, setPackages] = useState<Package[]>([]);
  const [selectedPkg, setSelectedPkg] = useState<Package | null>(null);
  const [phone, setPhone] = useState("");
  const [loginPhone, setLoginPhone] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [subscriber, setSubscriber] = useState<Subscriber | null>(null);
  const [pwdVisible, setPwdVisible] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [showInstallBanner, setShowInstallBanner] = useState(false);
  const [loggingIn, setLoggingIn] = useState(false);
  const { toast } = useToast();

  // Fetch packages on mount
  useEffect(() => {
    const init = async () => {
      const { data } = await supabase.from("packages").select("*").in("type", ["hotspot", "both"]).eq("active", true).order("price");
      setPackages((data ?? []) as Package[]);

      // Check cookie-based session
      const token = getCookie(COOKIE_KEY);
      if (token) {
        const { data: session } = await supabase.from("portal_sessions" as any).select("*, subscribers(*, packages(name))").eq("token", token).gt("expires_at", new Date().toISOString()).single();
        if (session) {
          setSubscriber((session as any).subscribers);
          setStep("portal");
          return;
        } else {
          deleteCookie(COOKIE_KEY);
        }
      }
      setStep("select");
    };
    init();

    // Show PWA install banner after 5s if available
    const timer = setTimeout(() => { if (deferredPrompt) setShowInstallBanner(true); }, 5000);
    return () => clearTimeout(timer);
  }, []);

  const installPWA = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
    setShowInstallBanner(false);
  };

  const handlePurchase = async () => {
    if (!selectedPkg || !phone || phone.length < 9) return;
    setStep("processing");
    try {
      // In production this calls /api/mpesa/stk-push
      // For now we create a pending transaction and simulate
      const formattedPhone = phone.startsWith("0") ? "254" + phone.slice(1) : phone;
      
      // Check if subscriber exists
      const { data: existing } = await supabase.from("subscribers").select("*").eq("phone", phone).maybeSingle();
      
      // Simulating STK push — in production call backend
      await new Promise((r) => setTimeout(r, 2000));
      
      // After payment confirmed (via webhook in production), subscriber gets auto-created/updated
      // and we start a portal session
      const name = existing?.full_name ?? `User ${phone.slice(-4)}`;
      const username = existing?.username ?? `user${phone.slice(-4)}`;
      
      // Create portal session
      let subId = existing?.id;
      if (!subId) {
        const { data: newSub } = await supabase.from("subscribers").insert({
          full_name: name, phone, username, type: "hotspot", package_id: selectedPkg.id, status: "active",
          expires_at: new Date(Date.now() + selectedPkg.duration_days * 86400000).toISOString(),
        }).select().single();
        subId = (newSub as any)?.id;
      }

      if (subId) {
        const token = Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
        await supabase.from("portal_sessions" as any).insert({
          subscriber_id: subId, token, ip_address: "", user_agent: navigator.userAgent,
          expires_at: new Date(Date.now() + 30 * 86400000).toISOString(),
        });
        setCookie(COOKIE_KEY, token, COOKIE_DAYS);
      }

      const { data: sub } = await supabase.from("subscribers").select("*, packages(name)").eq("id", subId!).single();
      setSubscriber(sub as Subscriber);
      setStep("success");
    } catch (err: any) {
      toast({ title: "Payment Error", description: err.message, variant: "destructive" });
      setStep("phone");
    }
  };

  const handleLogin = async () => {
    if (!loginPhone.trim() || !loginPassword.trim()) {
      setLoginError("Please enter your phone number and password.");
      return;
    }
    setLoggingIn(true);
    setLoginError("");
    try {
      // Authenticate via backend API (bcrypt password check server-side)
      const apiBase = import.meta.env.VITE_BACKEND_URL ?? "/api";
      const res = await fetch(`${apiBase}/portal/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone: loginPhone.trim(), password: loginPassword }),
      });

      const data = await res.json();

      if (!res.ok || !data.success) {
        setLoginError(data.error ?? "Account not found or password incorrect.");
        return;
      }

      setCookie(COOKIE_KEY, data.token, COOKIE_DAYS);
      setSubscriber(data.subscriber as Subscriber);
      setStep("portal");
    } catch (err: any) {
      setLoginError(err.message);
    } finally {
      setLoggingIn(false);
    }
  };

  const handleLogout = () => {
    deleteCookie(COOKIE_KEY);
    setSubscriber(null);
    setStep("select");
  };

  if (step === "loading") return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <Loader2 className="h-8 w-8 text-primary animate-spin" />
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-4">
      {/* PWA Install Banner */}
      {showInstallBanner && (
        <div className="fixed top-4 left-4 right-4 max-w-sm mx-auto z-50 glass-card p-4 flex items-center gap-3 border-primary/50">
          <div className="h-10 w-10 rounded-xl bg-primary/20 flex items-center justify-center shrink-0">
            <Download className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <p className="text-xs font-semibold">Install WiFi Portal App</p>
            <p className="text-[10px] text-muted-foreground">Access your account offline &amp; get notifications</p>
          </div>
          <div className="flex gap-1">
            <Button size="sm" className="h-7 text-xs" onClick={installPWA}>Install</Button>
            <Button variant="ghost" size="sm" className="h-7 w-7 p-0" onClick={() => setShowInstallBanner(false)}><X className="h-3.5 w-3.5" /></Button>
          </div>
        </div>
      )}

      <div className="w-full max-w-lg space-y-6">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="h-14 w-14 rounded-2xl bg-primary/20 flex items-center justify-center mx-auto mb-4">
            <Wifi className="h-7 w-7 text-primary" />
          </div>
          <h1 className="text-2xl font-bold text-gradient">Connect to WiFi</h1>
          {step === "select" && <p className="text-sm text-muted-foreground">Select a package &amp; pay via M-Pesa</p>}
          {step === "login" && <p className="text-sm text-muted-foreground">Sign in with your phone &amp; password</p>}
          {step === "portal" && <p className="text-sm text-muted-foreground">Your account dashboard</p>}
        </div>

        {/* Package Selection */}
        {step === "select" && (
          <div className="space-y-3">
            {packages.map((pkg) => (
              <button key={pkg.id} onClick={() => { setSelectedPkg(pkg); setStep("phone"); }}
                className="w-full glass-card p-4 text-left transition-all hover:border-primary/50 active:scale-[0.99]">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="font-bold text-foreground">{pkg.name}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">↓{pkg.speed_down} · {pkg.duration_days}d · {pkg.max_devices} device{pkg.max_devices > 1 ? "s" : ""}</p>
                  </div>
                  <p className="text-lg font-extrabold text-primary">KES {Number(pkg.price).toLocaleString()}</p>
                </div>
              </button>
            ))}
            <div className="pt-2 text-center">
              <button onClick={() => setStep("login")} className="text-xs text-primary hover:underline flex items-center gap-1 mx-auto">
                <LogIn className="h-3.5 w-3.5" />Already have an account? Sign in
              </button>
            </div>
          </div>
        )}

        {/* Phone entry for purchase */}
        {step === "phone" && selectedPkg && (
          <div className="glass-card p-6 space-y-5">
            <div className="text-center">
              <p className="text-sm text-muted-foreground">Selected: <span className="font-semibold text-foreground">{selectedPkg.name}</span></p>
              <p className="text-2xl font-extrabold text-primary mt-1">KES {Number(selectedPkg.price).toLocaleString()}</p>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-muted-foreground">M-Pesa Phone Number</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="0712345678" value={phone} onChange={(e) => setPhone(e.target.value)} className="pl-9 bg-muted/50 border-border" type="tel" maxLength={12} />
              </div>
            </div>
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => { setStep("select"); setSelectedPkg(null); }}>Back</Button>
              <Button className="flex-1" onClick={handlePurchase} disabled={!phone || phone.length < 9}>Pay via M-Pesa</Button>
            </div>
            <button onClick={() => setStep("login")} className="text-xs text-primary hover:underline w-full text-center">
              Already paid? Sign in instead
            </button>
          </div>
        )}

        {/* Processing */}
        {step === "processing" && (
          <div className="glass-card p-10 text-center space-y-4">
            <Loader2 className="h-10 w-10 text-primary animate-spin mx-auto" />
            <div>
              <p className="font-semibold">STK Push Sent to {phone}</p>
              <p className="text-sm text-muted-foreground mt-1">Enter your M-Pesa PIN on your phone to complete payment</p>
            </div>
            <div className="text-xs text-muted-foreground animate-pulse">Waiting for confirmation...</div>
          </div>
        )}

        {/* Success */}
        {step === "success" && subscriber && (
          <div className="glass-card p-8 text-center space-y-4">
            <div className="h-14 w-14 rounded-full bg-success/20 flex items-center justify-center mx-auto">
              <CheckCircle className="h-7 w-7 text-success" />
            </div>
            <div>
              <p className="font-bold text-lg">You're Connected, {subscriber.full_name?.split(" ")[0]}!</p>
              <p className="text-sm text-muted-foreground mt-1">Your WiFi password has been sent via SMS.</p>
            </div>
            <Button className="w-full" onClick={() => setStep("portal")}>View My Account</Button>
          </div>
        )}

        {/* Login Form */}
        {step === "login" && (
          <div className="glass-card p-6 space-y-4">
            <div className="space-y-2">
              <label className="text-xs font-medium text-muted-foreground">Phone Number</label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input placeholder="0712345678" value={loginPhone} onChange={(e) => setLoginPhone(e.target.value)} className="pl-9 bg-muted/50 border-border" type="tel" />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-xs font-medium text-muted-foreground">Password (sent via SMS)</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input type={pwdVisible ? "text" : "password"} placeholder="Your WiFi password" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} className="pl-9 pr-10 bg-muted/50 border-border"
                  onKeyDown={(e) => e.key === "Enter" && handleLogin()} />
                <button type="button" onClick={() => setPwdVisible(!pwdVisible)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground text-xs">
                  {pwdVisible ? "Hide" : "Show"}
                </button>
              </div>
            </div>
            {loginError && <p className="text-xs text-destructive">{loginError}</p>}
            <div className="flex gap-3">
              <Button variant="outline" className="flex-1" onClick={() => setStep("select")}>Back</Button>
              <Button className="flex-1 gap-2" onClick={handleLogin} disabled={loggingIn}>
                {loggingIn ? <Loader2 className="h-4 w-4 animate-spin" /> : <LogIn className="h-4 w-4" />}Sign In
              </Button>
            </div>
          </div>
        )}

        {/* Subscriber Portal */}
        {step === "portal" && subscriber && (
          <div className="space-y-4">
            <div className="glass-card p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="font-bold">{subscriber.full_name}</p>
                  <p className="text-xs font-mono text-muted-foreground">{subscriber.username}</p>
                </div>
                <span className={`px-2.5 py-1 rounded-full text-[10px] font-semibold ${subscriber.status === "active" ? "bg-success/20 text-success" : "bg-destructive/20 text-destructive"}`}>
                  {subscriber.status}
                </span>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between py-2 border-b border-border/30">
                  <span className="text-muted-foreground">Package</span>
                  <span className="font-semibold">{subscriber.packages?.name ?? "—"}</span>
                </div>
                <div className="flex justify-between py-2 border-b border-border/30">
                  <span className="text-muted-foreground">Expires</span>
                  <span className="font-mono text-xs">{subscriber.expires_at ? new Date(subscriber.expires_at).toLocaleDateString() : "—"}</span>
                </div>
                <div className="flex justify-between py-2">
                  <span className="text-muted-foreground">Phone</span>
                  <span className="font-mono text-xs">{subscriber.phone}</span>
                </div>
              </div>
            </div>

            {/* Renew */}
            <div className="glass-card p-5">
              <h3 className="text-sm font-semibold mb-3">Renew / Upgrade Package</h3>
              <div className="space-y-2">
                {packages.slice(0, 4).map((pkg) => (
                  <button key={pkg.id} onClick={() => { setSelectedPkg(pkg); setPhone(subscriber.phone); setStep("phone"); }}
                    className="w-full flex items-center justify-between p-3 rounded-lg border border-border hover:border-primary/50 transition-colors text-sm">
                    <span>{pkg.name} · {pkg.duration_days}d</span>
                    <span className="font-bold text-primary">KES {Number(pkg.price).toLocaleString()}</span>
                  </button>
                ))}
              </div>
            </div>

            <Button variant="outline" className="w-full" onClick={handleLogout}>Sign Out</Button>
          </div>
        )}

        <p className="text-[10px] text-center text-muted-foreground">WiFi Billing System · Powered by MikroTik</p>
      </div>
    </div>
  );
};

export default HotspotPortal;
