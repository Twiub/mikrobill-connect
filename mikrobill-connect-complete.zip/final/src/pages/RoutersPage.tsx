import { useState } from "react";
import AdminLayout from "@/components/AdminLayout";
import StatusBadge from "@/components/StatusBadge";
import { useRouters } from "@/hooks/useDatabase";
import { supabase } from "@/integrations/supabase/client";
import { Wifi, AlertTriangle, Settings, Plus, Loader2, Save, Eye, EyeOff, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Progress } from "@/components/ui/progress";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const EMPTY_ROUTER = {
  name: "",
  ip_address: "",
  api_port: 8728,
  api_username: "admin",
  api_password: "",
  api_ssl: false,
  location: "",
  nas_ip: "",
  secret_radius: "",
};

const RoutersPage = () => {
  const { data: routers, isLoading } = useRouters();
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showPass, setShowPass] = useState(false);
  const [showSecret, setShowSecret] = useState(false);
  const [editId, setEditId] = useState<string | null>(null);
  const [form, setForm] = useState({ ...EMPTY_ROUTER });

  const openAdd = () => { setEditId(null); setForm({ ...EMPTY_ROUTER }); setShowPass(false); setOpen(true); };
  const openEdit = (r: any) => {
    setEditId(r.id);
    setForm({
      name: r.name ?? "", ip_address: r.ip_address ?? "",
      api_port: r.api_port ?? 8728, api_username: r.api_username ?? "admin",
      api_password: r.api_password ?? "", api_ssl: r.api_ssl ?? false,
      location: r.location ?? "", nas_ip: r.nas_ip ?? "",
      secret_radius: r.secret_radius ?? "",
    });
    setOpen(true);
  };

  const set = (k: keyof typeof EMPTY_ROUTER) => (v: any) => setForm((f) => ({ ...f, [k]: v }));

  const handleSave = async () => {
    if (!form.name.trim() || !form.ip_address.trim()) {
      toast({ title: "Validation Error", description: "Name and IP address are required.", variant: "destructive" });
      return;
    }
    // Basic IP validation
    const ipRe = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (!ipRe.test(form.ip_address.trim())) {
      toast({ title: "Invalid IP", description: "Please enter a valid IPv4 address.", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const payload: any = {
        name: form.name.trim(),
        ip_address: form.ip_address.trim(),
        api_port: Number(form.api_port),
        api_username: form.api_username,
        api_password: form.api_password,
        api_ssl: form.api_ssl,
        location: form.location || null,
        nas_ip: form.nas_ip || null,
        secret_radius: form.secret_radius || null,
        status: "offline",
      };
      if (editId) {
        const { error } = await supabase.from("routers").update(payload).eq("id", editId);
        if (error) throw error;
        toast({ title: "Router Updated", description: `${form.name} saved. Connection will be tested on next poll.` });
      } else {
        const { error } = await supabase.from("routers").insert(payload);
        if (error) throw error;
        toast({ title: "Router Added", description: `${form.name} added. Status will update within 1 minute.` });
      }
      queryClient.invalidateQueries({ queryKey: ["routers"] });
      setOpen(false);
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <AdminLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">MikroTik Routers</h1>
            <p className="text-sm text-muted-foreground mt-1">Network device management &amp; monitoring</p>
          </div>
          <Button size="sm" className="gap-2" onClick={openAdd}>
            <Plus className="h-4 w-4" />Add Router
          </Button>
        </div>

        {/* Info banner */}
        <div className="flex items-start gap-3 p-4 rounded-lg bg-info/10 border border-info/30 text-sm">
          <Info className="h-4 w-4 text-info mt-0.5 shrink-0" />
          <div className="text-info">
            <p className="font-medium">MikroTik API Setup</p>
            <p className="text-xs mt-0.5 opacity-80">Enable API on router: <code>/ip service enable api</code> (port 8728) or API-SSL (port 8729). Create a dedicated API user with full permissions in <code>/user</code>. The backend polling service updates status, CPU, memory, and active users every 60 seconds.</p>
          </div>
        </div>

        {isLoading ? (
          <div className="p-8 text-center text-muted-foreground">Loading routers...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {routers?.map((r: any) => (
              <div key={r.id} className={`glass-card p-6 ${r.status === "offline" ? "border-destructive/30" : "border-border/50"}`}>
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-3">
                    <div className={`h-10 w-10 rounded-lg flex items-center justify-center ${r.status === "online" ? "bg-success/10" : "bg-destructive/10"}`}>
                      <Wifi className={`h-5 w-5 ${r.status === "online" ? "text-success" : "text-destructive"}`} />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm">{r.name}</h3>
                      <p className="text-xs font-mono text-muted-foreground">{r.ip_address}:{r.api_port ?? 8728}</p>
                      {r.location && <p className="text-[10px] text-muted-foreground">{r.location}</p>}
                    </div>
                  </div>
                  <StatusBadge status={r.status} />
                </div>

                {r.status === "online" ? (
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-muted-foreground">CPU Load</span>
                        <span className={`font-semibold ${r.cpu_load > 80 ? "text-destructive" : r.cpu_load > 60 ? "text-warning" : "text-success"}`}>{r.cpu_load}%</span>
                      </div>
                      <Progress value={r.cpu_load} className="h-1.5" />
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-muted-foreground">Memory</span>
                        <span className={`font-semibold ${r.memory_used > 80 ? "text-destructive" : r.memory_used > 60 ? "text-warning" : "text-success"}`}>{r.memory_used}%</span>
                      </div>
                      <Progress value={r.memory_used} className="h-1.5" />
                    </div>
                    <div className="flex justify-between text-sm pt-2 border-t border-border/50">
                      <span className="text-muted-foreground">Active Users</span>
                      <span className="font-bold text-primary">{r.active_users}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Uptime</span>
                      <span className="font-mono text-xs">{r.uptime}</span>
                    </div>
                    {r.model && <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Model</span>
                      <span className="text-xs">{r.model}</span>
                    </div>}
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-3 py-4 text-destructive">
                    <AlertTriangle className="h-8 w-8" />
                    <p className="text-sm font-medium">Router Unreachable</p>
                    <p className="text-[10px] text-muted-foreground text-center">Check API service is enabled and credentials are correct</p>
                  </div>
                )}

                <div className="mt-4 pt-4 border-t border-border/50 flex justify-end">
                  <Button variant="ghost" size="sm" className="text-xs text-primary h-7" onClick={() => openEdit(r)}>
                    <Settings className="h-3 w-3 mr-1" />Configure
                  </Button>
                </div>
              </div>
            ))}
            {routers?.length === 0 && (
              <div className="col-span-3 glass-card p-12 text-center text-muted-foreground">
                <Wifi className="h-10 w-10 mx-auto mb-3 opacity-30" />
                <p className="font-medium">No routers added yet</p>
                <p className="text-sm mt-1">Click "Add Router" to connect your first MikroTik device.</p>
              </div>
            )}
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-xl">
          <DialogHeader>
            <DialogTitle>{editId ? "Edit Router" : "Add MikroTik Router"}</DialogTitle>
          </DialogHeader>
          <Tabs defaultValue="connection">
            <TabsList className="mb-4">
              <TabsTrigger value="connection">Connection</TabsTrigger>
              <TabsTrigger value="radius">RADIUS / NAS</TabsTrigger>
            </TabsList>

            <TabsContent value="connection" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label>Router Name *</Label>
                  <Input placeholder="e.g. Main Office" value={form.name} onChange={(e) => set("name")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>IP Address *</Label>
                  <Input placeholder="192.168.88.1" value={form.ip_address} onChange={(e) => set("ip_address")(e.target.value)} />
                </div>
                <div className="space-y-1.5">
                  <Label>API Port</Label>
                  <Input type="number" placeholder="8728" value={form.api_port} onChange={(e) => set("api_port")(e.target.value)} />
                  <p className="text-[10px] text-muted-foreground">8728 (API) or 8729 (API-SSL)</p>
                </div>
                <div className="space-y-1.5">
                  <Label>API Username</Label>
                  <Input placeholder="admin" value={form.api_username} onChange={(e) => set("api_username")(e.target.value)} />
                </div>
                <div className="col-span-2 space-y-1.5">
                  <Label>API Password</Label>
                  <div className="relative">
                    <Input
                      type={showPass ? "text" : "password"}
                      placeholder="Router API password"
                      value={form.api_password}
                      onChange={(e) => set("api_password")(e.target.value)}
                    />
                    <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
                      {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label>Location / Site</Label>
                  <Input placeholder="e.g. Westlands, Nairobi" value={form.location} onChange={(e) => set("location")(e.target.value)} />
                </div>
                <div className="flex items-center gap-2 pt-5">
                  <Switch checked={form.api_ssl} onCheckedChange={set("api_ssl")} />
                  <Label>Use API-SSL (port 8729)</Label>
                </div>
              </div>
              <div className="p-3 rounded-lg bg-muted/40 text-xs text-muted-foreground">
                <strong>RouterOS setup:</strong><br />
                <code>/ip service enable api</code><br />
                <code>/user add name=billing-api password=PASS group=full</code>
              </div>
            </TabsContent>

            <TabsContent value="radius" className="space-y-4">
              <div className="p-3 rounded-lg bg-muted/40 text-xs text-muted-foreground">
                RADIUS / NAS settings are needed if this router authenticates users against FreeRADIUS. The NAS-IP is the router's IP as seen by the RADIUS server.
              </div>
              <div className="space-y-1.5">
                <Label>NAS IP Address</Label>
                <Input placeholder="Same as router IP usually" value={form.nas_ip} onChange={(e) => set("nas_ip")(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>RADIUS Secret</Label>
                <div className="relative">
                  <Input
                    type={showSecret ? "text" : "password"}
                    placeholder="Shared secret between router and RADIUS"
                    value={form.secret_radius}
                    onChange={(e) => set("secret_radius")(e.target.value)}
                  />
                  <button type="button" onClick={() => setShowSecret(!showSecret)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                    {showSecret ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                <p className="text-[10px] text-muted-foreground">Must match <code>/radius set secret=...</code> on the router</p>
              </div>
            </TabsContent>
          </Tabs>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving} className="gap-2">
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
              {editId ? "Save Changes" : "Add Router"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
};

export default RoutersPage;
