/**
 * src/pages/CoverageMapPage.tsx
 *
 * Admin coverage map showing:
 *   • User location heatmap (where subscribers are connecting from)
 *   • MikroTik router markers (online/offline)
 *   • RadiusDesk access point markers with client counts
 *   • Outage zones (areas with historic coverage but no recent connections)
 *
 * Uses Leaflet.js + Leaflet.heat loaded via CDN (no npm package needed).
 * PostGIS aggregation happens server-side; client receives pre-bucketed points.
 */

import { useEffect, useRef, useState } from "react";
import AdminLayout from "@/components/AdminLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Wifi, AlertTriangle, RefreshCw, Radio, Users } from "lucide-react";

// ── Types ────────────────────────────────────────────────────────────────────

interface HeatPoint  { lat: number; lng: number; weight: number }
interface RouterPin  { id: number; name: string; ip_address: string; lat: number | null; lng: number | null; status: string; active_users: number; cpu_load: number }
interface APPin      { mac: string; name: string; lat: number; lng: number; online: boolean; active_clients: number; last_contact: string }
interface OutageZone { lat: number; lng: number; historical_count: number }

interface CoverageData {
  locations:   HeatPoint[];
  routers:     RouterPin[];
  aps:         APPin[];
  outageZones: OutageZone[];
}

// ── Hours filter options ─────────────────────────────────────────────────────
const HOUR_OPTIONS = [1, 6, 24, 72, 168] as const;

// ── Component ────────────────────────────────────────────────────────────────
const CoverageMapPage = () => {
  const mapRef       = useRef<HTMLDivElement>(null);
  const leafletMap   = useRef<any>(null);
  const heatLayer    = useRef<any>(null);
  const markersGroup = useRef<any>(null);

  const [data,       setData]       = useState<CoverageData | null>(null);
  const [hours,      setHours]      = useState<number>(24);
  const [loading,    setLoading]    = useState(false);
  const [lastFetch,  setLastFetch]  = useState<Date | null>(null);
  const [layers,     setLayers]     = useState({ heatmap: true, routers: true, aps: true, outages: true });

  // ── Load Leaflet + Leaflet.heat from CDN ──────────────────────────────────
  useEffect(() => {
    const loadScript = (src: string, id: string): Promise<void> =>
      new Promise((res, rej) => {
        if (document.getElementById(id)) { res(); return; }
        const s = document.createElement("script");
        s.id = id; s.src = src; s.onload = () => res(); s.onerror = rej;
        document.head.appendChild(s);
      });

    const loadLink = (href: string, id: string) => {
      if (document.getElementById(id)) return;
      const l = document.createElement("link");
      l.id = id; l.rel = "stylesheet"; l.href = href;
      document.head.appendChild(l);
    };

    loadLink("https://unpkg.com/leaflet@1.9.4/dist/leaflet.css", "leaflet-css");

    loadScript("https://unpkg.com/leaflet@1.9.4/dist/leaflet.js", "leaflet-js")
      .then(() => loadScript("https://unpkg.com/leaflet.heat@0.2.0/dist/leaflet-heat.js", "leaflet-heat-js"))
      .then(() => initMap())
      .catch(e => console.error("Leaflet load failed", e));

    return () => {
      leafletMap.current?.remove();
      leafletMap.current = null;
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── Initialise map ────────────────────────────────────────────────────────
  function initMap() {
    const L = (window as any).L;
    if (!mapRef.current || !L || leafletMap.current) return;

    const map = L.map(mapRef.current, { zoomControl: true }).setView([-1.2921, 36.8219], 11);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution: "© OpenStreetMap contributors",
      maxZoom: 19,
    }).addTo(map);

    markersGroup.current = L.layerGroup().addTo(map);
    leafletMap.current   = map;

    fetchData();
  }

  // ── Fetch coverage data from API ──────────────────────────────────────────
  async function fetchData() {
    setLoading(true);
    try {
      const res = await fetch(`/api/admin/coverage-map?hours=${hours}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json: CoverageData = await res.json();
      setData(json);
      setLastFetch(new Date());
      renderLayers(json);
    } catch (e) {
      console.error("Coverage map fetch failed", e);
    } finally {
      setLoading(false);
    }
  }

  // ── Re-fetch when hours filter changes ────────────────────────────────────
  useEffect(() => {
    if (leafletMap.current) fetchData();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hours]);

  // ── Render map layers ─────────────────────────────────────────────────────
  function renderLayers(d: CoverageData) {
    const L = (window as any).L;
    if (!L || !leafletMap.current) return;

    // Clear previous
    heatLayer.current?.remove();
    markersGroup.current?.clearLayers();

    // Heatmap
    if (layers.heatmap && d.locations.length > 0) {
      const heatData = d.locations.map(p => [p.lat, p.lng, Math.min(p.weight / 10, 1)]);
      heatLayer.current = (L as any).heatLayer(heatData, {
        radius: 25, blur: 15, maxZoom: 17, max: 1.0,
        gradient: { 0.2: "#3b82f6", 0.5: "#22c55e", 0.8: "#f59e0b", 1.0: "#ef4444" },
      }).addTo(leafletMap.current);
    }

    // Router markers
    if (layers.routers) {
      d.routers.filter(r => r.lat && r.lng).forEach(r => {
        const color  = r.status === "online" ? "#22c55e" : "#ef4444";
        const marker = L.circleMarker([r.lat, r.lng], {
          radius: 14, color, fillColor: color, fillOpacity: 0.85, weight: 2,
        });
        marker.bindPopup(
          `<b>🔴 ${r.name}</b><br>` +
          `IP: ${r.ip_address}<br>` +
          `Status: <b>${r.status}</b><br>` +
          `Active users: ${r.active_users}<br>` +
          `CPU: ${r.cpu_load}%`
        );
        markersGroup.current.addLayer(marker);
      });
    }

    // RadiusDesk AP markers
    if (layers.aps) {
      d.aps.forEach(ap => {
        const color  = ap.online ? "#8b5cf6" : "#6b7280";
        const marker = L.circleMarker([ap.lat, ap.lng], {
          radius: 9, color, fillColor: color, fillOpacity: 0.75, weight: 2,
        });
        marker.bindPopup(
          `<b>📡 ${ap.name}</b><br>` +
          `MAC: <code>${ap.mac}</code><br>` +
          `Status: <b>${ap.online ? "Online" : "Offline"}</b><br>` +
          `Clients: ${ap.active_clients}`
        );
        markersGroup.current.addLayer(marker);
      });
    }

    // Outage zones (red circles)
    if (layers.outages) {
      d.outageZones.forEach(z => {
        const circle = L.circle([z.lat, z.lng], {
          radius: 200, color: "#ef4444", fillColor: "#ef4444",
          fillOpacity: 0.2, weight: 1, dashArray: "4",
        });
        circle.bindPopup(
          `<b>⚠️ Possible Outage Zone</b><br>` +
          `Historical connections: ${z.historical_count}<br>` +
          `No recent connections (2h+)`
        );
        markersGroup.current.addLayer(circle);
      });
    }
  }

  // Re-render when toggle changes without re-fetching
  useEffect(() => {
    if (data) renderLayers(data);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [layers]);

  // ── Summary stats ─────────────────────────────────────────────────────────
  const totalUsers    = data?.locations.reduce((s, p) => s + p.weight, 0) ?? 0;
  const onlineRouters = data?.routers.filter(r => r.status === "online").length ?? 0;
  const onlineAPs     = data?.aps.filter(a => a.online).length ?? 0;
  const outageCount   = data?.outageZones.length ?? 0;

  return (
    <AdminLayout>
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Coverage Map</h1>
            <p className="text-sm text-muted-foreground mt-0.5">
              User location heatmap · Router & AP status · Outage detection
            </p>
          </div>
          <div className="flex items-center gap-2">
            {/* Hours filter */}
            <div className="flex gap-1">
              {HOUR_OPTIONS.map(h => (
                <Button
                  key={h}
                  variant={hours === h ? "default" : "outline"}
                  size="sm"
                  className="text-xs h-7 px-2"
                  onClick={() => setHours(h)}
                >
                  {h < 24 ? `${h}h` : `${h / 24}d`}
                </Button>
              ))}
            </div>
            <Button size="sm" variant="outline" className="gap-1.5 text-xs" onClick={fetchData} disabled={loading}>
              <RefreshCw className={`h-3.5 w-3.5 ${loading ? "animate-spin" : ""}`} />
              Refresh
            </Button>
          </div>
        </div>

        {/* Stat pills */}
        <div className="flex flex-wrap gap-3">
          <div className="glass-card px-4 py-2.5 flex items-center gap-2">
            <Users className="h-4 w-4 text-primary" />
            <span className="text-xs text-muted-foreground">Reports</span>
            <span className="text-sm font-bold">{totalUsers.toLocaleString()}</span>
          </div>
          <div className="glass-card px-4 py-2.5 flex items-center gap-2">
            <Wifi className="h-4 w-4 text-success" />
            <span className="text-xs text-muted-foreground">Routers online</span>
            <span className="text-sm font-bold">{onlineRouters}/{data?.routers.length ?? 0}</span>
          </div>
          <div className="glass-card px-4 py-2.5 flex items-center gap-2">
            <Radio className="h-4 w-4 text-violet-500" />
            <span className="text-xs text-muted-foreground">APs online</span>
            <span className="text-sm font-bold">{onlineAPs}/{data?.aps.length ?? 0}</span>
          </div>
          {outageCount > 0 && (
            <div className="glass-card px-4 py-2.5 flex items-center gap-2 border-destructive/30">
              <AlertTriangle className="h-4 w-4 text-destructive" />
              <span className="text-xs text-muted-foreground">Outage zones</span>
              <Badge variant="destructive" className="text-xs">{outageCount}</Badge>
            </div>
          )}
          {lastFetch && (
            <div className="glass-card px-4 py-2.5 text-xs text-muted-foreground">
              Updated {lastFetch.toLocaleTimeString()}
            </div>
          )}
        </div>

        {/* Layer toggles */}
        <div className="flex flex-wrap gap-2">
          {(["heatmap", "routers", "aps", "outages"] as const).map(key => {
            const labels: Record<string, string> = {
              heatmap: "🔥 Heatmap",
              routers: "🔴 Routers",
              aps:     "📡 Access Points",
              outages: "⚠️ Outage Zones",
            };
            return (
              <Button
                key={key}
                size="sm"
                variant={layers[key] ? "default" : "outline"}
                className="text-xs h-7"
                onClick={() => setLayers(l => ({ ...l, [key]: !l[key] }))}
              >
                {labels[key]}
              </Button>
            );
          })}
        </div>

        {/* Map */}
        <div className="glass-card overflow-hidden" style={{ height: "calc(100vh - 300px)", minHeight: 500 }}>
          <div ref={mapRef} style={{ height: "100%", width: "100%" }} />
        </div>

        {/* Legend */}
        <div className="glass-card p-4 flex flex-wrap gap-6 text-xs text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-[#3b82f6]" />Low density
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-[#22c55e]" />Medium density
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-[#ef4444]" />High density
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-[#22c55e] opacity-80" />Router online
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-[#ef4444] opacity-80" />Router offline
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-[#8b5cf6] opacity-80" />AP online
          </div>
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 rounded-full bg-[#ef4444] border-2 border-dashed border-[#ef4444]" />Outage zone
          </div>
        </div>
      </div>
    </AdminLayout>
  );
};

export default CoverageMapPage;
