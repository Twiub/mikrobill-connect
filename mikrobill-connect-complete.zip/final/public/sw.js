// WiFi Billing PWA Service Worker v1.0
const CACHE_NAME = "wifibill-v1";
const STATIC_ASSETS = ["/", "/hotspot", "/manifest.json"];

// Install: cache static assets
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS)).then(() => self.skipWaiting())
  );
});

// Activate: clean old caches
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))).then(() => self.clients.claim())
  );
});

// Fetch: network first for API, cache first for assets
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // Always network for Supabase API calls
  if (url.hostname.includes("supabase.co") || url.pathname.startsWith("/api/")) {
    event.respondWith(
      fetch(event.request).catch(() => new Response(JSON.stringify({ error: "offline" }), { headers: { "Content-Type": "application/json" } }))
    );
    return;
  }

  // Cache first for static assets
  event.respondWith(
    caches.match(event.request).then((cached) => {
      if (cached) return cached;
      return fetch(event.request).then((res) => {
        if (res.ok) {
          const clone = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put(event.request, clone));
        }
        return res;
      });
    }).catch(() => caches.match("/"))
  );
});

// Background sync for portal session keep-alive
self.addEventListener("periodicsync", (event) => {
  if (event.tag === "session-keepalive") {
    event.waitUntil(
      fetch("/api/portal/keepalive", { method: "POST", credentials: "include" }).catch(() => {})
    );
  }
});

// Push notifications
self.addEventListener("push", (event) => {
  const data = event.data?.json() ?? { title: "WiFi Billing", body: "New notification" };
  event.waitUntil(
    self.registration.showNotification(data.title, {
      body: data.body,
      icon: "/favicon.ico",
      badge: "/favicon.ico",
      tag: data.tag ?? "wifibill",
      data: data.url ? { url: data.url } : undefined,
    })
  );
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = event.notification.data?.url ?? "/hotspot";
  event.waitUntil(clients.openWindow(url));
});
