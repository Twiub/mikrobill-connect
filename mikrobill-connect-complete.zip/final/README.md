# Mikrobill Connect v2.0 — Complete WiFi ISP Billing System

A production-ready web application for managing MikroTik-based ISP networks with full billing, monitoring, and subscriber management.

---

## Features

### Core Admin
- Subscriber management (create, edit, suspend, delete)
- Package & pricing management with burst support
- M-Pesa transaction tracking (STK push & C2B)
- Active sessions monitoring & remote disconnect
- Support ticket system with GPS location tagging
- Ticket map (geographic ticket view)
- KYC compliance & ID document uploads
- Admin roles & permissions
- Expenditure tracking
- Notifications centre

### Network & MikroTik
- MikroTik router management (auto-registers NAS in FreeRADIUS + RadiusDesk)
- Network health monitor
- Bandwidth schedules
- IP/MAC binding
- Anti-sharing / tethering enforcement (real-time sync from MikroTik)
- **IP Pool utilisation dashboard** (per-router, auto-refresh 60s)
- **QoS / CAKE monitoring** (WAN queues, top users, drop rate alerts, auto-refresh 30s)

### Coverage & Location
- **Interactive coverage map** (user heatmap + router markers + RadiusDesk APs + outage zones)
- GDPR-style location consent in User Portal
- Periodic GPS reporting from PWA (every 5 min, only on ISP network)

### User Portal (PWA)
- Package status & data usage
- Device management
- M-Pesa payment initiation
- Usage analytics
- Support ticket submission with auto-GPS
- Smart TV IP binding (captive portal bypass)
- Location sharing with consent

### Analytics & AI
- Revenue & usage analytics dashboard
- AI network health insights
- Error logs

---

## Quick Start

### 1. Prerequisites
- Node.js >= 18
- Supabase project
- MikroTik RouterOS API access
- (Optional) RadiusDesk instance for AP management
- (Optional) Redis for QoS top-user leaderboard

### 2. Frontend Setup
```bash
npm install
npm run dev        # development
npm run build      # production build
```

### 3. Database Migrations
```bash
# Enable PostGIS in Supabase Dashboard -> Database -> Extensions first, then:
supabase db push

# Or manually in order:
psql $DATABASE_URL -f supabase/migrations/20260226112712_87d5980b-544c-4e80-b0b1-0c08d5388153.sql
psql $DATABASE_URL -f supabase/migrations/002_new_features.sql
psql $DATABASE_URL -f supabase/migrations/001_missing_features.sql
```

### 4. Backend Setup
```bash
cd backend
npm install
# Set environment variables (see .env section below)
npm start
```

### 5. Environment Variables

Frontend `.env`:
- `VITE_SUPABASE_URL` — Supabase project URL
- `VITE_SUPABASE_PUBLISHABLE_KEY` — Supabase anon key

Backend `.env`:
- `SUPABASE_URL` + `SUPABASE_SERVICE_ROLE_KEY` — Supabase server credentials
- `MIKROTIK_HOST`, `MIKROTIK_USER`, `MIKROTIK_PASS` — MikroTik API
- `RADIUSDESK_URL`, `RADIUSDESK_API_TOKEN` — RadiusDesk (optional)
- `REDIS_URL` — Redis for QoS leaderboard (optional)
- `PORT` — Backend port (default 3001)

---

## New Pages (v2.0)

| Page | Path | Description |
|---|---|---|
| Coverage Map | `/coverage-map` | Leaflet heatmap with router & AP markers |
| IP Pools | `/ip-pools` | Per-router pool utilisation with alerts |
| QoS / CAKE | `/qos` | CAKE queue stats, top users, drop rate |

---

## Production Deployment

**Frontend:** `npm run build` → deploy `dist/` to Vercel/Netlify/Cloudflare Pages

**Backend:** `cd backend && npm ci --production && node src/index.js` — runs on any Node.js host (Railway, Render, DigitalOcean)

**PWA:** manifest.json + sw.js included for Add to Home Screen support on mobile
